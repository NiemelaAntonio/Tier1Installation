#!/usr/bin/env python
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Kelvin-Helmholtz instability in the solar corona.
"""

import argparse

import numpy as np

import coco
import coco.io.vtk
import coco.sim


class CoronalKelvinHelmholtzSimulation(coco.sim.IdealMagnetohydrodynamicsSimulation):
    """Simulation setup to study the Kelvin-Helmholtz instability using
    solar coronal parameters.

    This simulation is setup to study the KH instability in solar coronal
    conditions following the work of  `Nykyri et al. (2013)`_ (henceforth
    denoted N13).

    The simulation considers a 100 Mm x 50 Mm portion of the
    corona with two distinct plasma environments: the "ejecta" that represents
    plasma in the vicinity of the erupting CME, and surrounding "ambient"
    coronal plasma. The two plasmas are separated by a thin transition.
    The ejecta is moving at a certain velocity with respect to the ambient
    plasma. This is modelled in the frame moving at half that speed.

    .. _Nykyri et al. (2013):
       https://doi.org/10.1002/grl.50807
    """

    def __init__(self, **kwargs):

        coco.sim.IdealMagnetohydrodynamicsSimulation.__init__(self, **kwargs)

        #
        # Model parameters
        #
        self.params.adiabatic_index = 5.0 / 3.0
        self.params.mean_molecular_mass = 0.5 * coco.constants.proton_mass

        #
        # Hydrodynamic parameters of the ambient corona, SI
        #
        self.params.ambient_number_density = 7.1e8 * 1e6  # m^{-3}
        self.params.ambient_temperature = 4.5e6  # K

        self.params.ambient_mass_density = self.params.ambient_number_density * self.params.mean_molecular_mass

        self.params.ambient_pressure = (
            2.0 * self.params.ambient_number_density * self.params.ambient_temperature * coco.constants.kB
        )

        #
        # Hydrodynamic parameters of the ejecta, SI
        #
        self.params.ejecta_number_density = 7.1e8 * 1e6  # m^{-3}
        self.params.ejecta_temperature = 11.6e6  # K

        self.params.ejecta_mass_density = self.params.ejecta_number_density * self.params.mean_molecular_mass

        self.params.ejecta_pressure = (
            2.0 * self.params.ejecta_number_density * self.params.ejecta_temperature * coco.constants.kB
        )

        #
        # Ambient magnetic field parameters (case 4c in N13)
        #
        mu0 = coco.constants.mu0

        self.params.ambient_B = 11.0e-4
        self.params.ambient_B_inclination = 1.0 * np.pi / 180.0

        self.params.ambient_Bx = -self.params.ambient_B * np.sin(self.params.ambient_B_inclination)
        self.params.ambient_Bz = self.params.ambient_B * np.cos(self.params.ambient_B_inclination)

        #
        # Ejecta magnetic field parameters (case 4c in N13)
        #
        self.params.ejecta_B = np.sqrt(
            2.0
            * mu0
            * (self.params.ambient_pressure - self.params.ejecta_pressure + 0.5 * self.params.ambient_B ** 2 / mu0)
        )

        self.params.ejecta_B_inclination = 3.0 * np.pi / 180.0

        self.params.ejecta_Bx = -self.params.ejecta_B * np.sin(self.params.ejecta_B_inclination)
        self.params.ejecta_Bz = self.params.ejecta_B * np.cos(self.params.ejecta_B_inclination)

        #
        # Shear flow speed, i.e. speed of the ejecta
        #
        self.params.shear_flow_speed = 772.0 * 1e3  # m/s

        #
        # Maximum amplitude of the velocity perturbation at y = 0
        #
        self.params.perturbation_amplitude = 0.01 * self.params.shear_flow_speed

        #
        # Width of shear layer
        #
        self.params.shear_layer_width = 2.0e6  # m

        # Argument to tanh() function in shear profile
        self.params.tanh_scale = 0.5 * self.params.shear_layer_width / np.arctanh(0.95)

    def set_grid(self, num_cells=128):
        """Set coordinates of the computational grid
        """

        #
        # Construct coordinates of the edges of the in-domain cells.
        # In this case, a uniform grid is chosen in each direction
        #
        x = coco.CoordinateAxis(name="x", unit=1e6)
        x.construct_uniform(-50, 50, num_cells + 1)

        y = coco.CoordinateAxis(name="y", unit=1e6)
        y.construct_uniform(-25, 25, num_cells + 1)

        # z is a "dummy" axis
        z = coco.CoordinateAxis(name="z", unit=1e6)
        z.construct_uniform(-1, 1, 2)

        #
        # Initialize the grid using the constructed coordinate axes.
        #
        self.grid.set_coordinate_axes(x, y, z, ignore=z)

    def set_solver_parameters(self):
        """Set parameters required by the solver
        """
        self.solver.kernel.adiabatic_index = self.params.adiabatic_index
        self.solver.courant_number = 0.2

    def shear_layer_profile(self, y, ejecta_value, ambient_value):
        """Defines the profile of the shear layer.

        This function determines in which way the values transition initially
        from the ejecta to the ambient. The transition is a simple hyperbolic
        tangent similar to that of Otto & Fairfield (2000).
        """
        return ejecta_value + 0.5 * (ambient_value - ejecta_value) * (1.0 + np.tanh(y / self.params.tanh_scale))

    def velocity_perturbation(self, x, y):
        """Defines the velocity perturbation imposed initially.

        At y=0, a sinusoidal velocity profile for vy is chosen,
        vy(y = 0) = vamp sin(ax) where a is a constant determining the wavelength
        of the perturbation and vamp determines the amplitude of the
        vy perturbation. The perturbation is set to decrese away from the
        shear layer with a 1/cosh^2(by) profile, where b determines how fast
        the perturbation decays in the y-direction. Thus, we set

            vy = vamp sin(a*x)/cosh^2(b*y)

        The x-component of the velocity is determined by requiring the
        perturbation vector to be incompressible. This gives

            vx = c*vamp*cos(a*x)*tanh(b*y)/cosh^2(b*y)

        with c = -2.0*(b/a)
        """

        vamp = self.params.perturbation_amplitude
        a = self.params.perturbation_wavenumber
        b = self.params.perturbation_y_decay

        c = -2.0 * (b / a) * vamp

        delta_vx = c * np.cos(a * x) * np.tanh(b * y) * (1.0 / np.cosh(b * y)) ** 2
        delta_vy = vamp * np.sin(a * x) * (1.0 / np.cosh(b * y)) ** 2

        return delta_vx, delta_vy

    def set_initial_condition(self):
        """Set the values of the MHD variables from which the simulation starts
        """

        # Length of the simulation domain in the x-direction
        Lx = self.global_grid.extent.x

        # Set perturbation params
        self.params.perturbation_wavenumber = -2.0 * np.pi / Lx
        self.params.perturbation_y_decay = 2.0e-7  # 1/m

        #
        # Set cell-centered in-domain MHD quantities
        #
        for i, x in enumerate(self.grid.axis.x.centers):
            for j, y in enumerate(self.grid.axis.y.centers):

                #
                # The density, x-directed velocity and pressure of the
                # unperturbed plasma is initially given by a shear flow with a
                # given transition profile in the y-direction
                #
                P = self.shear_layer_profile(y, self.params.ejecta_pressure, self.params.ambient_pressure)

                rho = self.shear_layer_profile(y, self.params.ejecta_mass_density, self.params.ambient_mass_density)

                vx = self.shear_layer_profile(
                    y, -0.5 * self.params.shear_flow_speed, 0.5 * self.params.shear_flow_speed
                )

                # The KH instability is seeded by a perturbation in the
                # velocity
                dvx, dvy = self.velocity_perturbation(x, y)

                vx += dvx
                vy = dvy

                #
                # Set values on the grid
                #
                self.solver.kernel.mass_density()[i, j, :] = rho
                self.solver.kernel.pressure()[i, j, :] = P
                self.solver.kernel.momentum_density(0)[i, j, :] = rho * vx
                self.solver.kernel.momentum_density(1)[i, j, :] = rho * vy

        #
        # Set face-centered magnetic field components
        #
        self.solver.kernel.magnetic_field(1)[:, :, :] = 0.0

        for j, y in enumerate(self.grid.face_center_coords(0).y):
            Btot = self.shear_layer_profile(y, self.params.ejecta_B, self.params.ambient_B)

            if y > 0.0:
                self.solver.kernel.magnetic_field(0)[:, j, :] = -Btot * np.sin(self.params.ambient_B_inclination)
            else:
                self.solver.kernel.magnetic_field(0)[:, j, :] = -Btot * np.sin(self.params.ejecta_B_inclination)

        for j, y in enumerate(self.grid.face_center_coords(2).y):
            Btot = self.shear_layer_profile(y, self.params.ejecta_B, self.params.ambient_B)
            if y > 0.0:
                self.solver.kernel.magnetic_field(2)[:, j, :] = Btot * np.cos(self.params.ambient_B_inclination)
            else:
                self.solver.kernel.magnetic_field(2)[:, j, :] = Btot * np.cos(self.params.ejecta_B_inclination)

    def set_y_lower_ghost_cells(self):

        variables = (
            self.solver.kernel.mass_density(),
            self.solver.kernel.energy_density(),
            self.solver.kernel.pressure(),
            self.solver.kernel.momentum_density(0),
            self.solver.kernel.momentum_density(1),
            self.solver.kernel.magnetic_field(0),
            self.solver.kernel.magnetic_field(2),
        )

        for q in variables:
            q[:, 1, :] = q[:, 2, :]
            q[:, 0, :] = q[:, 3, :]

    def set_y_upper_ghost_cells(self):

        variables = (
            self.solver.kernel.mass_density(),
            self.solver.kernel.energy_density(),
            self.solver.kernel.pressure(),
            self.solver.kernel.momentum_density(0),
            self.solver.kernel.momentum_density(1),
            self.solver.kernel.magnetic_field(0),
            self.solver.kernel.magnetic_field(2),
        )

        for q in variables:
            q[:, -1, :] = q[:, -4, :]
            q[:, -2, :] = q[:, -3, :]

    def set_boundary_conditions(self):

        self.boundary.x.lower = "periodic"
        self.boundary.x.upper = "periodic"

        self.boundary.y.lower.ghost_cells = self.set_y_lower_ghost_cells
        self.boundary.y.upper.ghost_cells = self.set_y_upper_ghost_cells

        self.boundary.z.lower = "periodic"
        self.boundary.z.upper = "periodic"

    def add_vtk_output(self):
        def vtk_output_data():

            rho = self.solver.kernel.mass_density()

            B = np.array(
                (
                    self.solver.kernel.magnetic_field(0),
                    self.solver.kernel.magnetic_field(1),
                    self.solver.kernel.magnetic_field(2),
                )
            )

            return {
                "rho": self.solver.kernel.mass_density(),
                "vx": self.solver.kernel.momentum_density(0) / rho,
                "vy": self.solver.kernel.momentum_density(1) / rho,
                "vz": self.solver.kernel.momentum_density(2) / rho,
                "P": self.solver.kernel.pressure(),
                "B": B,
            }

        # Add output event
        self.events.add(
            coco.io.vtk.VTKWriteEvent(
                self, vtk_output_data, interval=10, base_name="output/corona_kh", centering="nodal"
            )
        )


if __name__ == "__main__":

    #
    # Parse command line arguments
    #
    parser = argparse.ArgumentParser()

    parser.add_argument("--num_cells", default=128, type=int, help="Number of cells in x and y (default: %(default)s)")

    parser.add_argument("--t_stop", default=400.0, type=float, help="Time when to stop (default: %(default)s)")

    args = parser.parse_args()

    # Instantiate simulation
    sim = CoronalKelvinHelmholtzSimulation()

    # Set grid coordinates
    sim.set_grid(args.num_cells)

    # Initialize the framework
    sim.initialize()

    # Set the parameters required by the solver
    sim.set_solver_parameters()

    # Set boundary conditions to use
    sim.set_boundary_conditions()

    # Construct initial state of simulation
    sim.set_initial_condition()

    # Add VTK output
    sim.add_vtk_output()

    # Run the simulation until t=t_stop
    sim.run(t_stop=args.t_stop)
