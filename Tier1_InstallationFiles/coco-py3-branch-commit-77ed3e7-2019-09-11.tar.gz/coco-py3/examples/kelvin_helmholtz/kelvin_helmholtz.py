#!/usr/bin/env python
#
# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Hydrodynamic Kelvin-Helmholtz instability test.
"""

import argparse

import numpy as np

import coco
import coco.io.vtk
import coco.sim


class KelvinHelmholtzSimulation(coco.sim.IdealHydrodynamicsSimulation):
    """Hydrodynamic Kelvin-Helmholtz instability test.

    This example sets up a shear flow initiating the KH instability. The
    precise form of the setup is the 2D "well-posed" problem detailed in
    `McNally et al. (2012)`_ (henceforth denoted M12).

    .. _McNally et al. (2012):
       https://doi.org/10.1088/0067-0049/201/2/18
    """

    def __init__(self, **kwargs):

        coco.sim.IdealHydrodynamicsSimulation.__init__(self, **kwargs)

        #
        # Model parameters
        #
        self.params.adiabatic_index = 5.0 / 3.0

    def set_grid(self, num_cells=256):
        """Set coordinates of the computational grid

        Args:
            num_cells : Number of cells in x and y
        """

        #
        # Construct coordinates of the edges of the in-domain cells.
        # In this case, a uniform grid is chosen in each direction
        #

        x = coco.CoordinateAxis(name="x")
        x.construct_uniform(0, 1, num_cells + 1)

        y = coco.CoordinateAxis(name="y")
        y.construct_uniform(0, 1, num_cells + 1)

        # For 2D simulations, need at least one cell in the ignorable
        # direction
        z = coco.CoordinateAxis(name="z")
        z.construct_uniform(-0.05, 0.05, 2)

        #
        # Initialize the grid using the constructed coordinate axes.
        #
        self.grid.set_coordinate_axes(x, y, z, ignore=z)

    def set_solver_parameters(self):
        """Set parameters required by the solver
        """
        self.solver.kernel.adiabatic_index = self.params.adiabatic_index
        self.solver.courant_number = 0.2

    def shear_layer_profile(self, y, v1, v2):
        """Defines the profile of the shear layer, eq. (1) and (3) in M12
        generalized to a given quantity v.
        """

        # Make sure y is in [0, 1]
        y = np.mod(y, 1.0)

        L = 0.025
        vm = 0.5 * (v1 - v2)

        if (y < 0.25) and (y >= 0.0):
            v = v1 - vm * np.exp((y - 0.25) / L)
        elif (y < 0.5) and (y >= 0.25):
            v = v2 + vm * np.exp((-y + 0.25) / L)
        elif (y < 0.75) and (y >= 0.5):
            v = v2 + vm * np.exp(-(0.75 - y) / L)
        elif (y < 1.0) and (y >= 0.75):
            v = v1 - vm * np.exp(-(y - 0.75) / L)

        return v

    def set_initial_condition(self):
        """Set the values of the MHD variables from which the simulation starts
        """

        #
        # Set cell-centered in-domain MHD quantities
        #
        for i, x in enumerate(self.grid.axis.x.centers):
            for j, y in enumerate(self.grid.axis.y.centers):

                #
                # The density and x-directed velocity of the unperturbed plasma
                # is initially given by a shear flow with a given transition
                # profile in the y-direction
                #
                rho = self.shear_layer_profile(y, 1.0, 2.0)
                vx = self.shear_layer_profile(y, 0.5, -0.5)

                # The y-directed velocity contains the perturbation
                vy = 0.01 * np.sin(4.0 * np.pi * x)

                # Constant thermal pressure
                P = 2.5

                #
                # Set values on the grid
                #
                self.solver.kernel.mass_density()[i, j, :] = rho
                self.solver.kernel.pressure()[i, j, :] = P
                self.solver.kernel.momentum_density(0)[i, j, :] = rho * vx
                self.solver.kernel.momentum_density(1)[i, j, :] = rho * vy

    def set_boundary_conditions(self):

        self.boundary.x.lower = "periodic"
        self.boundary.x.upper = "periodic"

        self.boundary.y.lower = "periodic"
        self.boundary.y.upper = "periodic"

        self.boundary.z.lower = "periodic"
        self.boundary.z.upper = "periodic"

    def add_vtk_output(self):
        def vtk_output_data():

            rho = self.solver.kernel.mass_density()

            return {
                "rho": self.solver.kernel.mass_density(),
                "vx": self.solver.kernel.momentum_density(0) / rho,
                "vy": self.solver.kernel.momentum_density(1) / rho,
                "vz": self.solver.kernel.momentum_density(2) / rho,
                "P": self.solver.kernel.pressure(),
            }

        # Add output event
        self.events.add(
            coco.io.vtk.VTKWriteEvent(self, vtk_output_data, interval=0.1, base_name="output/kh", centering="zonal")
        )


if __name__ == "__main__":

    #
    # Parse command line arguments
    #
    parser = argparse.ArgumentParser()

    parser.add_argument("--num_cells", default=256, type=int, help="Number of cells in x and y (default: %(default)s)")

    parser.add_argument("--t_stop", default=2.0, type=float, help="Time at when to stop (default: %(default)s)")

    args = parser.parse_args()

    # Instantiate simulation
    sim = KelvinHelmholtzSimulation()

    # Set grid coordinates
    sim.set_grid(int(args.num_cells))

    # Initialize the framework
    sim.initialize()

    # Set the parameters required by the solver
    sim.set_solver_parameters()

    # Set boundary conditions to use
    sim.set_boundary_conditions()

    # Construct initial state of simulation
    sim.set_initial_condition()

    # Add VTK output
    sim.add_vtk_output()

    # Run the simulation until t=t_stop
    sim.run(t_stop=args.t_stop)
