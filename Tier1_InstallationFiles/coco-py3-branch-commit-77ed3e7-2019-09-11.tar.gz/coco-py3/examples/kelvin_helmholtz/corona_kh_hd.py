#!/usr/bin/env python
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Kelvin-Helmholtz instability in the solar corona.
"""

import numpy as np

import coco
import coco.io.vtk
import coco.sim


class CoronalKelvinHelmholtzSimulation(coco.sim.IdealHydrodynamicsSimulation):
    """Simulation setup to study the Kelvin-Helmholtz instability using
    solar coronal parameters.

    Currently, the magnetic field is not included. The parameters are in part
    inspired by `Nykyri et al. (2013)`_ (henceforth denoted N13)

    .. _Nykyri et al. (2013):
       https://doi.org/10.1002/grl.50807
    """

    def __init__(self, **kwargs):

        coco.sim.IdealHydrodynamicsSimulation.__init__(self, **kwargs)

        #
        # Model parameters
        #
        self.params.adiabatic_index = 5.0 / 3.0
        self.params.mean_molecular_mass = 0.5 * coco.constants.proton_mass

        #
        # Parameters of the ambient corona, SI
        #

        # These are taken from N13
        self.params.ambient_number_density = 7.1e8 * 1e6  # m^{-3}
        self.params.ambient_temperature = 4.5e6  # K

        self.params.ambient_mass_density = self.params.ambient_number_density * self.params.mean_molecular_mass

        self.params.ambient_pressure = (
            self.params.ambient_number_density * self.params.ambient_temperature * coco.constants.kB
        )
        # NOTE: the above does not include the 2 as in N13

        #
        # Parameters of the ejecta sheath, SI
        #

        # Here, a density jump is specified
        self.params.ejecta_number_density = 2.0 * 7.1e8 * 1e6  # m^{-3}

        # To keep the pressure constant, the temperature needs to be
        # correspondingly lowered
        self.params.ejecta_temperature = 0.5 * 4.5e6  # K

        self.params.ejecta_mass_density = self.params.ejecta_number_density * self.params.mean_molecular_mass

        self.params.ejecta_pressure = (
            self.params.ejecta_number_density * self.params.ejecta_temperature * coco.constants.kB
        )

        #
        # Shear flow speed, i.e. speed of the ejecta
        #
        self.params.shear_flow_speed = 680.0 * 1e3  # m/s

        #
        # Stength of the velocity perturbation
        #
        self.params.perturbation_amplitude = 0.01 * self.params.shear_flow_speed

        #
        # Width of shear layer
        #
        self.params.shear_layer_width = 2.0e6

        # Argument to tanh() function in shear profile
        self.params.tanh_scale = 0.5 * self.params.shear_layer_width / np.arctanh(0.95)

    def set_grid(self):
        """Set coordinates of the computational grid
        """

        #
        # Construct coordinates of the edges of the in-domain cells.
        # In this case, a uniform grid is chosen in each direction
        #
        x = coco.CoordinateAxis(name="x", unit=1e6)
        x.construct_uniform(-50, 50, 128 + 1)

        y = coco.CoordinateAxis(name="y", unit=1e6)
        y.construct_uniform(-25, 25, 128 + 1)

        z = coco.CoordinateAxis(name="z", unit=1e6)
        z.construct_uniform(-1, 1, 2)

        #
        # Initialize the grid using the constructed coordinate axes.
        #
        self.grid.set_coordinate_axes(x, y, z)

    def set_solver_parameters(self):
        """Set parameters required by the solver
        """
        self.solver.kernel.adiabatic_index = self.params.adiabatic_index
        self.solver.courant_number = 0.2
        self.solver.kernel.ignore_dimension = 2

    def shear_layer_profile_prev(self, y, v1, v2):
        """Defines the profile of the shear layer, eq. (1) and (3) in M12
        generalized to a given quantity v.
        """

        # Make sure y is in [0, 1]

        y = np.mod(y, 1.0)

        L = 0.025
        vm = 0.5 * (v1 - v2)

        if (y < 0.25) and (y >= 0.0):
            v = v1 - vm * np.exp((y - 0.25) / L)
        elif (y < 0.5) and (y >= 0.25):
            v = v2 + vm * np.exp((-y + 0.25) / L)
        elif (y < 0.75) and (y >= 0.5):
            v = v2 + vm * np.exp(-(0.75 - y) / L)
        elif (y < 1.0) and (y >= 0.75):
            v = v1 - vm * np.exp(-(y - 0.75) / L)

        return v

    def shear_layer_profile(self, y, ejecta_value, ambient_value):
        """Defines the profile of the shear layer.

        This function determines in which way the values transition initially
        from the ejecta to the ambient.
        """

        return ejecta_value + 0.5 * (ambient_value - ejecta_value) * (1.0 + np.tanh(y / self.params.tanh_scale))

    def set_initial_condition(self):
        """Set the values of the MHD variables from which the simulation starts
        """

        # Length of the simulation domain in the x-direction
        Lx = self.global_grid.extent.x

        #
        # Set cell-centered in-domain MHD quantities
        #
        for i, x in enumerate(self.grid.axis.x.centers):
            for j, y in enumerate(self.grid.axis.y.centers):

                #
                # The density, x-directed velocity and pressure of the
                # unperturbed plasma is initially given by a shear flow with a
                # given transition profile in the y-direction
                #

                P = self.shear_layer_profile(y, self.params.ejecta_pressure, self.params.ambient_pressure)

                rho = self.shear_layer_profile(y, self.params.ejecta_mass_density, self.params.ambient_mass_density)

                vx = self.shear_layer_profile(
                    y, -0.5 * self.params.shear_flow_speed, 0.5 * self.params.shear_flow_speed
                )

                # The KH instability is seeded by a perturbation in the
                # y-directed speed
                vy = self.params.perturbation_amplitude * np.sin(4.0 * np.pi * x / Lx)

                #
                # Set values on the grid
                #
                self.solver.kernel.mass_density()[i, j, :] = rho
                self.solver.kernel.pressure()[i, j, :] = P
                self.solver.kernel.momentum_density(0)[i, j, :] = rho * vx
                self.solver.kernel.momentum_density(1)[i, j, :] = rho * vy

    def set_custom_ghost_data_prior_to_dUdt(self):

        #
        # Set boundary conditions
        #

        # Periodic in x and z
        variables = (
            self.solver.kernel.mass_density(),
            self.solver.kernel.energy_density(),
            self.solver.kernel.pressure(),
            self.solver.kernel.momentum_density(0),
            self.solver.kernel.momentum_density(1),
        )

        for q in variables:
            q[0:2, :, :] = q[-4:-2, :, :]
            q[-2::, :, :] = q[2:4, :, :]

            q[:, :, 0:2] = q[:, :, -4:-2]
            q[:, :, -2::] = q[:, :, 2:4]

        # Symmetric in y
        variables = (
            self.solver.kernel.mass_density(),
            self.solver.kernel.energy_density(),
            self.solver.kernel.pressure(),
            self.solver.kernel.momentum_density(0),
            self.solver.kernel.momentum_density(1),
        )

        for q in variables:
            q[:, 1, :] = q[:, 2, :]
            q[:, 0, :] = q[:, 3, :]

            q[:, -1, :] = q[:, -4, :]
            q[:, -2, :] = q[:, -3, :]

    def set_boundary_conditions(self):
        pass

    def add_vtk_output(self):
        def vtk_output_data():

            rho = self.solver.kernel.mass_density()

            return {
                "rho": self.solver.kernel.mass_density(),
                "vx": self.solver.kernel.momentum_density(0) / rho,
                "vy": self.solver.kernel.momentum_density(1) / rho,
                "vz": self.solver.kernel.momentum_density(2) / rho,
                "P": self.solver.kernel.pressure(),
            }

        # Add output event
        self.events.add(
            coco.io.vtk.VTKWriteEvent(
                self, vtk_output_data, interval=10, base_name="output/corona_kh_hd", centering="zonal"
            )
        )


if __name__ == "__main__":

    # Instantiate simulation
    sim = CoronalKelvinHelmholtzSimulation()

    # Set grid coordinates
    sim.set_grid()

    # Initialize the framework
    sim.initialize()

    # Set the parameters required by the solver
    sim.set_solver_parameters()

    # Set boundary conditions to use
    # sim.set_boundary_conditions()

    # Construct initial state of simulation
    sim.set_initial_condition()

    # Add VTK output
    sim.add_vtk_output()

    # Run the simulation until t=t_stop
    sim.run(t_stop=400.0)
