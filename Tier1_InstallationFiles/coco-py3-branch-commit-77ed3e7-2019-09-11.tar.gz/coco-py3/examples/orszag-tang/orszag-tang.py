#!/usr/bin/env python
#
# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""MHD Orszag Tang vortex test.
"""

import argparse
import datetime
import time

import numpy as np

import coco.core
import coco.io.vtk
import coco.sim


class OrszagTangSimulation(coco.sim.IdealMagnetohydrodynamicsSimulation):
    """MHD Orszag Tang vortex test.

    This is a periodic 2D test wherein a vortex flow is initialized in a
    medium with a uniform density and pressure. It has become a standard test
    for MHD codes. The problem is useful as it allows to study how the MHD
    solver copes with shocks and shock-shock interactions as the flow
    transitions into a supersonic turbulent regime. The setup here follows that
    used in the PLUTO code, see e.g. `Mignone et al. (2007)`_.

    .. _Mignone et al. (2007):
       http://dx.doi.org/10.1086/513316
    """

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        #
        # Model parameters
        #
        self.params.adiabatic_index = 5.0 / 3.0
        self.params.B0 = 1.0

    def set_grid(self, num_cells=64):
        """Defines the coordinates of the computational domain.
        """

        #
        # Construct coordinates of the edges of the in-domain cells.
        #
        x = coco.core.CoordinateAxis(name="x")
        x.construct_uniform(0.0, 2.0, num_cells + 1)
        x.coordinates *= np.pi

        y = coco.core.CoordinateAxis(name="y")
        y.construct_uniform(0.0, 2.0, num_cells + 1)
        y.coordinates *= np.pi

        z = coco.core.CoordinateAxis(name="z")
        z.construct_uniform(-0.25, 0.25, 2)

        #
        # Initialize the grid using the constructed axes.
        #
        self.grid.set_coordinate_axes(x, y, z, ignore=z)

    def set_solver_parameters(self):
        """Set parameters required by the solver
        """
        self.solver.kernel.adiabatic_index = self.params.adiabatic_index
        self.solver.kernel.inv_mu0 = 1.0
        self.solver.courant_number = 0.1

    def Az(self, x, y):
        """Magnetic vector potential of initial magnetic field.

        The initial magnetic field is \vec{B} = B0*(-sin(y), sin(2x), 0) and can be
        computed from the vector potential A_z = B0*(cos(y) + 0.5*cos(2x))
        """
        return self.params.B0 * (np.cos(y) + 0.5 * np.cos(2.0 * x))

    def set_initial_condition(self):
        """Set the values of the MHD variables from which the simulation starts
        """

        #
        # Set cell-centered MHD quantities
        #

        # Grid coordinates of cell centers
        x, y = np.meshgrid(self.grid.axis.x.centers, self.grid.axis.y.centers, indexing="ij")

        # Velocity: vortex flow
        vx = -np.sin(y)
        vy = np.sin(x)

        # Mass density & pressure: uniform
        P = 5.0 / 3.0
        rho = 25.0 / 9.0

        # Initialize with same solution for all z-planes
        for k, z in enumerate(self.grid.axis.z.centers):

            self.solver.kernel.pressure()[:, :, k] = P
            self.solver.kernel.mass_density()[:, :, k] = rho

            self.solver.kernel.momentum_density(0)[:, :, k] = rho * vx
            self.solver.kernel.momentum_density(1)[:, :, k] = rho * vy

        #
        # Initialize magnetic field using the vector potential
        #
        delta_x = self.grid.spacing.x
        delta_y = self.grid.spacing.y

        # Set Bx
        for i, x in enumerate(self.grid.face_center_coords(0).x):
            for j, y in enumerate(self.grid.face_center_coords(0).y):
                for k, z in enumerate(self.grid.face_center_coords(0).z):
                    dy = delta_y[j]
                    self.solver.kernel.magnetic_field(0)[i, j, k] = (
                        self.Az(x, y + 0.5 * dy) - self.Az(x, y - 0.5 * dy)
                    ) / dy

        # Set By
        for i, x in enumerate(self.grid.face_center_coords(1).x):
            for j, y in enumerate(self.grid.face_center_coords(1).y):
                for k, z in enumerate(self.grid.face_center_coords(1).z):
                    dx = delta_x[i]
                    self.solver.kernel.magnetic_field(1)[i, j, k] = (
                        -(self.Az(x + 0.5 * dx, y) - self.Az(x - 0.5 * dx, y)) / dx
                    )

    def set_boundary_conditions(self):

        self.boundary.x.lower = "periodic"
        self.boundary.x.upper = "periodic"

        self.boundary.y.lower = "periodic"
        self.boundary.y.upper = "periodic"

        self.boundary.z.lower = "periodic"
        self.boundary.z.upper = "periodic"

    def add_vtk_output_event(self):
        def vtk_output_data():

            rho = self.solver.kernel.mass_density()

            Bx = self.solver.kernel.magnetic_field(0)
            By = self.solver.kernel.magnetic_field(1)
            Bz = self.solver.kernel.magnetic_field(2)
            B = np.array((Bx, By, Bz))

            return {
                "rho": rho,
                "vx": self.solver.kernel.momentum_density(0) / rho,
                "vy": self.solver.kernel.momentum_density(1) / rho,
                "vz": self.solver.kernel.momentum_density(2) / rho,
                "P": self.solver.kernel.pressure(),
                "B": B,
            }

        #
        # Add output event with the given parameters
        #
        self.events.add(
            coco.io.vtk.VTKWriteEvent(self, vtk_output_data, interval=0.1, base_name="output/ot", centering="nodal")
        )


if __name__ == "__main__":

    #
    # Parse command line arguments
    #
    parser = argparse.ArgumentParser()

    parser.add_argument("--num_cells", default=64, type=int, help="Number of cells in x and y (default: %(default)s)")

    parser.add_argument("--t_stop", default=3.1, type=float, help="Time at when to stop (default: %(default)s)")

    args = parser.parse_args()

    # Instantiate simulation
    sim = OrszagTangSimulation()

    # Set grid coordinates
    sim.set_grid(args.num_cells)

    # Initialize the framework
    sim.initialize()

    # Set the parameters required by the solver
    sim.set_solver_parameters()

    # Set boundary conditions to use
    sim.set_boundary_conditions()

    # Construct initial state of simulation
    sim.set_initial_condition()

    # Add output
    sim.add_vtk_output_event()

    # Run simulation

    if sim.grid.rank == 0:
        start = time.time()

    sim.run(t_stop=args.t_stop)

    if sim.grid.rank == 0:
        print("Elapsed:", datetime.timedelta(seconds=time.time() - start))
