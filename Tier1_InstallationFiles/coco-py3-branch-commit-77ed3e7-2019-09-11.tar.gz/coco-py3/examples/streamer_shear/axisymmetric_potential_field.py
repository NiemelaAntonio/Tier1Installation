# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


import scipy as sp
import scipy.constants
import scipy.integrate
import scipy.special


class AxisymmetricPotentialMagneticField(object):
    """Compute potential magnetic field in a spherical shell assuming azimuthal symmetry.

    Computes the scalar potential that solves the Laplace equation in a
    spherical setting with symmetry about the azimuth and given Neumann boundary
    conditions on the inner sphere. The solution is obtained using a expansion
    in Legendre polynomials given an analytic expression for the Neumann boundary
    condition. See the notebook for mathematical derivation.

    Note: for most applications, it is probably better to use a full-blown
    spherical harmonic-based Laplace-solver instead.

    Args:
        r0  :  Height of inner radial boundary
        Rss :  Source surface radius
        max_order : Maximum order of expansion
        mode      : PFSS or regular
    """

    def __init__(self, r0=1.0, Rss=2.5, max_order=10, mode="regular"):

        self.r0 = r0
        self.expansion_order = max_order
        self.source_surface_radius = Rss

        if mode.upper() == "PFSS":
            self.Br = self.Br_pfss
            self.Bclt = self.Bclt_pfss

        else:
            self.Br = self.Br_regular
            self.Bclt = self.Bclt_regular

    def Br_regular(self, r, clt):
        """Compute radial magnetic field at given point using the regular model
        """

        x = self.r0 / r

        cos_colat = sp.cos(clt)

        Br = 0.0
        for n in range(len(self.coefficients)):

            bn = self.coefficients[n]
            xpow = x ** (n + 2)

            Pn = scipy.special.eval_legendre(n, cos_colat)

            Br += bn * xpow * Pn

        return Br

    def Bclt_regular(self, r, clt):
        """Compute magnetic field at given point using the regular model
        """

        x = self.r0 / r

        cos_colat = sp.cos(clt)

        delta_colat = 1.0e-6
        cos_dcolat = sp.cos(clt + delta_colat)

        Bt = 0.0
        for n in range(len(self.coefficients)):
            bn = self.coefficients[n]
            xpow = x ** (n + 2)

            Pn = scipy.special.eval_legendre(n, cos_colat)
            Pn_delta = scipy.special.eval_legendre(n, cos_dcolat)

            Bt += -(bn / (n + 1.0)) * xpow * (Pn_delta - Pn) / delta_colat

        return Bt

    def Br_pfss(self, r, clt):
        """Compute radial component of magnetic field at given point using the PFSS model
        """

        x = self.r0 / r
        Rss = self.source_surface_radius

        cos_colat = sp.cos(clt)

        Br = 0.0
        for n in range(len(self.coefficients)):

            bn = self.coefficients[n]

            coeff = bn / (1.0 + n * (1.0 + (self.r0 / Rss) ** (2 * n + 1)))
            xpow = x ** (n + 2)
            pfsspow = x * ((self.r0 / Rss) ** (n + 1)) * ((r / Rss) ** n)

            Pn = scipy.special.eval_legendre(n, cos_colat)

            Br += coeff * ((n + 1.0) * xpow + n * pfsspow) * Pn

        return Br

    def Bclt_pfss(self, r, clt):
        """Compute colat component of magnetic field at given point using the PFSS model
        """

        x = self.r0 / r
        Rss = self.source_surface_radius

        cos_colat = sp.cos(clt)

        delta_colat = 1.0e-6
        cos_dcolat = sp.cos(clt + delta_colat)

        Bt = 0.0
        for n in range(len(self.coefficients)):

            bn = self.coefficients[n]

            # Rather arbitrary names..
            coeff = bn / (1.0 + n * (1.0 + (self.r0 / Rss) ** (2 * n + 1)))
            xpow = x ** (n + 2)
            pfsspow = x * ((self.r0 / Rss) ** (n + 1)) * ((r / Rss) ** n)

            Pn = scipy.special.eval_legendre(n, cos_colat)
            Pn_delta = scipy.special.eval_legendre(n, cos_dcolat)
            dPndclt = (Pn_delta - Pn) / delta_colat

            Bt += -coeff * (xpow - pfsspow) * dPndclt

        return Bt

    def compute(self):
        """Compute the model
        """

        #
        # Compute all b_n up to the given order
        #
        self.coefficients = sp.zeros(self.expansion_order)

        for n in range(0, self.expansion_order):
            self.coefficients[n] = self.compute_expansion_coefficient(n)

    def coefficient_integrand(self, colat, n):
        """Integrand of b_n
        """
        return sp.sin(colat) * scipy.special.eval_legendre(n, sp.cos(colat)) * self.M(colat)

    def compute_expansion_coefficient(self, n):
        """Compute coefficient of the Legendre expansion

        Computes the b_n coefficient by integrating the magnetogram M(clt).
        This is done employing standard numerical quadrature.

        Args:
            n  : Expansion degree/order
        """

        # NOTE: Number of clt grid points completely arbitrary
        clt = sp.linspace(1e-12, sp.pi - 1e-12, 2049)
        func = sp.zeros(len(clt))

        for i, th in enumerate(clt):
            func[i] = self.coefficient_integrand(th, n)

        return 0.5 * (2.0 * n + 1.0) * scipy.integrate.simps(func, dx=clt[1] - clt[0])

        # return (0.5*(2.0*n+1.0)/self.inner_term(n))*scipy.integrate.simps(func, dx = clt[1]-clt[0])
        # return (0.5*(2.0*n+1.0)/self.inner_term(n))*scipy.integrate.quad(self.coefficient_integrand, 0, sp.pi, args=(n))[0]
