#!/usr/bin/env python
#
# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""MHD simulation of CME formation by shearing of solar wind streamers.

This is a comprehensive example to demonstrate how the code could be used in an
actual research-relevant case. Depending on the inputs in the configuration
file, there are several distinct models of varying complexity that can be run.
The models are related by the fact that they all model (somewhat simplistically)
the coronal environment including solar wind flows, and depending on the case,
also the formation of coronal mass ejections via photospheric shear flows. All
of the models are axisymmetric (i.e. no longitudinal dependence). Please refer
to the description in the corresponding cfg for an overview of what each model
does.
"""

import argparse
import configparser

import numpy as np

import axisymmetric_potential_field as pot
import coco
import coco.core.constants as constants
import coco.io.vtk
import coco.sim

# Import local files
import initial_condition


class CoronalShearingSimulation(coco.sim.IdealMagnetohydrodynamicsSimulation):
    """Solar coronal magnetic field evolution due to shear flow.

    Computes the dynamics of the corona subject to a boundary shear flow.
    Details of the computation depends heavily on the provided configuration
    file.

    Args:
        config_file_name (str) :  Configuration file
    """

    def __init__(self, config_file_name):

        super().__init__()

        #
        # Read configuration file
        #
        self.config = configparser.ConfigParser()
        self.config.read(config_file_name)

        #
        # Get model parameters from configuration file
        #

        # Mean molecular mass, kg
        self.params.mean_molecular_mass = self.config.getfloat("Corona", "mean_molecular_mass")
        self.params.mean_molecular_mass *= constants.proton_mass

        # Reference height, and height of lower radial boundary, m
        self.params.r0 = self.config.getfloat("Corona", "reference_radius")
        self.params.r0 *= constants.solar_radius

        # Mass density at reference height, kg/m^3
        self.params.rho0 = self.config.getfloat("Corona", "mass_density")

        # Reference coronal temperature, K
        self.params.T0 = self.config.getfloat("Corona", "temperature")

        # Polar field strength at r=r0, T
        self.params.B0 = self.config.getfloat("MagneticField", "B0")

        # Adiabatic index
        self.params.adiabatic_index = self.config.getfloat("Corona", "adiabatic_index")

    def set_grid(self):
        """Construct computational grid
        """

        #
        # Select spherical geometry
        #
        self.grid.geometry = "spherical"

        Rs = constants.solar_radius

        #
        # Construct coordinates of the computational domain
        #

        # Radial coordinates: stretched
        r = coco.CoordinateAxis(name="r", unit=Rs)

        r.construct_constant_ratio(
            self.params.r0 / Rs,  # start
            self.config.getfloat("Grid", "outer_radius"),
            self.config.getint("Grid", "num_radial") + 1,
            self.config.getfloat("Grid", "dr_at_start"),
        )

        # Co-latitudinal coordinates: uniform
        clt = coco.CoordinateAxis(name="clt")

        latitudinal_span = self.config.getfloat("Grid", "latitudinal_span")
        clt.construct_uniform(
            90.0 - 0.5 * latitudinal_span,
            90.0 + 0.5 * latitudinal_span,
            self.config.getint("Grid", "num_latitudinal") + 1,
        )
        clt.coordinates *= np.pi / 180.0

        # Longitudinal coordinates: uniform
        # The longitude is a "dummy" axis as the simulation is axisymmetric
        lon = coco.CoordinateAxis(name="lon")
        lon.construct_uniform(-45, 45, 3)

        lon.coordinates *= np.pi / 180.0

        #
        # Set the axes
        #
        self.grid.set_coordinate_axes(r, clt, lon, ignore=lon)

    def set_solver_parameters(self):
        """Set parameters intrinsic to the physical model
        """
        self.solver.kernel.adiabatic_index = self.params.adiabatic_index
        self.solver.kernel.gravity = True

    def set_spherically_symmetric(self, grid_quantity, function):
        """Computes a cell-centered variable that is a function of radius and
        repeats it for all latitudes and longitudes of the computational domain.
        """

        # Compute spherically symmetric variable
        var = function(self.grid.axis.r.centers)

        # Shape to use in the repetition
        tile_shape = (len(self.grid.axis.lon.centers), len(self.grid.axis.clt.centers), 1)

        # Repeat in all directions
        grid_quantity[:, :, :] = np.tile(var, tile_shape).T

    def set_initial_condition(self):
        """Computes the initial state of the simulation.

        There are two distinct initial states: either a magnetohydrostatic
        equilibirium, or alternatively an out-of-equilibrium state consisting
        of a Parker solar wind solution for the hydrodynamic variables together
        with a potential magnetic field. The latter is used for obtaining a
        steady state solar wind solution, while the former is used for the
        shearing simulations that do not include a solar wind.
        """

        #
        # Select magnetic field model
        #
        magnetic_field_model_type = self.config.get("MagneticField", "model")

        if magnetic_field_model_type == "dipole":
            magnetic_field = initial_condition.DipoleMagneticField(r0=self.params.r0, B0=self.params.B0)
        elif magnetic_field_model_type == "pfss_dipole":
            magnetic_field = pot.AxisymmetricPotentialMagneticField(
                r0=self.params.r0, Rss=self.grid.axis.r.coordinates[-1], max_order=20, mode="PFSS"
            )

            magnetic_field.M = lambda clt: self.params.B0 * np.cos(clt)

            magnetic_field.compute()

        else:
            raise ValueError("Unknown magnetic field model type")

        #
        # Select hydro model: wind or static
        #
        model_type = self.config.get("Run", "type")

        if model_type == "solar wind relaxation":
            raise ValueError("This model has not been implemented yet")
            hydro = initial_condition.ParkerIsothermalSolarWind()
        elif model_type == "static shearing":
            hydro = initial_condition.IsothermalHydrostaticEquilibirum()
        else:
            raise ValueError("Unknown hydro model type")

        # Store initial magnetic field model (needed in boundary routines)
        self.initial_magnetic_field = magnetic_field

        #
        # Set magnetic field
        #
        # TODO: use vector potential!

        # Br
        for i, r in enumerate(self.grid.face_center_coords(0).r):
            for j, clt in enumerate(self.grid.face_center_coords(0).clt):
                self.solver.kernel.magnetic_field(0)[i, j, :] = magnetic_field.Br(r, clt)

        # Bclt
        for i, r in enumerate(self.grid.face_center_coords(1).r):
            for j, clt in enumerate(self.grid.face_center_coords(1).clt):
                self.solver.kernel.magnetic_field(1)[i, j, :] = magnetic_field.Bclt(r, clt)

        #
        # Set spherically symmetric mass density, pressure and radial momentum density.
        #
        self.set_spherically_symmetric(self.solver.kernel.mass_density(), hydro.mass_density)
        self.set_spherically_symmetric(self.solver.kernel.pressure(), hydro.pressure)
        self.set_spherically_symmetric(self.solver.kernel.momentum_density(0), hydro.radial_momentum_density)

    def add_vtk_output_event(self):
        """Triggers VTK output
        """

        def vtk_output_data():

            rho = self.solver.kernel.mass_density()

            # Number density (cm^-3)
            n = 1e-6 * rho / self.params.mean_molecular_mass

            # Velocity components (km/s)
            v1 = 1e-3 * self.solver.kernel.momentum_density(0) / rho
            v2 = 1e-3 * self.solver.kernel.momentum_density(1) / rho
            v3 = 1e-3 * self.solver.kernel.momentum_density(2) / rho
            v = np.array((v1, v2, v3))

            # Magnetic field in units of Gauss
            B1 = 1e4 * self.solver.kernel.magnetic_field(0)
            B2 = 1e4 * self.solver.kernel.magnetic_field(1)
            B3 = 1e4 * self.solver.kernel.magnetic_field(2)
            B = np.array((B1, B2, B3))

            return {"n": n, "v": v, "B": B, "P": self.solver.kernel.pressure()}

        #
        # Add output event with the given parameters
        #
        one_minute = 60.0

        output_dir = self.config.get("Output", "directory")
        base_name = self.config.get("Output", "base_name")

        interval = self.config.getfloat("Output.VTK", "interval")
        centering = self.config.get("Output.VTK", "centering")

        self.events.add(
            coco.io.vtk.VTKWriteEvent(
                self,
                vtk_output_data,
                interval=interval * one_minute,
                base_name=output_dir + base_name,
                centering=centering,
            )
        )

    def set_boundary_conditions(self):
        """Defines boundary conditions
        """

        self.boundary.r.lower.ghost_cells = self.set_inner_radial_ghost_cells
        self.boundary.r.lower.flux = self.set_inner_radial_electric_field
        self.boundary.r.upper.ghost_cells = self.set_outer_radial_ghost_cells

        self.boundary.clt.lower.ghost_cells = self.set_lower_colat_ghost_cells
        self.boundary.clt.upper.ghost_cells = self.set_upper_colat_ghost_cells

        self.boundary.lon.lower = "periodic"
        self.boundary.lon.upper = "periodic"

    def shear_flow(self, colat):
        """Defines the shear flow profile and magnitude
        """

        latitude = 0.5 * np.pi - colat

        return 100.0e3 * np.exp(-(latitude ** 2) / 0.1) * np.sin(latitude)

    def set_inner_radial_electric_field(self):
        """Set the horizontal electric field components (Eclt, Elon) at the
        inner radial boundary
        """

        # Shear flow vlon at inner boundary gives rise to electric field
        # E = - v x B = - vlon e_phi x (Br e_r + Bth e_th)
        #   = -vlon*( Br e_th  -  Bth e_r )
        # i.e.
        # Eclt = -vlon*Br
        # Ephi = 0 ==> radial magnetic field stays fixed at boundary

        for j, clt in enumerate(self.grid.edge_center_coords(1).clt):
            for k, lon in enumerate(self.grid.edge_center_coords(1).lon):
                self.solver.kernel.electric_field(1)[2, j, k] = -self.shear_flow(clt) * self.initial_magnetic_field.Br(
                    self.params.r0, clt
                )

        self.solver.kernel.electric_field(2)[0, :, :] = 0.0

    def set_outer_radial_ghost_cells(self):
        """Implements the outer radial boundary condition
        """

        model_type = self.config.get("Run", "type")

        if model_type == "solar wind relaxation":

            # r   = self.grid.axis.r.centers
            # rho = self.solver.kernel.mass_density()
            # P   = self.solver.kernel.pressure()
            # mr  = self.solver.kernel.momentum_density(0)

            # Boundary conditions:
            #
            # vr   : extrapolate
            # vclt : extrapolate
            # T    : extrapolate
            # rho  : constant radial mass flux r^2 rho vr = const
            # P    : P = rho k T / m

            # Radial speed at two last points
            vr_i = (mr[-4, :, :] / rho[-4, :, :], mr[-3, :, :] / rho[-3, :, :])

            # Radial speed at ghost cells
            vr_g = (2.0 * vr_i[1] - vr_i[0], 3.0 * vr_i[1] - 2.0 * vr_i[0])

            # Temperature at two last points
            c = self.params.mean_molecular_mass / constants.kB
            T_i = (c * P[-4, :, :] / rho[-4, :, :], c * P[-3, :, :] / rho[-3, :, :])
            T_g = (2.0 * T_i[1] - T_i[0], 3.0 * T_i[1] - 2.0 * T_i[0])

            # Set mass density
            rho[-2, :, :] = ((r[-3] / r[-2]) ** 2) * mr[-3, :, :] / vr_g[0]
            rho[-1, :, :] = ((r[-3] / r[-1]) ** 2) * mr[-3, :, :] / vr_g[1]

            # Set momentum density
            mr[-2, :, :] = rho[-2, :, :] * vr_g[0]
            mr[-1, :, :] = rho[-1, :, :] * vr_g[1]

            # Set pressure
            P[-2, :, :] = T_g[0] * rho[-2, :, :] / c
            P[-1, :, :] = T_g[1] * rho[-1, :, :] / c

        elif model_type == "static shearing":

            # Boundary condition: keep initial value of ghost cells
            pass

    def enforce_interface_at_inner_radial_boundary(self, q, q_at_interface):
        """Sets ghost cell values at inner radial boundary so that the value
        at the interface is enforced linearly
        """
        q[1, :, :] = 2.0 * q_at_interface - q[2, :, :]
        q[0, :, :] = 4.0 * q_at_interface - 3.0 * q[2, :, :]

    def set_inner_radial_ghost_cells(self):
        """Implements the inner radial boundary condition
        """

        model_type = self.config.get("Run", "type")

        if model_type == "solar wind relaxation":
            # TODO
            pass

        elif model_type == "static shearing":

            # Compute shear flow at cell centers at inner boundary
            vphi = np.tile(self.shear_flow(self.grid.axis.clt.centers), (len(self.grid.axis.lon.centers), 1)).T

            # Keep density fixed
            self.enforce_interface_at_inner_radial_boundary(self.solver.kernel.mass_density(), self.params.rho0)

            # Set vr = 0.0
            self.enforce_interface_at_inner_radial_boundary(self.solver.kernel.momentum_density(0), 0.0)

            # Set vclt = 0.0
            self.enforce_interface_at_inner_radial_boundary(self.solver.kernel.momentum_density(1), 0.0)

            # Set vphi equal to given flow profile
            self.enforce_interface_at_inner_radial_boundary(
                self.solver.kernel.momentum_density(2), self.params.rho0 * vphi
            )

            # Keep temperature and density fixed => keep pressure fixed
            P0 = self.params.rho0 * self.params.T0 * constants.kB / self.params.mean_molecular_mass

            self.enforce_interface_at_inner_radial_boundary(self.solver.kernel.pressure(), P0)

            # Extrapolate Bclt, Blon linearly:
            # Constructing a linear function at r = r_2 gives
            #     B(r)   = B_2 + (r-r_2)*(B_3-B_2)/(r_3-r_2)
            #  => B(r_1) = 2*B_2 - B_3
            #  => B(r_0) = B_2 - 2*(B_3-B_2)
            for B in (self.solver.kernel.magnetic_field(1), self.solver.kernel.magnetic_field(2)):
                B[0, :, :] = 3.0 * B[2, :, :] - 2.0 * B[3, :, :]
                B[1, :, :] = 2.0 * B[2, :, :] - B[3, :, :]

    def set_lower_colat_ghost_cells(self):
        """Symmetric reflection at the lateral boundary
        """

        for q in (
            self.solver.kernel.mass_density(),
            self.solver.kernel.pressure(),
            self.solver.kernel.momentum_density(0),
            self.solver.kernel.momentum_density(1),
            self.solver.kernel.momentum_density(2),
        ):

            q[:, 1, :] = q[:, 2, :]
            q[:, 0, :] = q[:, 3, :]

    def set_upper_colat_ghost_cells(self):
        """Symmetric reflection at the lateral boundary
        """

        for q in (
            self.solver.kernel.mass_density(),
            self.solver.kernel.pressure(),
            self.solver.kernel.momentum_density(0),
            self.solver.kernel.momentum_density(1),
            self.solver.kernel.momentum_density(2),
        ):

            q[:, -2, :] = q[:, -3, :]
            q[:, -1, :] = q[:, -4, :]


if __name__ == "__main__":

    #
    # Parse command line arguments
    #
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--config-file", default="static_dipole_shear.cfg", type=str, help="Configuration file (default: %(default)s)"
    )

    args = parser.parse_args()

    # Instantiate simulation
    sim = CoronalShearingSimulation(args.config_file)

    # Define the computational grid
    sim.set_grid()

    # Initialize the simulation infrastructure
    sim.initialize()

    # Set model parameters
    sim.set_solver_parameters()

    # Set boundary conditions to use
    sim.set_boundary_conditions()

    # Construct initial state
    sim.set_initial_condition()

    # Add VTK output event
    sim.add_vtk_output_event()

    # Run the simulation for the given duration
    one_minute = 60.0
    one_hour = 60.0 * one_minute

    sim.run(t_stop=sim.config.getfloat("Run", "duration") * one_hour)

