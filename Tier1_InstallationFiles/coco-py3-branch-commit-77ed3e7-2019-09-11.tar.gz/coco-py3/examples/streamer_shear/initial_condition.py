# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Classes used for computing the initial condition for the coronal shearing
simulations.
"""

import numpy as np

import coco.core.constants as constants


class Parameters(object):
    pass


class DipoleMagneticField(object):
    """Axisymmetric dipole magnetic field.

    Args:
        r0 (float) : Reference radius of dipole
        B0 (float) : Field strength at the poles at r = r0
    """

    def __init__(self, r0=1.03 * constants.solar_radius, B0=1e-4):

        self.params = Parameters()

        self.params.r0 = r0
        self.params.B0 = B0

    def Br(self, r, colat, lon=0.0):
        return self.params.B0 * np.cos(colat) * (self.params.r0 / r) ** 3

    def Bclt(self, r, colat, lon=0.0):
        return 0.5 * self.params.B0 * np.sin(colat) * (self.params.r0 / r) ** 3

    def Blon(self, r, colat, lon=0.0):
        return 0.0


class ParkerIsothermalSolarWind(object):
    def __init__(self):

        self.params = Parameters()

        # Constant (isothermal) temperature, K
        self.params.T0 = 1.0e6

        # Mean molecular mass, kg
        self.params.mean_molecular_mass = 0.5 * constants.proton_mass

        # Reference height
        self.params.r0 = 1.03 * constants.solar_radius

        # Mass density at reference height, kg/m^3
        self.params.rho0 = 1.0e-13

    @property
    def critical_radius(self):
        return 0.5 * scipy.constants.G * constants.solar_mass / (self.sound_speed ** 2)

    @property
    def sound_speed(self):
        return np.sqrt(self.params.T0 * scipy.constants.k / self.params.mean_molecular_mass)

    def radial_velocity(self, r):

        # Dimensionless radial coordinate
        x = r / self.critical_radius

        rhs = 4.0 * (np.log(x) + 1.0 / x) - 3.0

        vr = np.zeros(len(r))

        for i, xi in enumerate(x):

            # Starting value for Newton-Raphson iteration chosen
            # differently depending on if we are beyond the critical
            # point or not. This ensures that we get the supersonic
            # solution branch.

            if xi < 1.0:
                u = 0.0001
            else:
                u = 1.1

            for iter in range(50):
                unew = u - (np.log(u * u) - u * u + rhs[i]) / ((2.0 / u) - 2.0 * u)
                u = unew

            vr[i] = u * self.sound_speed

        return vr

    def mass_density(self, r):

        # Radial velocity on radial grid points
        vr = self.radial_velocity(r)

        # Radial velocity at reference radius r = r0
        vr0 = self.radial_velocity((self.params.r0,))

        # Constant radial mass flux
        mass_flux = (self.params.r0 ** 2) * self.params.rho0 * vr0

        # Density at r:  r^2 rho vr = constant = r0^2 rho0 vr0
        return mass_flux / (r * r * vr)

    def pressure(self, r):

        rho = self.mass_density(r)

        return rho * self.params.T0 * constants.kB / self.params.mean_molecular_mass

    def radial_momentum_density(self, r):

        return self.mass_density(r) * self.radial_velocity(r)


class IsothermalHydrostaticEquilibirum(object):
    """Class that sets up an isothermal hydrostatic equilibrium.

    For \vec{v}(\vec{x}) = 0 and T(\vec{x}) = T0 = const, hydrostatic equilibrium
    is obtained when the pressure gradient and gravity forces balance
    (assuming an EOS P = \rho kB T/m):

    0 = - (kB T0/ m) grad(\rho) - \rho (G M / r^2) \vec{e}_r

    Solving gives \rho = \rho0 exp ( A (1/r - 1/r0) ), A = GMm/(kB T0)

    Args:
        T0   :  Constant temperature, K
        m    :  Mean mean_molecular_mass
        r0   :  Reference height, m
        rho0 :  Mass density at reference height
    """

    def __init__(self, T0=1.0e6, r0=1.03 * constants.solar_radius, rho0=1.0e-13, m=0.5 * constants.proton_mass):

        self.params = Parameters()

        # Constant (isothermal) temperature, K
        self.params.T0 = T0

        # Mean molecular mass, kg
        self.params.mean_molecular_mass = m

        # Reference height
        self.params.r0 = r0

        # Mass density at reference height, kg/m^3
        self.params.rho0 = rho0

    def mass_density(self, r):
        """Computes the hydrostatic equilibrium density.
        """

        # Shorthand to solar radius
        Rs = constants.solar_radius

        # Gravitational acceleration
        g = constants.G * constants.solar_mass / (Rs ** 2)

        # Gravitational scale height
        scale_height = constants.kB * self.params.T0 / (self.params.mean_molecular_mass * g)

        # Mass density
        return self.params.rho0 * np.exp((Rs * Rs / scale_height) * ((1.0 / r) - (1.0 / self.params.r0)))

    def pressure(self, r):
        """Computes the hydrostatic equilibrium pressure.
        """

        rho = self.mass_density(r)

        return rho * self.params.T0 * constants.kB / self.params.mean_molecular_mass

    def radial_momentum_density(self, r):
        return np.zeros(len(r))
