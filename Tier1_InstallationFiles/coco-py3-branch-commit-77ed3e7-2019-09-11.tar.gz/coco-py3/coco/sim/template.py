# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Simulation template.
"""
import copy

import numpy as np

import coco.core.boundary
import coco.core.controller
import coco.core.parallel as parallel


class SimulationTemplate(object):
    def __init__(self, **kwargs):

        #
        # Simulation parameter container
        #
        class Parameters(object):
            pass

        self.params = Parameters()

        #
        # Solver
        #
        self.solver = None

        #
        # Computational grid
        #
        self.grid = None

        #
        # Event handler
        #
        self.events = coco.core.controller.EventList()

        #
        # Counters
        #
        self.counter = {}
        self.counter["num_time_steps"] = 0

        # Default simulation start time
        self.t = 0.0

        # Size of time step
        self.dt = 0.0

        # Upper limit on dt
        self.max_dt = np.Inf

        #
        # Keep track that simulation has been initialized
        #
        self.is_initialized = False

    def initialize(self):
        """Initializes the simulation infrastructure.

        Must be called before any computations can be performed.
        """

        if self.grid is None:
            raise ValueError("Grid has not been set.")

        if self.grid.is_empty:
            raise ValueError("Grid axes have not been set.")

        if self.solver is None:
            raise ValueError("Solver has not been set.")

        #
        # Initialize boundary conditions
        #
        self.boundary = coco.core.boundary.create_boundary_condition_containers(self.grid)

        #
        # Partition the grid
        #
        self.global_grid = copy.copy(self.grid)

        if parallel.use_mpi:
            self.partitioner = parallel.DomainDecomposition()
            self.grid = self.partitioner.create_local_grid(self.grid)
        else:
            self.grid.rank = parallel.rank

        self.grid.use_mpi = parallel.use_mpi

        #
        # Initialize the solver
        #
        self.solver.initialize(self.grid)

        # Done!
        self.is_initialized = True

    def initialize_boundary_condition_setters(self):

        # Remove internal MPI boundary conditions
        if self.grid.use_mpi:
            self.partitioner.set_internal_boundaries(self.boundary)

        # Set BCs for periodic directions in serial run
        if not self.grid.use_mpi:
            for dim in (0, 1, 2):
                if self.boundary[dim].lower == "periodic":
                    self.boundary[dim].lower = coco.core.boundary.BoundaryConditionInfo()
                    self.boundary[dim].lower.ghost_cells = lambda d=dim: self.solver.set_periodic_ghost_data(d)
                    self.boundary[dim].upper = None

    def set_ghost_cells(self):
        """Sets ghost cells.

        Sets ghost cells by calling the ghost_cells() method of each boundary
        unless the boundary.dim.side is a string or None.
        """

        for boundary_pair in self.boundary:
            for side in boundary_pair:
                if not isinstance(side, str) and side is not None:
                    side.ghost_cells()

    def set_flux_boundary_conditions(self):
        """Sets flux boundary data.

        Sets flux boundary data by calling the flux() method of each boundary
        unless the boundary.dim.side is a string or None.
        """

        for boundary_pair in self.boundary:
            for side in boundary_pair:
                if not isinstance(side, str) and side is not None:
                    side.flux()

    def update_metadata(self):
        pass

    def run(self, **kwargs):
        """Run simulation.
        """

        if not self.is_initialized:
            raise ValueError("Simulation must be initialized first.")

        # Setup boundary conditions
        self.initialize_boundary_condition_setters()

        # Finalize solver initialization
        self.solver.pre_run_finalization()

        # Time at which the simulation should terminate
        t_stop = float(kwargs.get("t_stop", 1.0))

        # Add a dummy stop event
        self.events.add(coco.core.controller.Event(description="Stop", start=t_stop))

        if parallel.rank == 0:
            print("----------------------------------------------------")

        stop = False
        while stop == False:

            #
            # Update simulation metadata
            #
            self.update_metadata()

            #
            # Get time of next event
            #
            t_next_event = self.events.time_at_next()

            #
            # Set ghost cells
            #
            self.set_ghost_cells()

            #
            # Compute update
            #
            self.solver.compute_update()

            #
            # Apply flux boundary conditions
            #
            self.set_flux_boundary_conditions()

            #
            # Determine the globally admissible time step size
            #
            solver_dt = self.solver.get_stable_time_step()

            if parallel.use_mpi:
                solver_dt = self.partitioner.comm.allreduce(solver_dt, parallel.mpi.MIN)

            #
            # Determine actual time step to use taking into account output etc.
            #
            self.dt = min(solver_dt, self.max_dt, abs(t_next_event - self.t), abs(t_stop - self.t))

            #
            # Update solution
            #
            self.solver.update_solution(self.dt)

            self.t += self.dt

            #
            # Update internal ghost data
            #
            if parallel.use_mpi:
                self.solver.update_internal(self.partitioner.comm, self.boundary)

            # TODO: only for debug output purposes!
            # self.set_custom_ghost_data_after_dUdt()

            #
            # Check whether to trigger an event
            #
            self.events.check(self.t)

            #
            # At end?
            #
            if np.isclose(self.t, t_stop):
                stop = True

            # Keep track of number of time steps
            self.counter["num_time_steps"] += 1

        #
        # Simulation ended: write last state if not already done
        #
        # if not np.isclose(t_stop, t_next_vtk_output):
        #    self.write_vtk()
