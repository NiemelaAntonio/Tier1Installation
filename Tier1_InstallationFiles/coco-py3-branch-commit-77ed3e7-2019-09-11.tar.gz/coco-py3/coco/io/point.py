# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module providing point output
"""

import os

import numpy as np

import coco.core.controller


class PointDataOutputEvent(coco.core.controller.Event):
    """Point data output class.

    Args:
        file_name : Name of the file to write the data to
        p         : Point (coordinate tiple) from which to grab the data
        sim       : Simulation class containing the data
        data      : Function that returns the data as a tuple given the cell
                    index of the grid
    """

    def __init__(self, file_name, p, sim, data, **kwargs):

        coco.core.controller.Event.__init__(self, **kwargs)

        #
        # Initialize output file
        #
        self.file_name = file_name

        # Get (optional) header
        header = kwargs.get("header", None)

        # Rank zero initializes file and writes header, rest of processes wait
        if sim.grid.rank == 0:
            with open(self.file_name, "w") as output_file:
                if header is not None:
                    output_file.write(str(header))

        if sim.grid.use_mpi:
            sim.partitioner.comm.Barrier()

        #
        # Initialize rest
        #

        # Figure out output format if not given
        self.output_format = kwargs.get("output_format", None)
        if self.output_format is None:
            self.output_format = (len(data((0, 0, 0), (0, 0, 0)))) * "{:.5e} " + "\n"

        # Event description
        self.description = "Point data output"

        # Ref to simulation object
        self._sim = sim

        # Point at which to get data
        self.p = p

        # User-defined function to get data
        self._data = data

    def print_message(self):

        if self._sim.grid.rank == 0:
            msg = " * "
            msg += "At t = {:>10.3e} : ".format(self._sim.t)
            msg += "Point output to {}".format(self.file_name)
            print(msg)

    def get_position(self):
        return self.p

    def run(self):
        """Event task definition
        """

        # Get position
        self.p = self.get_position()

        # Write data at position
        self.write()

    def write(self):
        """Write point data to file.

        The process that owns the data opens the file and performs the write.
        """

        data_to_write = self.get_data()

        if data_to_write is not None:

            self.print_message()

            # Append data to file
            with open(self.file_name, "a") as output_file:
                output_file.write(self.output_format.format(*data_to_write))

        # This should not be needed but is added as a safety precaution
        if self._sim.grid.use_mpi:
            self._sim.partitioner.comm.Barrier()

    def get_data(self):
        """Get data at the specified point.

        Returns None if the point does not exist in the domain.
        """

        data = None

        # Ensure that the point is in the grid
        if self._sim.grid.is_inside(self.p):

            # Get index of cell
            idx = self._sim.grid.get_cell_idx(self.p)

            # Use user-defined function to grab data
            data = self._data(self.p, idx)

        return data
