# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module providing data output in the NumPy array format.
"""

import os

import numpy as np

import coco.core.controller


class NPYDataOutputEvent(coco.core.controller.Event):
    def __init__(self, sim, data, **kwargs):

        coco.core.controller.Event.__init__(self, **kwargs)

        self.description = "NPY data output"

        self.file_name_base = kwargs.get("base_name", "x")

        # Ref to sim data
        self._sim = sim

        # Function that returns dict of data to save
        self._data = data

    def output_file_name(self):
        return self.file_name_base + "." + str(self.counter).zfill(4)

    def run(self):

        self.write()

    def write(self):

        # Shorthand to grid
        grid = self._sim.grid

        t = self._sim.t

        #
        # Construct output file name
        #
        file_name = self.output_file_name()

        if grid.rank == 0:
            msg = " * "
            msg += "At t = {:>10.3e} : ".format(t) if t is not None else ""
            msg += "NPY output to {}".format(file_name)
            print(msg)

        if grid.use_mpi:
            file_name += "_" + str(grid.rank).zfill(3)

        #
        # Construct basic info to save
        #
        if grid.use_mpi:
            mpi_coord = self._sim.partitioner.comm.Get_coords(grid.rank)
            mpi_blocks = self._sim.partitioner.blocks
        else:
            mpi_coord = [0, 0, 0]
            mpi_blocks = [1, 1, 1]

        data_to_save = {
            "time": self._sim.t,
            "rank": grid.rank,
            "mpi_coord": mpi_coord,
            "mpi_blocks": mpi_blocks,
            "num_ghosts": grid.num_ghost_cells,
            grid.axis[0].name: grid.axis[0].coordinates,
            grid.axis[1].name: grid.axis[1].coordinates,
            grid.axis[2].name: grid.axis[2].coordinates,
            "units": (grid.axis[0].unit, grid.axis[1].unit, grid.axis[2].unit),
        }

        # Append user-defined data
        data_to_save.update(self._data())

        # Save to disk
        np.savez(file_name, **data_to_save)
