# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module providing VTK output
"""

import os

import numpy as np

import coco.core.controller
import coco.core.parallel as parallel

try:
    evtk = __import__("evtk.hl", fromlist=["gridToVTK"])
except ImportError:
    evtk = __import__("pyevtk.hl", fromlist=["gridToVTK"])


class VTKWriteEvent(coco.core.controller.Event):
    def __init__(self, sim, data, **kwargs):

        coco.core.controller.Event.__init__(self, **kwargs)

        self.description = "VTK output"

        self.file_name_base = kwargs.get("base_name", "x")
        self.centering = kwargs.get("centering", "zonal")
        self.write_full_domain = kwargs.get("write_full_domain", False)
        self.write_visit_file = kwargs.get("write_visit_file", True)

        self._vtk = VTK()
        self._sim = sim
        self._data = data

    def output_file_name(self):
        return self.file_name_base + "." + str(self.counter).zfill(4)

    def run(self):

        self._vtk.write(
            self.output_file_name(),
            self.file_name_base,
            self._sim.grid,
            self._data(),
            self.centering,
            time=self._sim.t,
            write_full_domain=self.write_full_domain,
            write_visit_file=self.write_visit_file,
        )


class VTK(object):
    def __init__(self, **kwargs):

        pass
        # self.grid = None

    def write_visit_file(self, file_name, file_name_base):
        """Write .visit - file
        """

        # Remove directory from file_name_base
        file_name_wout_dir = os.path.basename(file_name)

        num_subdomains = parallel.num_processes

        if parallel.rank == 0:

            if hasattr(self, "visit_file"):

                # Append subdomain files to files.visit
                for i in range(num_subdomains):

                    ending = "_" + str(i).zfill(3) if parallel.use_mpi else ""

                    self.visit_file.write(file_name_wout_dir + ending + ".vtr\n")
                    self.visit_file.flush()

            else:

                # Initialize file
                try:
                    self.visit_file = open(file_name_base + ".visit", "w")
                except IOError:
                    print("Cannot open " + file_name_base + ".visit")
                    exit()

                # Write block info at the top of the file
                self.visit_file.write("!NBLOCKS " + str(num_subdomains) + "\n")

                # Write first entry by recalling the function
                self.write_visit_file(file_name, file_name_base)

    def _get_field_type(self, grid, field):
        """Identifies the type of the given field

        Determines whether the field is cell-centered, face-centered,
        edge-centered or nodal. This is done based on the number of data
        points in the field compared to the grid. The identification scheme
        for vector fields is as follows:

        Cell-centered:  shape of each component = # cells
        Face-centered:  shape of component xi   = # cells + 1 in dim xi
        Edge-centered:  shape of component xi   = # cells + 1 in dims other than xi
        Nodal:          shape of each component = # cells + 1 in each dim

        For scalar fields, only cell-centered and nodal colocations are supported.

        Args:
            grid   :  Grid object
            field  :  Input scalar or vector field (numpy 3D array)
        Returns:
            str giving the field type (cell-centered/face-centered/edge-centered/nodal)
        """

        num_cells = np.asarray(grid.num_cells)

        # Are we dealing with a vector field?
        is_vector_field = True if len(field.shape) != 3 else False

        # Identify vector fields using the shape of the x (first) component
        field_shape = field[0].shape if is_vector_field else field.shape

        # Number of points for x component for each colocation type
        num_data_points = {
            "cell-centered": num_cells,
            "face-centered": num_cells + np.array((1, 0, 0)),
            "edge-centered": num_cells + np.array((0, 1, 1)),
            "nodal": num_cells + np.array((1, 1, 1)),
        }

        # Compare the number of data points
        field_colocation = None
        for colocation in num_data_points:
            if np.all(field_shape == num_data_points[colocation]):
                field_colocation = colocation

        if field_colocation is None:
            raise ValueError("Unrecognized field type")

        # For scalar fields, only nodal and cell-centered colocations
        # are supported
        if not is_vector_field and field_colocation not in ("cell-centered", "nodal"):
            raise ValueError("Unsupported scalar field colocation")

        return field_colocation, is_vector_field

    def _face_centered_to_nodal(self, grid, field):
        """Interpolates face-centered vector field to the in-domain nodes of the
        grid.

        Employs simple averaging interpolation, which is equivalent to linear
        interpolation when the grid is uniform in all directions.

        """

        # NOTE: zero ghost cells not supported!!
        ng = grid.num_ghost_cells

        B1 = 0.25 * (
            field[0][ng[0] : -ng[0], ng[1] - 1 : -ng[1], ng[2] - 1 : -ng[2]]
            + field[0][ng[0] : -ng[0], ng[1] : -ng[1] + 1, ng[2] : -ng[2] + 1]
            + field[0][ng[0] : -ng[0], ng[1] : -ng[1] + 1, ng[2] - 1 : -ng[2]]
            + field[0][ng[0] : -ng[0], ng[1] - 1 : -ng[1], ng[2] : -ng[2] + 1]
        )

        B2 = 0.25 * (
            field[1][ng[0] - 1 : -ng[0], ng[1] : -ng[1], ng[2] - 1 : -ng[2]]
            + field[1][ng[0] : -ng[0] + 1, ng[1] : -ng[1], ng[2] : -ng[2] + 1]
            + field[1][ng[0] : -ng[0] + 1, ng[1] : -ng[1], ng[2] - 1 : -ng[2]]
            + field[1][ng[0] - 1 : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2] + 1]
        )

        B3 = 0.25 * (
            field[2][ng[0] - 1 : -ng[0], ng[1] - 1 : -ng[1], ng[2] : -ng[2]]
            + field[2][ng[0] : -ng[0] + 1, ng[1] : -ng[1] + 1, ng[2] : -ng[2]]
            + field[2][ng[0] : -ng[0] + 1, ng[1] - 1 : -ng[1], ng[2] : -ng[2]]
            + field[2][ng[0] - 1 : -ng[0], ng[1] : -ng[1] + 1, ng[2] : -ng[2]]
        )

        return np.array((B1, B2, B3))

    def _edge_centered_to_nodal(self, grid, field):
        """Interpolates edge-centered vector field to the in-domain nodes of the
        grid.

        Employs simple averaging interpolation, which is equivalent to linear
        interpolation when the grid is uniform in all directions.
        """

        ng = grid.num_ghost_cells

        B1 = 0.5*(field[0][ng[0] : -ng[0] + 1, ng[1] : -ng[1], ng[2] : -ng[2]]
                  + field[0][ng[0] - 1 : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]])

        B2 = 0.5 * (
            field[1][ng[0] : -ng[0], ng[1] : -ng[1] + 1, ng[2] : -ng[2]]
            + field[1][ng[0] : -ng[0], ng[1] - 1 : -ng[1], ng[2] : -ng[2]]
        )

        B3 = 0.5 * (
            field[2][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2] + 1]
            + field[2][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] - 1 : -ng[2]]
        )

        return np.array((B1, B2, B3))

    def _face_centered_to_cell_centered(self, grid, field):
        """Averages face-centered vector field to cell centers.
        """

        # index of first cell
        # si = (0, 0,0 )

        # index of last cell
        # ei =

        B1 = 0.5*(field[0][0:-1, :, :] + field[0][1::, :, :])
        B2 = 0.5*(field[1][:, 0:-1, :] + field[1][:, 1::, :])
        B3 = 0.5*(field[2][:, :, 0:-1] + field[2][:, :, 1::])

        return np.array((B1, B2, B3))

    def _cell_centered_scalar_to_nodal(self, grid, field):
        """Interpolates cell-centered field to the in-domain nodes of the
        grid.

        Employs simple averaging interpolation, which is equivalent to linear
        interpolation when the grid is uniform in all directions.
        """

        # NOTE: zero ghost cells not supported!!
        ng = grid.num_ghost_cells

        V = (1.0/8.0)*(
            field[ng[0] - 1 : -ng[0], ng[1] - 1 : -ng[1], ng[2] - 1 : -ng[2]]
            + field[ng[0] - 1 : -ng[0], ng[1] : -ng[1] + 1, ng[2] - 1 : -ng[2]]
            + field[ng[0] : -ng[0] + 1, ng[1] - 1 : -ng[1], ng[2] - 1 : -ng[2]]
            + field[ng[0] : -ng[0] + 1, ng[1] : -ng[1] + 1, ng[2] - 1 : -ng[2]]
            #
            + field[ng[0] - 1 : -ng[0], ng[1] - 1 : -ng[1], ng[2] : -ng[2] + 1]
            + field[ng[0] - 1 : -ng[0], ng[1] : -ng[1] + 1, ng[2] : -ng[2] + 1]
            + field[ng[0] : -ng[0] + 1, ng[1] - 1 : -ng[1], ng[2] : -ng[2] + 1]
            + field[ng[0] : -ng[0] + 1, ng[1] : -ng[1] + 1, ng[2] : -ng[2] + 1]
        )
        return V

    def _cell_centered_to_nodal(self, grid, field, is_vector_field):

        if is_vector_field:
            V0 = self._cell_centered_scalar_to_nodal(grid, field[0])
            V1 = self._cell_centered_scalar_to_nodal(grid, field[1])
            V2 = self._cell_centered_scalar_to_nodal(grid, field[2])
            V = np.array((V0, V1, V2))
        else:
            V = self._cell_centered_scalar_to_nodal(grid, field)

        return V

    def _crop_nodal(self, grid, field, is_vector_field):

        ng = grid.num_ghost_cells

        if is_vector_field:
            V0 = field[0][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]]
            V1 = field[1][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]]
            V2 = field[2][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]]
            V = np.array((V0, V1, V2))
        else:
            V = np.copy(field[ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]])

        return V

    def _crop_zonal(self, grid, field, is_vector_field):

        ng = grid.num_ghost_cells

        if is_vector_field:
            V0 = field[0][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]]
            V1 = field[1][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]]
            V2 = field[2][ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]]
            V = np.array((V0, V1, V2))
        else:
            V = np.copy(field[ng[0] : -ng[0], ng[1] : -ng[1], ng[2] : -ng[2]])

        return V

    def write(self, file_name, file_name_base, grid, data, centering, **kwargs):
        """Write VTK output data.
        """

        # Write files.visit
        if kwargs.get("write_visit_file", True):
            self.write_visit_file(file_name, file_name_base)

        # Get time
        t = kwargs.get("time", None)

        # Log output
        if parallel.rank == 0:
            msg = " * "
            msg += "At t = {:>10.3e} : ".format(t) if t is not None else ""
            msg += "VTK output to {}".format(file_name)
            print(msg)

        # Add rank specifier to file name
        if parallel.use_mpi:
            file_name += "_" + str(parallel.rank).zfill(3)

        # Write full domain or only the in-domain?
        write_full_domain = kwargs.get("write_full_domain", False)

        #
        # Determine coordinates of domain to output
        #
        if centering == "nodal" and not write_full_domain:
            crds = grid.indomain_edge_coords
        elif centering == "zonal" and not write_full_domain:
            crds = grid.indomain_edge_coords
        elif centering == "nodal" and write_full_domain:
            crds = grid.edge_coords
        elif centering == "zonal":
            crds = grid.edge_coords

        # Determine coordinate normalization scalars
        coordinate_normalization = [1.0, 1.0, 1.0]
        for dim in range(3):
            if grid.axis[dim].unit is not None:
                coordinate_normalization[dim] = float(grid.axis[dim].unit)

        #
        # Compute output data
        #
        output_data = {}
        output_crds = {}

        for key in data:

            field = data[key]

            # TODO: Accept functors?

            # Get the colocation of the field
            field_colocation, is_vector_field = self._get_field_type(grid, field)

            # Perform the required interpolation AND crop the domain
            if centering == "zonal" and field_colocation == "face-centered":
                interpolated_field = self._face_centered_to_cell_centered(grid, field)
            elif centering == "nodal" and field_colocation == "face-centered":
                interpolated_field = self._face_centered_to_nodal(grid, field)
            elif centering == "nodal" and field_colocation == "cell-centered":
                interpolated_field = self._cell_centered_to_nodal(grid, field, is_vector_field)
            elif centering == "nodal" and field_colocation == "edge-centered":
                interpolated_field = self._edge_centered_to_nodal(grid, field)
            elif centering == "nodal" and field_colocation == "nodal" and not write_full_domain:
                interpolated_field = self._crop_nodal(grid, field, is_vector_field)
            elif centering == "zonal" and field_colocation == "cell-centered" and not write_full_domain:
                interpolated_field = self._crop_zonal(grid, field, is_vector_field)
            else:
                interpolated_field = field

            # Append data to the dict
            if is_vector_field:
                for dim in range(3):
                    name = key + grid.axis[dim].name
                    output_data[name] = interpolated_field[dim]
            else:
                output_data[key] = interpolated_field

            # For native output, add coordinates to the dict
            if centering == "native":
                if field_colocation == "cell-centered":
                    if is_vector_field:
                        for dim in range(3):
                            name = key + grid.axis[dim].name
                            output_crds[name] = grid.center_coords
                    else:
                        output_crds[key] = grid.center_coords
                elif field_colocation == "face-centered":
                    for dim in range(3):
                        name = key + grid.axis[dim].name
                        output_crds[name] = grid.face_center_coords(dim)
                elif field_colocation == "edge-centered":
                    for dim in range(3):
                        name = key + grid.axis[dim].name
                        output_crds[name] = grid.edge_center_coords(dim)

        #
        # Write data
        #
        cell_data = output_data if centering == "zonal" else None
        point_data = output_data if centering == "nodal" else None

        if centering == "native":

            # For native output, a separate file is written for each
            # variable. Vector components are considered separate variables.
            for key in output_data:

                evtk.gridToVTK(
                    file_name + "_" + str(key),
                    output_crds[key][0] / coordinate_normalization[0],
                    output_crds[key][1] / coordinate_normalization[1],
                    output_crds[key][2] / coordinate_normalization[2],
                    pointData={key: output_data[key]},
                )

        else:

            evtk.gridToVTK(
                file_name,
                crds[0] / coordinate_normalization[0],
                crds[1] / coordinate_normalization[1],
                crds[2] / coordinate_normalization[2],
                cellData=cell_data,
                pointData=point_data,
            )

        """
        cell_data  = kwargs.get("cell_data", None)
        point_data = kwargs.get("point_data", None)

        # Crop data
        if not write_full_domain:

            selection  = (slice(grid.num_ghost_cells[0], -grid.num_ghost_cells[0]),
                          slice(grid.num_ghost_cells[1], -grid.num_ghost_cells[1]),
                          slice(grid.num_ghost_cells[2], -grid.num_ghost_cells[2]))

            for var in cell_data.keys():
                cell_data[var] = np.copy(cell_data[var][selection])

        # Check point data output shape
        node_shape = [len(crd) for crd in crds]
        for var in point_data.keys():
            for dim in range(3):
                if point_data[var].shape[dim] is not node_shape[dim]:
                    raise ValueError("Unexpected point data shape")


        #
        # Write data
        #
        evtk.gridToVTK(file_name,
                       crds[0]/coordinate_normalization[0],
                       crds[1]/coordinate_normalization[1],
                       crds[2]/coordinate_normalization[2],
                       cellData=cell_data,
                       pointData=point_data)
        """

    def write_old(self, file_name, grid, **kwargs):
        """Write VTK output data.
        """

        # Determine file name of output file
        # file_name = self.output_file_name()

        # Write files.visit
        self.write_visit_file(file_name)

        # Get time
        t = kwargs.get("time", None)

        # Log output
        if parallel.rank is 0:
            msg = " * "
            msg += "At t = {:>10.3e} : ".format(t) if t is not None else ""
            msg += "Output to {}".format(file_name)
            print(msg)

        # Add rank specifier to file name
        if parallel.use_mpi:
            file_name += "_" + str(parallel.rank).zfill(3)

        # Write full domain or only the in-domain?
        write_full_domain = kwargs.get("write_full_domain", False)

        #
        # Determine coordinates to output
        #
        crds = grid.edge_coords if write_full_domain else grid.indomain_edge_coords

        # Determine coordinate normalization scalars
        coordinate_normalization = [1.0, 1.0, 1.0]
        for dim in range(3):
            if grid.axis[dim].unit is not None:
                coordinate_normalization[dim] = float(grid.axis[dim].unit)

        #
        # Determine output data
        #
        cell_data = kwargs.get("cell_data", None)
        point_data = kwargs.get("point_data", None)

        # Crop data
        if not write_full_domain:

            selection = (
                slice(grid.num_ghost_cells[0], -grid.num_ghost_cells[0]),
                slice(grid.num_ghost_cells[1], -grid.num_ghost_cells[1]),
                slice(grid.num_ghost_cells[2], -grid.num_ghost_cells[2]),
            )

            for var in cell_data.keys():
                cell_data[var] = np.copy(cell_data[var][selection])

        # Check point data output shape
        node_shape = [len(crd) for crd in crds]
        for var in point_data.keys():
            for dim in range(3):
                if point_data[var].shape[dim] is not node_shape[dim]:
                    raise ValueError("Unexpected point data shape")

        #
        # Write data
        #
        evtk.gridToVTK(
            file_name,
            crds[0] / coordinate_normalization[0],
            crds[1] / coordinate_normalization[1],
            crds[2] / coordinate_normalization[2],
            cellData=cell_data,
            pointData=point_data,
        )
