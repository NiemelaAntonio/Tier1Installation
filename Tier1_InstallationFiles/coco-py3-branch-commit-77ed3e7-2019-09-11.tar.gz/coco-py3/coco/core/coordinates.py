# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Coordinate interval manipulation utilities.
"""

import numpy as np
import scipy.optimize


def partition_interval(x, num_intervals, min_edge_pts, overlap):
    """Partition discrete interval into subintervals.

    Partitions the given interval into a given number of subintervals. The
    partitioning is done such that each subinterval consists roughly of the
    same number of points.

    Args:
        x             :  interval coordinates
        num_intervals :  number of intervals the partitioning should result in
        min_edge_pts  :  min. number of points that the first and last partition
                         should contain
        overlap       :  number of extra overlapping points to include

    Returns:
        List of arrays, each contaning the coordinates of the created partition
    """

    if num_intervals == 1:
        return [x]

    #
    # Determine how many points each interval should have
    #

    num_pts_to_partition = len(x)

    if 2*min_edge_pts > num_pts_to_partition:
        raise ValueError("Too many edge points required!")

    # nominal integer number of points in each interval
    num_pts_nominal = int(np.round(num_pts_to_partition/num_intervals))

    # number of points in each interval
    num_pts = np.ones(num_intervals, dtype=int)*num_pts_nominal

    # require edge intervals to contain a minimum number of points
    num_pts[0] = max(num_pts_nominal, min_edge_pts)
    num_pts[-1] = max(num_pts_nominal, min_edge_pts)

    # number of points left to distribute
    num_pts_leftover = num_pts_to_partition - sum(num_pts)

    if num_pts_leftover > 0:

        #
        # Add points to intervals with smallest amount of points
        #
        for i in range(num_pts_leftover):
            idx = np.argmin(num_pts)
            num_pts[idx] += 1

    else:

        #
        # Remove points from intervals with largest amount of points
        #
        for i in range(abs(num_pts_leftover)):

            num_pts_search = num_pts

            # cannot remove from edges if they already are at their
            # minimum value
            if num_pts[0] == min_edge_pts:
                num_pts_search = num_pts_search[1::]
            if num_pts[-1] == min_edge_pts:
                num_pts_search = num_pts_search[0:-1]

            idx = np.argmax(num_pts_search)

            if num_pts_search[idx] <= 1:
                raise ValueError("Partitioning failed: Too few points in block.")

            num_pts_search[idx] -= 1

    assert sum(num_pts) == num_pts_to_partition
    assert num_pts[0] >= min_edge_pts
    assert num_pts[-1] >= min_edge_pts

    #
    # Determine coordinates in each interval
    #

    interval_coordinates = []

    start_idx = 0
    for i in range(num_intervals):
        interval_coordinates.append(x[start_idx : (start_idx + num_pts[i])])
        start_idx += num_pts[i]

    #
    # Add overlap coordinates. Coordinates are not added at the outer edges of
    # the domain, only at interfaces where a partition has been introduced.
    #

    interval_coordinates_with_overlap = []

    for i in range(num_intervals):

        center = interval_coordinates[i]

        if i == 0:
            # Do not add coordinates to the left in the first partition
            left_overlap = []
        else:
            # NOTE: an extra point is added to the left. This is to ensure that
            # the cells are properly overlaping, as the input coordinates
            # are here assumed to be edge coordinates
            left_overlap = interval_coordinates[i - 1][-overlap - 1::]

        if i == (num_intervals - 1):
            # Do not add coordinates to the right in the last partition
            right_overlap = []
        else:
            right_overlap = interval_coordinates[i + 1][0:overlap]

        interval_coordinates_with_overlap.append(np.concatenate((left_overlap, center, right_overlap)))

    return interval_coordinates_with_overlap


def constant_ratio_coordinates(**kwargs):
    """Computes coordinates whose spacing increases by a constant factor.

    The coordinates are constructed according to the requirement that
    x[i+1] = x[i] + k*( x[i]-x[i-1] )
    where k is a constant. This leads to a geometric series
    x[N] = x[0] + dx sum_{i=0}^{N-1} k^i = x[0] + dx (1-k^N)/(1-k)
    where dx = x[1]-x[0] is the spacing at the start.

    The constant k is computed automatically.

    Args:
        start       :  Starting coordinate (x[0])
        end         :  Ending coordinate (x[N])
        num_points  :  Number of coordinates (N-1)
        dx_at_start :  Grid spacing at start
    """

    start = float(kwargs.get("start", 0.0))
    end = float(kwargs.get("end", 1.0))
    N = int(kwargs.get("num_points", 10)) - 1
    dx = float(kwargs.get("dx_at_start", 0.1))

    #
    # Compute increase ration k
    #

    c = (end - start)/dx

    def _func(k, c, N):
        return -c + (1.0 - k**N)/(1.0 - k)

    k = scipy.optimize.brentq(_func, 1.0 + 1e-12, 2.5, args=(c, N))

    #
    # Compute and return coordinates
    #
    crds = []
    crds.append(start)

    for i in range(1, N + 1):
        crds.append(start + dx*((1.0 - k**i)/(1.0 - k)))

    return np.array(crds)
