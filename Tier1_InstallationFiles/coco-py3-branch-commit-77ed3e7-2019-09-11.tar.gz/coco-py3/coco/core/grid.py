# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module defining the computational grid.
"""

import collections

import numpy as np

import coco


class Grid(object):
    """Three-dimensional rectilinear grid class.

    The grid, as understood here, is a three-dimensional volume discretized into
    a set of hexahedral cells in a logically rectilinear fashion. In addition to
    storing coordinates of the cells, the class also stores various metadata
    concerning the properties of the grid. However, the class does not store
    any cell data itself.

    Attributes:
        num_ghost_cells : Number of ghost cells in each dimension
        geometry        : Geometry of the grid (cartesian/spherical)
    """

    def __init__(self, **kwargs):

        # TODO: Make these "private"?
        self.num_ghost_cells = np.array(kwargs.get("num_ghost_cells", (0, 0, 0)))
        self.geometry = kwargs.get("geometry", "cartesian")
        self.ignorable_axes = kwargs.get("ignore", None)

    def __str__(self):
        """Return basic information of the grid
        """

        if self.is_empty:
            return "Empty grid"

        axis_names = [axis.name for axis in self.axis]
        domain_extent = [str(axis.extent/axis.unit) for axis in self.axis]
        units = [str(axis.unit) for axis in self.axis]

        message = ""
        message += "Geometry:                " + self.geometry + "\n"
        message += "Axes:                    " + str(axis_names) + "\n"
        message += "Domain extent:           " + str(domain_extent) + "\n"
        message += "Units:                   " + str(units) + "\n"
        message += "Total number of cells:   " + str(tuple(self.num_cells)) + "\n"
        message += "Ghost cells at each end: " + str(tuple(self.num_ghost_cells))  # + "\n"

        return message

    @property
    def is_empty(self):
        """Checks if the grid has existing axes.
        """
        has_axis = True
        if not hasattr(self, "axis"):
            has_axis = False

        return not has_axis

    @property
    def edge_coords(self):
        """Returns cell edge coordinates of entire grid as named tuple.
        """
        Edges = collections.namedtuple("Coordinates", self.axis._fields)

        return Edges(self.axis[0].edges, self.axis[1].edges, self.axis[2].edges)

    @property
    def center_coords(self):
        """Returns cell center coordinates of entire grid as named tuple.
        """
        Centers = collections.namedtuple("Coordinates", self.axis._fields)

        return Centers(self.axis[0].centers, self.axis[1].centers, self.axis[2].centers)

    @property
    def indomain_edge_coords(self):
        """Returns cell edge coordinates of in-domain region as named tuple.
        """
        Edges = collections.namedtuple("Coordinates", self.axis._fields)

        start_idx = self.num_ghost_cells
        end_idx = self.num_cells - self.num_ghost_cells + 1

        return Edges(
            self.axis[0].edges[start_idx[0] : end_idx[0]],
            self.axis[1].edges[start_idx[1] : end_idx[1]],
            self.axis[2].edges[start_idx[2] : end_idx[2]],
        )

    @property
    def indomain_center_coords(self):
        """Returns cell center coordinates of in-domain region as named tuple.
        """
        Centers = collections.namedtuple("Coordinates", self.axis._fields)

        start_idx = self.num_ghost_cells
        end_idx = self.num_cells - self.num_ghost_cells

        return Centers(
            self.axis[0].centers[start_idx[0] : end_idx[0]],
            self.axis[1].centers[start_idx[1] : end_idx[1]],
            self.axis[2].centers[start_idx[2] : end_idx[2]],
        )

    @property
    def extent(self):
        """Returns extent of in-domain region as named tuple.
        """
        Extent = collections.namedtuple("Extent", self.axis._fields)

        ng = self.num_ghost_cells

        return Extent(
            self.axis[0].edges[-1 - ng[0]] - self.axis[0].edges[ng[0]],
            self.axis[1].edges[-1 - ng[1]] - self.axis[1].edges[ng[1]],
            self.axis[2].edges[-1 - ng[2]] - self.axis[2].edges[ng[2]],
        )

    @property
    def domain(self):
        """Returns coordinates of outer edges of the in-domain region as named tuple.
        """
        Domain = collections.namedtuple("Domain", self.axis._fields)

        edge_coords = self.indomain_edge_coords

        return Domain(
            (edge_coords[0][0], edge_coords[0][-1]),
            (edge_coords[1][0], edge_coords[1][-1]),
            (edge_coords[2][0], edge_coords[2][-1]),
        )

    def face_center_coords(self, dim):
        """Returns the face-centered coordinates for the faces with normals
        in the dim:th coordinate direction
        """
        FaceCenters = collections.namedtuple("Coordinates", self.axis._fields)

        crds = [self.axis[i].centers for i in range(3)]
        crds[dim] = self.axis[dim].edges

        return FaceCenters(crds[0], crds[1], crds[2])

    def edge_center_coords(self, dim):
        """Returns the edge-centered coordinates for the cell edges directed
        in the dim:th coordinate direction
        """
        EdgeCenters = collections.namedtuple("Coordinates", self.axis._fields)

        crds = [self.axis[i].edges for i in range(3)]
        crds[dim] = self.axis[dim].centers

        return EdgeCenters(crds[0], crds[1], crds[2])

    def get_coordinates(self, element, **kwargs):
        """Returns coordinates at the position defined by the element.

        Args:
            element : String defining the points within the grid. The
                      nomenclature used in https://femtable.org/ is used.
        Returns:
            Namedtuple containing the coordinates
        """

        Coordinates = collections.namedtuple("Coordinates", self.axis._fields)

        #
        # Construct coordinates based on the element type
        #

        if element == "dQ0":
            crds = self.center_coords
        elif element == "Q1":
            crds = self.edge_coords
        elif element == "Q2":
            crds = Coordinates(
                np.sort(np.concatenate((self.axis[0].edges, self.axis[0].centers))),
                np.sort(np.concatenate((self.axis[1].edges, self.axis[1].centers))),
                np.sort(np.concatenate((self.axis[2].edges, self.axis[2].centers))),
            )
        elif element == "face0":
            crds = self.face_center_coords(0)
        elif element == "face1":
            crds = self.face_center_coords(1)
        elif element == "face2":
            crds = self.face_center_coords(2)
        elif element == "edge0":
            crds = self.edge_center_coords(0)
        elif element == "edge1":
            crds = self.edge_center_coords(1)
        elif element == "edge2":
            crds = self.edge_center_coords(2)
        else:
            raise ValueError("Unknown element type")

        #
        # Get normalization constants (i.e. the specified unit)
        #
        normalization = [1.0, 1.0, 1.0]
        if kwargs.get("normalize", False):
            for dim in range(3):
                normalization[dim] = float(self.axis[dim].unit)

        return Coordinates(crds[0]/normalization[0], crds[1]/normalization[1], crds[2]/normalization[2])

    def get_cell_idx(self, p):
        """Returns the index of the cell containing the given point.

        Args:
            p : Array/tuple/list containing the coordinates of the point.

        Returns:
            Tuple containing i, j, k indices of the cell
        """

        # assert ??
        idx = [0, 0, 0]
        for dim in range(3):
            idx[dim] = abs(self.axis[dim].centers - p[dim]).argmin()

        return tuple(idx)

    def is_inside(self, p):
        """Tests if the given point is inside the domain of the grid.

        Note that points exactly on the edges are excluded.

        Args:
            p : Array/tuple/list containing the coordinates of the point.

        Returns:
            bool
        """

        edges = self.indomain_edge_coords

        is_in = True
        for dim in range(3):
            if p[dim] >= edges[dim][-1] or p[dim] <= edges[dim][0]:
                is_in = False

        return is_in

    @property
    def spacing(self):
        """Returns grid cell sizes in each direction of entire grid.
        """

        Delta = collections.namedtuple("Delta", self.axis._fields)

        return Delta(self.axis[0].spacing, self.axis[1].spacing, self.axis[2].spacing)

    @property
    def num_cells(self):
        """Returns the total number of cells in each direction.
        """
        return np.array([axis.num_crds - 1 for axis in self.axis])

    @property
    def num_nodes(self):
        """Returns the total number of nodes in each direction.
        """
        return np.array([axis.num_crds for axis in self.axis])

    def set_coordinate_axes(self, x1, x2, x3, **kwargs):
        """Sets coordinates of the grid.

        Constructs the grid given three CoordinateAxis objects. Note that the
        order of the axes given to the function are NOT arbitrary. The axes
        should be given in the following order:

            (x1, x2, x3) = (x, y, z)        when the geometry is Cartesian
            (x1, x2, x3) = (r, colat, lon)  when the geometry is spherical

        The coordinates given in the axes are assumed to represent edge
        coordinates of the grid. Metadata set in the axes are used to set grid
        properties such as the periodicity and output unit of the axis.

        Args:
            x1, x2, x3  :  CoordinateAxis objects
        """

        #
        # Check that the given coordinate axis are sane
        #
        for axis in (x1, x2, x3):
            axis.check()

        #
        # Store coordinates as named tuples using the given axes
        #

        # Give each axis a reasonable name if none has been given
        for dim, axis in zip(range(3), (x1, x2, x3)):
            if axis.name is None:
                axis.name = "x" + str(dim + 1)

        # Create axis container
        self.axis = collections.namedtuple("Axis", (x1.name, x2.name, x3.name))(x1, x2, x3)

        #
        # Append ghost coordinates to axes
        #
        if kwargs.get("add_ghost_coordinates", True):
            for dim, ax in zip(range(3), self.axis):
                ax.add_coordinates(self.num_ghost_cells[dim])

        #
        # Determine if any of the axes are to be ignored
        #
        axis_names = [axis.name for axis in self.axis]

        ignorable_axes = kwargs.get("ignore", coco.CoordinateAxis())
        ignorable_axes = [ignorable_axes] if type(ignorable_axes) not in (tuple, list) else ignorable_axes
        ignorable_axis_names = [axis.name for axis in ignorable_axes]

        ignorable_axis_dims = []
        for dim, name in enumerate(axis_names):
            if name in ignorable_axis_names:
                ignorable_axis_dims.append(dim)

        self.ignorable_axes = tuple(ignorable_axis_dims)  # if len(ignorable_axis_dims) > 0 else None


def get_element_type(grid, data_array):
    """Identifies the element type of the given array

    Determines the type of element of the array. This is done based on the
    number of data points in the array compared to the grid.

    Args:
        grid        :  Grid object
        data_array  :  Input scalar or vector field (numpy 3D array)
    Returns:
        str giving the field type
    """

    num_cells = np.asarray(grid.num_cells)

    # Number of points for each element type
    num_data_points = {
        "dQ0": num_cells,
        "face0": num_cells + np.array((1, 0, 0)),
        "face1": num_cells + np.array((0, 1, 0)),
        "face2": num_cells + np.array((0, 0, 1)),
        "edge0": num_cells + np.array((0, 1, 1)),
        "edge1": num_cells + np.array((1, 0, 1)),
        "edge2": num_cells + np.array((1, 1, 0)),
        "Q1": num_cells + np.array((1, 1, 1)),
    }

    data_shape = data_array.shape

    # Compare the number of data points
    element_type = None
    for element_id in num_data_points.keys():
        if np.all(data_shape == num_data_points[element_id]):
            element_type = element_id

    return element_type
