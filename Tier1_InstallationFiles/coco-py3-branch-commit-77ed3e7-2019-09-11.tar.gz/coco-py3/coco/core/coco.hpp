/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

/**
 * \brief Main header file of CoCo
 *
 *
 */

#include <array>

//
// Include xtensor headers
//
#include <xtensor/xarray.hpp>
#include <xtensor/xio.hpp>
#include <xtensor/xbuilder.hpp>
#include <xtensor/xview.hpp>

#if defined(USE_XTENSORPYTHON_ARRAY)
  #include <pybind11/pybind11.h>
  #include <xtensor-python/pyarray.hpp>
#endif

namespace coco {

//
// Define the dynamic array type.
//
#if defined(USE_XTENSORPYTHON_ARRAY)
  template <typename T>
  using xarray_t = xt::pyarray<T>;
#else
  template <typename T>
  using xarray_t = xt::xarray<T>;
#endif


//
// FieldData types
//
using ScalarFieldData = xarray_t<double>;

using VectorFieldData = std::array<xarray_t<double>, 3>;

template <int N>
using TensorFieldData = std::array<xarray_t<double>, N>;


// Type of index triple
using cell_idx_t = std::array<std::size_t, 3>;

}
