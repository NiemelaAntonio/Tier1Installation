/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

namespace coco {

namespace functions {


  template <typename T>
  int sgn(T val) {
    return (T(0) < val) - (val < T(0));
  }


  template <typename T>
  auto sqr(const T val) {
    return val*val;
  }


  // smallest arg if all args positive, largest if all are neg, otherwise zero
  template <typename T>
  T minmod(T x1, T x2)
  {
    return 0.5*(sgn(x1)+sgn(x2))*std::min(std::abs(x1), std::abs(x2));
  }


  template <typename T>
  T minmod(T x1, T x2, T x3)
  {
    const auto s = 0.5*(sgn(x1)+sgn(x2))*std::abs(0.5*(sgn(x1)+sgn(x3)));

    return s*std::min({std::abs(x1), std::abs(x2), std::abs(x3)});
  }


  template <typename T>
  T minmod(T x1, T x2, T x3, T x4)
  {
    const auto s = 0.5*(sgn(x1)+sgn(x2))*std::abs(0.5*(sgn(x1)+sgn(x3))*0.5*(sgn(x1)+sgn(x4)));

    return s*std::min({std::abs(x1), std::abs(x2), std::abs(x3), std::abs(x4)});
  }


  template <typename T>
  T median(T x1, T x2, T x3)
  {
    return x1 + minmod(x2-x1, x3-x1);
  }

}
}
