/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

/**
 * \brief Grid class definitions
 *
 *
 */

#include <array>
#include <boost/range/irange.hpp>

#include "axis.hpp"

namespace coco {

namespace core {

namespace detail {

//
// Note: These will be greatly simplified with C++17 and std::is_detected
// or perhaps using hana::is_valid

// NodeData
struct DefaultNodeDataType {};

template <typename T, typename = void>
struct NodeDataType { using type = DefaultNodeDataType; };

template <typename T>
struct NodeDataType<T, decltype(typename T::NodeData{}, void())> { using type = typename T::NodeData; };


// ZoneData
struct DefaultZoneDataType {};

template <typename T, typename = void>
struct ZoneDataType { using type = DefaultZoneDataType; };

template <typename T>
struct ZoneDataType<T, decltype(typename T::ZoneData{}, void())> { using type = typename T::ZoneData; };


// xFaceCenterData
struct DefaultxFaceCenterDataType {};

template <typename T, typename = void>
struct xFaceCenterDataType { using type = DefaultxFaceCenterDataType; };

template <typename T>
struct xFaceCenterDataType<T, decltype(typename T::xFaceCenterData{}, void())> { using type = typename T::xFaceCenterData; };

// yFaceCenterData
struct DefaultyFaceCenterDataType {};

template <typename T, typename = void>
struct yFaceCenterDataType { using type = DefaultyFaceCenterDataType; };

template <typename T>
struct yFaceCenterDataType<T, decltype(typename T::yFaceCenterData{}, void())> { using type = typename T::yFaceCenterData; };

// zFaceCenterData
struct DefaultzFaceCenterDataType {};

template <typename T, typename = void>
struct zFaceCenterDataType { using type = DefaultzFaceCenterDataType; };

template <typename T>
struct zFaceCenterDataType<T, decltype(typename T::zFaceCenterData{}, void())> { using type = typename T::zFaceCenterData; };


// xEdgeCenterData
struct DefaultxEdgeCenterDataType {};

template <typename T, typename = void>
struct xEdgeCenterDataType { using type = DefaultxEdgeCenterDataType; };

template <typename T>
struct xEdgeCenterDataType<T, decltype(typename T::xEdgeCenterData{}, void())> { using type = typename T::xEdgeCenterData; };

// yEdgeCenterData
struct DefaultyEdgeCenterDataType {};

template <typename T, typename = void>
struct yEdgeCenterDataType { using type = DefaultyEdgeCenterDataType; };

template <typename T>
struct yEdgeCenterDataType<T, decltype(typename T::yEdgeCenterData{}, void())> { using type = typename T::yEdgeCenterData; };

// zEdgeCenterData
struct DefaultzEdgeCenterDataType {};

template <typename T, typename = void>
struct zEdgeCenterDataType { using type = DefaultzEdgeCenterDataType; };

template <typename T>
struct zEdgeCenterDataType<T, decltype(typename T::zEdgeCenterData{}, void())> { using type = typename T::zEdgeCenterData; };


// StaggeredFaceCenterData
struct DefaultStaggeredFaceCenterDataType {};

template <typename T, typename = void>
struct StaggeredFaceCenterDataType { using type = DefaultStaggeredFaceCenterDataType; };

template <typename T>
struct StaggeredFaceCenterDataType<T, decltype(typename T::StaggeredFaceCenterData{}, void())> { using type = typename T::StaggeredFaceCenterData; };


// StaggeredEdgeCenterData
struct DefaultStaggeredEdgeCenterDataType {};

template <typename T, typename = void>
struct StaggeredEdgeCenterDataType { using type = DefaultStaggeredEdgeCenterDataType; };

template <typename T>
struct StaggeredEdgeCenterDataType<T, decltype(typename T::StaggeredEdgeCenterData{}, void())> { using type = typename T::StaggeredEdgeCenterData; };

}


template <class DataTypes>
class RectilinearGrid
{
public:

  using size_type = CoordinateAxis::array_t::size_type;


  // Axis in each coordinate direction
  std::array<CoordinateAxis, 3> axis;


  // Number of ghost cells in each direction
  std::array<size_type, 3> num_ghost_cells;

  //
  // Data
  //
  struct GridData
  {
    typename detail::NodeDataType<DataTypes>::type node;
    typename detail::ZoneDataType<DataTypes>::type zone;

    typename detail::xFaceCenterDataType<DataTypes>::type xface;
    typename detail::yFaceCenterDataType<DataTypes>::type yface;
    typename detail::zFaceCenterDataType<DataTypes>::type zface;

    typename detail::xEdgeCenterDataType<DataTypes>::type xedge;
    typename detail::yEdgeCenterDataType<DataTypes>::type yedge;
    typename detail::zEdgeCenterDataType<DataTypes>::type zedge;

    typename detail::StaggeredFaceCenterDataType<DataTypes>::type staggered_face;
    typename detail::StaggeredEdgeCenterDataType<DataTypes>::type staggered_edge;
  };

  GridData data;

public:

  RectilinearGrid() : num_ghost_cells{{0, 0, 0}} {}


  /**
   * Return the total number of cells in each dimension of the grid
   */
  auto num_cells() const -> std::array<size_type, 3>
  {
    return {{axis[0].num_crds()-1, axis[1].num_crds()-1, axis[2].num_crds()-1}};
  }

  /**
   * Return the total number of indomain cells in each dimension of the grid
   */
  auto num_indomain_cells() const -> std::array<size_type, 3>
  {
    return {{axis[0].num_crds()-1-2*num_ghost_cells[0],
             axis[1].num_crds()-1-2*num_ghost_cells[1],
             axis[2].num_crds()-1-2*num_ghost_cells[2]}};
  }


  /**
   * Return the total number of nodes in each dimension in the grid
   */
  auto num_nodes() const -> std::array<size_type, 3>
  {
    return {{axis[0].num_crds(), axis[1].num_crds(), axis[2].num_crds()}};
  }

  /**
   * Return the total number of indomain cell nodes in each dimension in the grid
   */
  auto num_indomain_nodes() const -> std::array<size_type, 3>
  {
    return {{axis[0].num_crds()-2*num_ghost_cells[0],
             axis[1].num_crds()-2*num_ghost_cells[1],
             axis[2].num_crds()-2*num_ghost_cells[2]}};
  }


  /**
   * Return the total number of faces in the given direction
   */
  auto num_faces(const int dim) const -> std::array<size_type, 3>
  {
    auto total_num_faces = num_cells();  total_num_faces[dim] += 1;
    return total_num_faces;
  }

  /**
   * Return the total number of faces of indomain cells in the given direction
   */
  auto num_indomain_faces(const int dim) const -> std::array<size_type, 3>
  {
    auto num_faces = num_indomain_cells();  num_faces[dim] += 1;
    return num_faces;
  }


  /**
   * Return the total number of edges in the given direction
   */
  auto num_edges(const int dim) const -> std::array<size_type, 3>
  {
    auto n_edges = num_nodes();  n_edges[dim] -= 1;
    return n_edges;
  }


  /**
   * Return the total number of edges of indomain cells in the given direction
   */
  auto num_indomain_edges(const int dim) const -> std::array<size_type, 3>
  {
    auto n_indomain_edges = num_indomain_nodes();  n_indomain_edges[dim] -= 1;
    return n_indomain_edges;
  }


  /**
   * Returns the first and last index of the cells in the given dir.
   *
   */
  auto cell_index_extents(const int dim) const -> std::array<size_type, 2>
  {
    return {{0, num_cells()[dim]-1}};
  }

  /**
   * Returns the first and last index of the indomain cells in the given dir.
   *
   */
  auto indomain_cell_index_extents(const int dim) const -> std::array<size_type, 2>
  {
    return {{num_ghost_cells[dim], num_cells()[dim]-num_ghost_cells[dim]-1}};
  }


  /**
   * Returns the first and last index of the cell nodes in the given dir.
   *
   */
  auto node_index_extents(const int dim) const -> std::array<size_type, 2>
  {
    return {{0, num_nodes()[dim]-1}};
  }

  /**
   * Returns the first and last index of the indomain cell nodes in the given dir.
   *
   */
  auto indomain_node_index_extents(const int dim) const -> std::array<size_type, 2>
  {
    return {{num_ghost_cells[dim], num_nodes()[dim]-num_ghost_cells[dim]-1}};
  }


  /**
   * Return the index range of all cells in the given dimension
   */
  auto cell_index_range(const int dim) const
  {
    return index_range(cell_index_extents(dim)[0],
                       cell_index_extents(dim)[1]);
  }

  /**
   * Return the index range of indomain cells in the given dimension
   */
  auto indomain_cell_index_range(const int dim) const
  {
    return index_range(indomain_cell_index_extents(dim)[0],
                       indomain_cell_index_extents(dim)[1]);
  }

  /**
   * Return the index range of all the cell nodes in the given dimension
   */
  auto node_index_range(const int dim) const
  {
    return index_range(node_index_extents(dim)[0],
                       node_index_extents(dim)[1]);
  }


  /**
   * Return the index range of all the indomain cell nodes in the given dimension
   */
  auto indomain_node_index_range(const int dim) const
  {
    return index_range(indomain_node_index_extents(dim)[0],
                       indomain_node_index_extents(dim)[1]);
  }


  /**
   * Return the index range of indomain x-directed faces in the given dimension
   */
  auto indomain_xface_index_range(const int dim) const
  {
    const auto first_idx = num_ghost_cells[dim];
    const auto last_idx  = num_ghost_cells[dim] + num_indomain_faces(0)[dim] - 1;

    return index_range(first_idx, last_idx);
  }

  auto indomain_yface_index_range(const int dim) const
  {
    const auto first_idx = num_ghost_cells[dim];
    const auto last_idx  = num_ghost_cells[dim] + num_indomain_faces(1)[dim] - 1;

    return index_range(first_idx, last_idx);
  }

  auto indomain_zface_index_range(const int dim) const
  {
    const auto first_idx = num_ghost_cells[dim];
    const auto last_idx  = num_ghost_cells[dim] + num_indomain_faces(2)[dim] - 1;

    return index_range(first_idx, last_idx);
  }


  /**
   *
   */
  auto indomain_xedge_index_range(const int dim) const
  {
    const auto first_idx = num_ghost_cells[dim];
    const auto last_idx  = num_ghost_cells[dim] + num_indomain_edges(0)[dim] - 1;

    return index_range(first_idx, last_idx);
  }

  auto indomain_yedge_index_range(const int dim) const
  {
    const auto first_idx = num_ghost_cells[dim];
    const auto last_idx  = num_ghost_cells[dim] + num_indomain_edges(1)[dim] - 1;

    return index_range(first_idx, last_idx);
  }

  auto indomain_zedge_index_range(const int dim) const
  {
    const auto first_idx = num_ghost_cells[dim];
    const auto last_idx  = num_ghost_cells[dim] + num_indomain_edges(2)[dim] - 1;

    return index_range(first_idx, last_idx);
  }


  template <class TField>
  void allocate(decltype(data.zone), TField & f)
  {
    allocate(f, this->num_cells());
  }


  template <class TField>
  void allocate(decltype(data.node), TField & f)
  {
    allocate(f, this->num_nodes());
  }


  template <class TField>
  void allocate(decltype(data.xface), TField & f)
  {
    allocate(f, this->num_faces(0));
  }


  template <class TField>
  void allocate(decltype(data.yface), TField & f)
  {
    allocate(f, this->num_faces(1));
  }


  template <class TField>
  void allocate(decltype(data.zface), TField & f)
  {
    allocate(f, this->num_faces(2));
  }


  template <class TField>
  void allocate(decltype(data.xedge), TField & f)
  {
    allocate(f, this->num_edges(0));
  }


  template <class TField>
  void allocate(decltype(data.yedge), TField & f)
  {
    allocate(f, this->num_edges(1));
  }


  template <class TField>
  void allocate(decltype(data.zedge), TField & f)
  {
    allocate(f, this->num_edges(2));
  }


  void allocate(decltype(data.staggered_face), VectorFieldData & v)
  {
    const auto num_cells = this->num_cells();

    v[0] = xt::zeros<double, std::vector<size_t>>({num_cells[0]+1, num_cells[1]  , num_cells[2]});
    v[1] = xt::zeros<double, std::vector<size_t>>({num_cells[0]  , num_cells[1]+1, num_cells[2]});
    v[2] = xt::zeros<double, std::vector<size_t>>({num_cells[0]  , num_cells[1]  , num_cells[2]+1});
  }

  void allocate(decltype(data.staggered_edge), VectorFieldData & v)
  {
    const auto num_cells = this->num_cells();

    v[0] = xt::zeros<double, std::vector<size_t>>({num_cells[0]  , num_cells[1]+1, num_cells[2]+1});
    v[1] = xt::zeros<double, std::vector<size_t>>({num_cells[0]+1, num_cells[1],   num_cells[2]+1});
    v[2] = xt::zeros<double, std::vector<size_t>>({num_cells[0]+1, num_cells[1]+1, num_cells[2]});
  }


  /**
   * Returns integer index range starting from first_idx and ending (inclusively)
   * at last_idx
   */
  template <class T>
  auto index_range(const T first_idx, const T last_idx) const
  {
    return boost::irange(first_idx, last_idx+1);
  }


private:


  void allocate(ScalarFieldData & f, std::array<std::size_t, 3> shape)
  {
    f = xt::zeros<double, std::vector<size_t>>({shape[0], shape[1], shape[2]});
  }

  void allocate(VectorFieldData & v, std::array<std::size_t, 3> shape)
  {
    for (int dim : {0, 1, 2}) {
      v[dim] = xt::zeros<double, std::vector<size_t>>({shape[0], shape[1], shape[2]});
    }
  }


};

}
}
