# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module defining classes related to handling events in the simulation loop.
"""

import numpy as np


class EventList(object):
    def __init__(self):
        self.elist = []

    def __str__(self):

        message = "Registered events: \n"
        for event in self.elist:
            message += " " + event.description + "\n"
        return message

    def add(self, event):
        self.elist.append(event)

    def time_at_next(self):
        t_next = self.elist[0].t_next

        for event in self.elist:
            if event.t_next < t_next:
                t_next = event.t_next

        return t_next

    def check(self, t):
        for event in self.elist:
            event.check(t)


class Event(object):
    def __init__(self, **kwargs):

        self.initialize(**kwargs)

    def __str__(self):
        """Return basic information
        """

        message = self.description + "\n" if self.description is not None else ""
        message += "Start:                " + str(self.t_start) + "\n"
        message += "Stop:                 " + str(self.t_stop) + "\n"
        message += "Next:                 " + str(self.t_next) + "\n"
        message += "Interval:             " + str(self.interval) + "\n"
        message += "Counts:               " + str(self.counter)

        return message

    def initialize(self, **kwargs):

        self.description = kwargs.get("description", "")

        self.t_start = kwargs.get("start", 0.0)
        self.t_stop = kwargs.get("stop", np.Inf)
        self.interval = kwargs.get("interval", 1.0)
        self.counter = 0

        self._do_stop = False

    @property
    def t_next(self):

        t_plus_dt = self.t_start + self.interval * self.counter

        return np.Inf if self._do_stop else t_plus_dt

    def check(self, t):

        if np.isclose(t, self.t_next) and not self._do_stop:

            # Trigger event
            self.run()

            # Check if this is the last time to trigger the event
            self._do_stop = True if np.isclose(t, self.t_stop) else False

            # Increase the counter
            self.counter += 1

    def run(self):
        pass
