# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module providing MPI support
"""

import copy
import warnings

import coco.core.coordinates

warnings.simplefilter("always", ImportWarning)


use_mpi = False
rank = 0
num_processes = 1

#
# Import and initialize MPI. If the mpi4py package is not found, or if it is
# found but only one process is used, a serial run is performed
#
try:
    from mpi4py import MPI as mpi

    num_processes = mpi.COMM_WORLD.size

    if num_processes > 1:
        use_mpi = True
        rank = mpi.COMM_WORLD.rank

except ImportError:
    use_mpi = False

    warnings.warn(
        "Package mpi4py not found: performing serial run. "
        "NOTE: if you ran using mpirun, the code will be "
        "run in serial np times.",
        ImportWarning,
    )


class DomainDecomposition(object):
    """
    input: global grid
    output: local patch for this proc.
    """

    def __init__(self, **kwargs):
        pass

    def create_local_grid(self, grid, **kwargs):

        #
        # Store basic data
        #
        self.rank = mpi.COMM_WORLD.rank

        self.method = kwargs.get("method", "cartesian")

        #
        # Decompose domain using Cartesian topology
        #
        if self.method == "cartesian":

            blocks = kwargs.get("blocks", None)

            # Determine partitioning scheme
            if blocks is None:

                if len(grid.ignorable_axes) == 0:
                    blocks = mpi.Compute_dims(mpi.COMM_WORLD.size, 3)

                if len(grid.ignorable_axes) == 1:
                    blocks = mpi.Compute_dims(mpi.COMM_WORLD.size, 2)
                    blocks.insert(grid.ignorable_axes[0], 1)

                if len(grid.ignorable_axes) == 2:
                    blocks = [1, 1, 1]
                    blocks[grid.ignorable_axes[0]] = mpi.COMM_WORLD.size

            # Create and store Cartesian topology communicator.
            # Each direction is set to be periodic.
            # Non-periodic cases are corrected for later after the
            # boundary conditions have been specified at which point it is
            # known whether some direction is not periodic
            self.comm = mpi.COMM_WORLD.Create_cart(blocks, periods=(True, True, True), reorder=False)

            # Store MPI block data
            self.blocks = blocks

            # Assign function to get local coordinates
            self.get_coordinates_of_local_patch = self.map_coordinates_using_cartesian_topology

        #
        # Get coordinates of patch owned by the current rank
        #
        new_coordinates = self.get_coordinates_of_local_patch(grid)

        #
        # Instantiate new grid given the coordinates
        #
        patch = copy.deepcopy(grid)
        for dim in range(3):
            patch.axis[dim].coordinates = new_coordinates[dim]

        # Add rank info
        patch.rank = self.rank

        return patch

    def set_internal_boundaries(self, boundary_conditions):
        """Removes boundary condition information for internal MPI boundaries.
        """

        block_crd = self.comm.Get_coords(self.rank)

        for dim in (0, 1, 2):
            if block_crd[dim] > 0:
                boundary_conditions[dim].lower = None

            if block_crd[dim] < (self.blocks[dim] - 1):
                boundary_conditions[dim].upper = None

    def map_coordinates_using_cartesian_topology(self, grid):

        #
        # Coordinates of entire grid
        #
        coordinates = grid.edge_coords

        #
        # Ensure number of grid points in each dir >= number of blocks in that dir
        #
        for dim in range(3):
            if self.blocks[dim] > len(coordinates[dim]):
                raise ValueError("Number of MPI blocks exceeds number of " "grid points in x" + str(dim + 1))

        #
        # Partition each direction according to the number of blocks.
        # This is done in serial.
        #
        if self.rank == 0:

            # Determine minimum number of coordinates needed
            # in the first and last partitions of each dimension.
            # This is needed to ensure that the ghost cells have access to
            # in-domain data. The extreme case is that the BC uses a one-sided
            # extrapolation using the entire available stencil.
            stencil_width = 1 + 2*max(grid.num_ghost_cells)
            min_num_coords_at_edges = stencil_width

            partition_crds = []
            for dim in range(3):
                crds = coco.core.coordinates.partition_interval(
                    coordinates[dim], self.blocks[dim], min_num_coords_at_edges, grid.num_ghost_cells[dim]
                )

                partition_crds.append(crds)
        else:
            partition_crds = None

        #
        # Inform each rank of how the coordinates have been partitioned
        #
        partition_crds = self.comm.bcast(partition_crds, root=0)

        #
        # Get block coordinates of the patch owned by the current rank
        #
        block_coord = self.comm.Get_coords(self.rank)

        #
        # Get the coordinates of the patch owned by the current rank
        #
        local_coordinates = []
        for dim in range(3):
            local_coordinates.append(partition_crds[dim][block_coord[dim]])

        return local_coordinates
