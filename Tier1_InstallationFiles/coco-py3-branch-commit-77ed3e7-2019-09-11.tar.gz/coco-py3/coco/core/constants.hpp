/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

namespace coco {

namespace constants {

namespace math {

  /* should probably use the value given by boost::math::constants::pi<double>() */
  const double pi = 3.141592653589793238462643383279502884197169399375105820974944;

}

namespace physics {

  constexpr double kB   = 1.38064852e-23;
  constexpr double G    = 6.67408e-11;
  constexpr double mp   = 1.672621898e-27;
  constexpr double mu0  = 1.25663706144e-6;  // 4pi1e-7 !!!

  constexpr double proton_mass = mp;

}

namespace solar {

  constexpr double GM     = 1.3271244e20;
  constexpr double mass   = GM/physics::G;
  constexpr double radius = 695700.0e3;
  constexpr double gravitational_acceleration = GM/(radius*radius);

}


constexpr double astronomical_unit = 149597870700.0;

}

}
