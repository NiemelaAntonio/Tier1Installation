# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module defining functionality related to boundary conditions.
"""

import namedlist


class BoundaryConditionInfo(object):
    def __init__(self):
        self.ghost_cells = lambda: None
        self.flux = lambda: None


def create_boundary_condition_containers(grid):
    """Creates containers for storing boundary condition info.
    """

    # The simulation has three coordinate directions that need BCs.
    # Each direction is contained as a namedlist using the names
    # given to the coordinate axes.
    axis_names = [grid.axis[dim].name for dim in range(3)]

    Boundary = namedlist.namedlist("Boundary", axis_names)

    # Each dimension has an "upper" and a "lower" boundary
    BoundaryPair = namedlist.namedlist("BoundaryPair", ["upper", "lower"])

    #
    # Each boundary is initialized with an instance of BoundaryConditionInfo
    #
    boundary_pairs = [BoundaryPair(BoundaryConditionInfo(), BoundaryConditionInfo()) for dim in range(3)]

    return Boundary(*boundary_pairs)
