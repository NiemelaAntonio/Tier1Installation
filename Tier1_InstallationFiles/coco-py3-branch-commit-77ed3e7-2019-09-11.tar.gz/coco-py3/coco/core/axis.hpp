/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

/**
 * \brief Coordinate axis class definitions
 *
 *
 */


namespace coco {

namespace core {


/**
 * \brief Class defining a discrete spatial interval.
 *
 * CoordinateAxis is a class for storing a set of strictly increasing numbers
 * that discretizes an interval of space in one dimension. The typical use case
 * for the class arises from the fact that a N-dimensional rectilinear grid is
 * a tensor product of N such intervals.
 *
 * The interval is defined in terms of "edge" points, i.e. the stored coordinate
 * values themselves. Artihmetic averages of the edges define "center" points.
 */
class CoordinateAxis
{
public:

  // Shorthand to the xtensor container that the class uses
  using array_t = xarray_t<double>;


  /**
   * Return the number of coordinates in the axis
   */
  array_t::size_type num_crds() const
  {
    return coordinates.size();
  }


  /**
   * Return a copy of the coordinates of the axis, i.e. the edge points
   */
  array_t edges() const
  {
    return coordinates;
  }


  /**
   * Return a copy of the center coordinates of the axis
   */
  array_t centers() const
  {
    const auto N = coordinates.size();

    return 0.5*(  xt::make_xview(coordinates, xt::range(static_cast<array_t::size_type>(0), N-1))
                + xt::make_xview(coordinates, xt::range(static_cast<array_t::size_type>(1), N  )));
  }


  /**
   * Return the center coordinate at the given index
   */
  double center(const int idx) const
  {
    return 0.5*(coordinates(idx+1)+coordinates(idx));
  }


  /**
   * Return the coordinate displacement (mesh size) at the given index
   */
  double delta(const int idx) const
  {
    return coordinates(idx+1)-coordinates(idx);
  }


  /**
   * Return distance between coordinates
   */
  array_t spacing() const
  {
    const auto N = coordinates.size();

    return   xt::make_xview(coordinates, xt::range(static_cast<array_t::size_type>(1), N  ))
           - xt::make_xview(coordinates, xt::range(static_cast<array_t::size_type>(0), N-1));
  }

  // TODO
  /**
   * Return idx of the coordinate closest to the given coordinate
   *
   */

  /**
   * Returns the index of the first coordinate of the axis for which
   *
   *    coordinates(index+1) >= x
   *
   * where x is the given coordinate. In other words, the index to
   * the coordinate that is closest to x to the left (neg. coordinate
   * direction) is returned.
   *
   * ? return int
   * ? should be able to call the grid data with the index..
   * ? behaviour when outside interval
   */
  int get_left_index_of(const double x) const
  {

    // Check if x not in interval
    if (x < coordinates(0))
      return -1;

    if (x > coordinates(num_crds()-1))
      return -1;

    // Slow linear search of the coordinate array
    int idx = 0;
    for (size_t i=0; i<coordinates.size()-1; ++i) {
      if (coordinates(i+1)>=x) {
        idx = i;
        break;
      }
    }

    return idx;
  }


public:

  array_t coordinates;

};

}
}
