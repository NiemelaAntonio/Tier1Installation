/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include "coco/core/functions.hpp"

namespace coco {

namespace limiters {


  struct Zero
  {
    auto operator() (const double, const double) const
    {
      return 0.0;
    }
  };


  struct VanLeer
  {
    auto operator() (const double x, const double y) const
    {
      return x*y > 0.0 ? 2.0*x*y/(x+y) : 0.0;
    }
  };


  struct MinMod
  {
    auto operator() (const double x, const double y) const
    {
      return functions::minmod(x, y);
    }
  };

}
}
