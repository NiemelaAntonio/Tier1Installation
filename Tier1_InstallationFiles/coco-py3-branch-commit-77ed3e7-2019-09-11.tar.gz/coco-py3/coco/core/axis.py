# This file is part of CoCo.
#
# Copyright 2016, 2017, 2019 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module defining a coordinate axis.
"""

import numpy as np

import coco.core.coordinates


class CoordinateAxis(object):
    """Class defining a discretized spatial interval.

    A coordinate axis is a set of strictly increasing numbers that discretizes
    an interval of space in one dimension. The typical use case arises from the
    fact that a N-dimensional rectilinear grid is a tensor product of N
    coordinate axes.

    Attributes:
        unit (float)  : Float defining the unit (typically length) of the coordinates.
                        Default: None
        name (str)    : String describing the axis. Default: None.
        coordinates (array) : The coordinates that make up the interval

    Example usage:

        >>> r   = CoordinateAxis(name='radius', unit=coco.constants.solar_radius)
        >>> r.construct_uniform(1.0, 2.5, 100)

        >>> lon = CoordinateAxis(name='longitude', periodic=True)
        >>> lon.coordinates = np.linspace(-1.0, 1.0, 200)*np.pi
    """

    def __init__(self, **kwargs):

        self.unit = kwargs.get("unit", 1.0)
        self.name = kwargs.get("name", None)

        self.coordinates = None

    @property
    def num_crds(self):
        """Returns the number of coordinates in the axis.
        """
        return len(self.coordinates)

    @property
    def spacing(self):
        """Returns distance between coordinates.
        """
        return self.coordinates[1::] - self.coordinates[0:-1]

    @property
    def edges(self):
        """Returns coordinates (convenience function).
        """
        return self.coordinates

    @property
    def centers(self):
        """Returns center coordinates.
        """
        return 0.5*(self.coordinates[0:-1] + self.coordinates[1::])

    @property
    def extent(self):
        """Returns the domain coordinate extent.
        """
        return np.array((self.coordinates[0], self.coordinates[-1]))

    def check(self):
        """Perform checks to verify that the axis is correctly constructed.
        """

        # Check that coordinates are monotonously increasing
        if not np.all(self.coordinates[1:] > self.coordinates[:-1]):
            raise ValueError("Coordinates not monotonously increasing")

    def add_mirrored_coordinates(self):

        reflected_crds = 2.0*self.coordinates[0] - self.coordinates[::-1]

        self.coordinates = np.concatenate((reflected_crds, self.coordinates[1::]))

    def construct_uniform(self, start, end, num):
        """Construct coordinates at constant distance from each other.
        """
        self.coordinates = np.linspace(start, end, num)*self.unit

    def construct_constant_ratio(self, start, end, num, dx_at_start):

        crds = coco.core.coordinates.constant_ratio_coordinates(
            start=start, end=end, num_points=num, dx_at_start=dx_at_start
        )
        self.coordinates = crds*self.unit

    def add_coordinates(self, num):
        """Add coordinates at each end of coordinate array.

        Adds given number of coordinates at each end of the interval.
        The addition is made using the same grid spacing as found
        at the ends.

        Args:
            num :  number of coordinates to insert at each end
        """

        if num == 0:
            return

        x = np.copy(self.coordinates)
        xextended = np.zeros(len(x) + 2*num)
        xextended[num:-num] = x

        for idx in range(0, num):
            # lower edge:
            xextended[idx] = x[0] - (num - idx)*(x[1] - x[0])
            # upper edge:
            xextended[idx + len(x) + num] = x[-1] + (idx + 1)*(x[-1] - x[-2])

        self.coordinates = np.copy(xextended)

    def remove_coordinates(self, num):
        """Remove coordinates at each end of coordinate array.

        Removes given number of coordinates at each end of the interval.

        Args:
            num :  number of coordinates to remove at each end
        """

        if num == 0:
            return

        x = np.copy(self.coordinates)
        self.coordinates = np.copy(x[num:-num])
