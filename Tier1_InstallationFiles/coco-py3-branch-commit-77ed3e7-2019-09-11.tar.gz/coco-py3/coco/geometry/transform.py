# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""Module for computing coordinate transformations.
"""


import numpy as np


def cylindrical_coordinate_to_cartesian(crd):

    r = crd[0]
    t = crd[1]
    z = crd[2]

    x = r*np.cos(t)
    y = r*np.sin(t)

    return np.array((x, y, z))


def spherical_coordinate_to_cartesian(crd):

    r = crd[0]
    t = crd[1]
    p = crd[2]

    x = r*np.sin(t)*np.cos(p)
    y = r*np.sin(t)*np.sin(p)
    z = r*np.cos(t)

    return np.array((x, y, z))


def cartesian_coordinate_to_cylindrical(crd):

    x = crd[0]
    y = crd[1]
    z = crd[2]

    r = np.sqrt(x*x + y*y)
    t = np.arctan2(y, x)

    return np.array((r, t, z))


def cartesian_coordinate_to_spherical(crd):

    x = crd[0]
    y = crd[1]
    z = crd[2]

    r = np.sqrt(x*x + y*y + z*z)
    t = np.arccos(z / r)
    p = np.arctan2(y, x)

    return np.array((r, t, p))


def cylindrical_vector_to_cartesian(vec, crd):

    t = crd[1]
    Br = vec[0]
    Bt = vec[1]
    Bz = vec[2]

    Bx = Br*np.cos(t) - Bt*np.sin(t)
    By = Br*np.sin(t) + Bt*np.cos(t)

    return np.array((Bx, By, Bz))


def spherical_vector_to_cartesian(vec, crd):

    t = crd[1]
    p = crd[2]
    Br = vec[0]
    Bt = vec[1]
    Bp = vec[2]

    Bx = Br*np.sin(t)*np.cos(p) + Bt*np.cos(t)*np.cos(p) - Bp*np.sin(p)
    By = Br*np.sin(t)*np.sin(p) + Bt*np.cos(t)*np.sin(p) + Bp*np.cos(p)
    Bz = Br*np.cos(t) - Bt*np.sin(t)

    return np.array((Bx, By, Bz))


def cartesian_vector_to_cylindrical(vec, crd):

    cyl_crd = cartesian_coordinate_to_cylindrical(crd)

    t = cyl_crd[1]
    Bx = vec[0]
    By = vec[1]
    Bz = vec[2]

    Br = Bx*np.cos(t) + By*np.sin(t)
    Bt = -Bx*np.sin(t) + By*np.cos(t)

    return np.array((Br, Bt, Bz))


def cartesian_vector_to_spherical(vec, crd, is_cartesian):

    if is_cartesian:
        sph_crd = cartesian_coordinate_to_spherical(crd)
    else:
        sph_crd = crd

    t = sph_crd[1]
    p = sph_crd[2]
    Bx = vec[0]
    By = vec[1]
    Bz = vec[2]

    Br = Bx*np.sin(t)*np.cos(p) + By*np.sin(t)*np.sin(p) + Bz*np.cos(t)
    Bt = Bx*np.cos(t)*np.cos(p) + By*np.cos(t)*np.sin(p) - Bz*np.sin(t)
    Bp = -Bx*np.sin(p) + By*np.cos(p)

    return np.array((Br, Bt, Bp))
