/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <array>
#include <functional>
#include <math.h>

#include "coco/core/axis.hpp"


namespace coco {

namespace geometry {


class Cartesian
{
public:

  static const std::string name() { return std::string("cartesian"); }

  std::array<std::reference_wrapper<const core::CoordinateAxis::array_t>, 3> x;


public:

  Cartesian(const core::CoordinateAxis::array_t & x1,
            const core::CoordinateAxis::array_t & x2,
            const core::CoordinateAxis::array_t & x3) : x{{x1, x2, x3}} {}



  std::array<double, 3> delta(const cell_idx_t idx) const
  {
    const auto i  = idx[0], j = idx[1], k = idx[2];

    return {{x[0](i+1)-x[0](i), x[1](j+1)-x[1](j), x[2](k+1)-x[2](k)}};
  }

  /**
   * Geometry scale factors
   *
   */
  double h1(const double, const double, const double) const
  {
   return 1.0;
  }

  double h2(const double, const double, const double) const
  {
    return 1.0;
  }

  double h3(const double, const double, const double) const
  {
    return 1.0;
  }


  /**
   *  Computes
   *
   *   \f[
   *      V = \int_{x^-}^{x^+}\int_{y^-}^{y^+}\int_{z^-}^{z^+} dx dy dz
   *   \f]
   *
   */
  double cell_volume(const cell_idx_t idx) const
  {
    const auto dx = delta(idx);

    return dx[0]*dx[1]*dx[2];
  }


  double cell_face_area(const cell_idx_t idx, const int dim, const int dir) const
  {
    const auto i = idx[0], j = idx[1], k = idx[2];

    double face_area(0);

    const auto direction = (dim+1)*dir;

    switch (direction) {
      case (-1): face_area = cell_area_in_dir_0(idx, x[0](i  )); break;
      case (+1): face_area = cell_area_in_dir_0(idx, x[0](i+1)); break;

      case (-2): face_area = cell_area_in_dir_1(idx, x[1](j  )); break;
      case (+2): face_area = cell_area_in_dir_1(idx, x[1](j+1)); break;

      case (-3): face_area = cell_area_in_dir_2(idx, x[2](k  )); break;
      case (+3): face_area = cell_area_in_dir_2(idx, x[2](k+1)); break;
    }

    return face_area;
  }


  std::array<double, 4> cell_edge_lengths(const cell_idx_t idx, const int dim) const
  {
    const auto i = idx[0], j = idx[1], k = idx[2];

    std::array<double, 4> edge_lengths;

    switch (dim) {

    case (0):
     {
       edge_lengths[0] = cell_length_in_dir_0(idx, x[1](j  ), x[2](k  ));
       edge_lengths[1] = cell_length_in_dir_0(idx, x[1](j+1), x[2](k  ));
       edge_lengths[2] = cell_length_in_dir_0(idx, x[1](j  ), x[2](k+1));
       edge_lengths[3] = cell_length_in_dir_0(idx, x[1](j+1), x[2](k+1));
       break;
     }

    case (1):
     {
       edge_lengths[0] = cell_length_in_dir_1(idx, x[0](i  ), x[2](k  ));
       edge_lengths[1] = cell_length_in_dir_1(idx, x[0](i+1), x[2](k  ));
       edge_lengths[2] = cell_length_in_dir_1(idx, x[0](i  ), x[2](k+1));
       edge_lengths[3] = cell_length_in_dir_1(idx, x[0](i+1), x[2](k+1));
       break;
     }

    case (2):
     {
       edge_lengths[0] = cell_length_in_dir_2(idx, x[0](i  ), x[1](j  ));
       edge_lengths[1] = cell_length_in_dir_2(idx, x[0](i+1), x[1](j  ));
       edge_lengths[2] = cell_length_in_dir_2(idx, x[0](i  ), x[1](j+1));
       edge_lengths[3] = cell_length_in_dir_2(idx, x[0](i+1), x[1](j+1));
       break;
     }
    }

    return edge_lengths;
  }


  /**
   *  Computes the area
   *
   *   \f[
   *      A_x = \int_{y^-}^{y^+}\int_{z^-}^{z^+}  dy dz
   *   \f]
   *
   */
  double cell_area_in_dir_0(const cell_idx_t idx, const double) const
  {
    const auto dx = delta(idx);

    return dx[1]*dx[2];
  }


  /*!
   *  Computes the area
   *
   *   \f[
   *      A_y = \int_{x^-}^{x^+}\int_{y^-}^{y^+} dx dz
   *   \f]
   *
   */
  double cell_area_in_dir_1(const cell_idx_t idx, const double) const
  {
    const auto dx = delta(idx);

    return dx[0]*dx[2];
  }


  /*!
   *  Computes the area
   *
   *   \f[
   *      A_z = \int_{x^-}^{x^+}\int_{y^-}^{y^+} dx dy
   *   \f]
   *
   */
  double cell_area_in_dir_2(const cell_idx_t idx, const double) const
  {
    const auto dx = delta(idx);

    return dx[0]*dx[1];
  }


  /*!
   *  Computes the length
   *
   *   \f[
   *      L_x = \int_{x^-}^{x^+} dx
   *   \f]
   *
   */
  double cell_length_in_dir_0(const cell_idx_t idx, const double, const double) const
  {
    return delta(idx)[0];
  }


  /*!
   *  Computes the length
   *
   *   \f[
   *      L_y = \int_{y^-}^{y^+} dy
   *   \f]
   *
   */
  double cell_length_in_dir_1(const cell_idx_t idx, const double, const double) const
  {
    return delta(idx)[1];
  }


  /*!
   *  Computes the length
   *
   *   \f[
   *      L_z = \int_{z^-}^{z^+} dz
   *   \f]
   *
   */
  double cell_length_in_dir_2(const cell_idx_t idx, const double, const double) const
  {
    return delta(idx)[2];
  }

};

}
}
