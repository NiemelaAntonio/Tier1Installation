/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once


#include <Eigen/Core>


namespace coco {

namespace geometry {

namespace transform {

namespace cartesian {


/*!
 * \brief Computes spherical coordinates of point given in Cartesian basis.
 *
 * \param[in]  p      Eigen::Vector3d containing Cartesian
 *                    (x, y, z) coordinates
 *
 * \returns    Eigen::Vector3d containing the spherical
 *             (r, clt, lon) = (r, theta, phi) coordinates
 */
auto to_spherical_coordinates(const Eigen::Vector3d & x)
{
  const auto r     = x.norm();
  const auto colat = acos(x[2]/r);
  const auto lon   = atan2(x[1], x[0]);

  return Eigen::Vector3d(r, colat, lon);
}


/*!
 * \brief Computes spherical vector components given a vector in Cartesian basis.
 *
 * \param[in]  V            Eigen::Vector3d containing the vector components in Cartesian
 *                          (Vx, Vy, Vz) basis
 * \param[in]  x            Eigen::Vector3d containing the end point coordinate of the vector.
 * \param[in]  is_cartesian Boolean: if true, x is assumed to contain Cartesian components, else
 *                          x is assumed to contain spherical components
 *
 * \returns    Eigen::Vector3d containing the spherical
 *             (Vr, Vcolat, Vlon) vector
 */
auto to_spherical_vector(const Eigen::Vector3d & V,
                         const Eigen::Vector3d & x,
                         const bool is_cartesian=true)
{
  // p is the coordinate in the spherical basis equivalent to x
  const auto p      = (is_cartesian) ? cartesian::to_spherical_coordinates(x) : x;

  //
  // Compute Cartesian vector components
  //

  const auto Vx      = V[0];
  const auto Vy      = V[1];
  const auto Vz      = V[2];

  const auto colat   = p[1];
  const auto lon     = p[2];

  const auto sin_clt = sin(colat);
  const auto cos_clt = cos(colat);

  const auto sin_lon = sin(lon);
  const auto cos_lon = cos(lon);

  const auto Vr      =  Vx*sin_clt*cos_lon + Vy*sin_clt*sin_lon + Vz*cos_clt;
  const auto Vt      =  Vx*cos_clt*cos_lon + Vy*cos_clt*sin_lon - Vz*sin_clt;
  const auto Vp      = -Vx*sin_lon         + Vy*cos_lon;

  return Eigen::Vector3d(Vr, Vt, Vp);
}

}


namespace spherical {


/*!
* \brief Computes Cartesian coordinates of point given in spherical basis.
*
* \param[in]  p      Eigen::Vector3d containing spherical
*                    (r, colat, lon) = (r, theta, phi) coordinates
*
* \returns    Eigen::Vector3d containing the Cartesian
*             (x, y, z) coordinates
*/
auto to_cartesian_coordinates(const Eigen::Vector3d & p)
{
 const auto r     = p[0];
 const auto colat = p[1];
 const auto lon   = p[2];

 return Eigen::Vector3d(r*sin(colat)*cos(lon),
                        r*sin(colat)*sin(lon),
                        r*cos(colat));
}


/*!
* \brief Computes Cartesian vector components given a vector in spherical basis.
*
* \param[in]  V            Eigen::Vector3d containing the vector components in spherical
*                          (Vr, Vcolat, Vlon) = (Vr, Vtheta, Vphi) basis
* \param[in]  x            Eigen::Vector3d containing the end point coordinate of the vector.
* \param[in]  is_cartesian Boolean: if true, x is assumed to contain Cartesian components, else
*                          x is assumed to contain spherical components
*
* \returns    Eigen::Vector3d containing the Cartesian
*             (Vx, Vy, Vz) vector
*/
auto to_cartesian_vector(const Eigen::Vector3d & V,
                         const Eigen::Vector3d & x,
                         const bool is_cartesian=true)
{

  // p is the coordinate in the spherical basis equivalent to x
  const auto p      = (is_cartesian) ? cartesian::to_spherical_coordinates(x) : x;

  //
  // Compute Cartesian vector components
  //

  const auto Vr     = V[0];
  const auto Vcolat = V[1];
  const auto Vlon   = V[2];

  const auto colat  = p[1];
  const auto lon    = p[2];

  const auto Vx     = Vr*sin(colat)*cos(lon) + Vcolat*cos(colat)*cos(lon) - Vlon*sin(lon);
  const auto Vy     = Vr*sin(colat)*sin(lon) + Vcolat*cos(colat)*sin(lon) + Vlon*cos(lon);
  const auto Vz     = Vr*cos(colat)          - Vcolat*sin(colat);

  return Eigen::Vector3d(Vx, Vy, Vz);
}

}

}
}
}
