/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#define USE_XTENSORPYTHON_ARRAY

#include "coco/core/coco.hpp"

#include "coco/geometry/cartesian.hpp"
#include "coco/geometry/spherical.hpp"

#include "coco/solvers/mhd/kernels/ideal.hpp"



PYBIND11_PLUGIN(ideal)
{
    namespace py = pybind11;

    py::module m("ideal", "Kernel for ideal MHD solver");


    using CartesianMHD = coco::solvers::mhd::IdealMHDSolverKernel<coco::geometry::Cartesian>;
    using SphericalMHD = coco::solvers::mhd::IdealMHDSolverKernel<coco::geometry::Spherical>;


    py::class_<CartesianMHD>(m, "CartesianMHD")
      .def(py::init<>())
      //
      // Init functions
      //
      .def("initialize", &CartesianMHD::initialize)
      .def("set_coordinate_axis", [](CartesianMHD & self,
                                     const int dim,
                                     const decltype(self.grid.axis[0].coordinates) x) { self.grid.axis[dim].coordinates = x; })
      .def("get_coordinate_axis", [](CartesianMHD & self, const int dim) { return self.grid.axis[dim].coordinates;} )
      .def("finalize_init", &CartesianMHD::finalize_initialization)
      //
      // Compute functions
      //
      .def("compute_update", &CartesianMHD::compute_update)
      .def_readonly("wave_crossing_time", &CartesianMHD::minimum_wave_crossing_time)
      .def("update_solution", &CartesianMHD::update_solution)
      //
      // Expose grid data
      //
      .def("mass_density",     [](CartesianMHD & self) { return self.grid.data.zone.mass_density; } )
      .def("pressure",         [](CartesianMHD & self) { return self.grid.data.zone.pressure; } )
      .def("energy_density",   [](CartesianMHD & self) { return self.grid.data.zone.energy_density; } )
      .def("momentum_density", [](CartesianMHD & self, const int dim) { return self.grid.data.zone.momentum_density[dim]; } )
      .def("magnetic_field",   [](CartesianMHD & self, const int dim) { return self.grid.data.staggered_face.magnetic_field[dim]; } )
      .def("electric_field",   [](CartesianMHD & self, const int dim) { return self.grid.data.staggered_edge.electric_field[dim]; } )
      //
      // Expose auxiliary variables
      //
      .def("v2i1",             [](CartesianMHD & self) { return self.grid.data.xface.v2; } )
      .def("v3i1",             [](CartesianMHD & self) { return self.grid.data.xface.v3; } )
      .def("v1i2",             [](CartesianMHD & self) { return self.grid.data.yface.v1; } )
      .def("v3i2",             [](CartesianMHD & self) { return self.grid.data.yface.v3; } )
      .def("v1i3",             [](CartesianMHD & self) { return self.grid.data.zface.v1; } )
      .def("v2i3",             [](CartesianMHD & self) { return self.grid.data.zface.v2; } )
      .def("a1p",              [](CartesianMHD & self) { return self.grid.data.xface.a1p; } )
      .def("a1m",              [](CartesianMHD & self) { return self.grid.data.xface.a1m; } )
      .def("a2p",              [](CartesianMHD & self) { return self.grid.data.yface.a2p; } )
      .def("a2m",              [](CartesianMHD & self) { return self.grid.data.yface.a2m; } )
      .def("a3p",              [](CartesianMHD & self) { return self.grid.data.zface.a3p; } )
      .def("a3m",              [](CartesianMHD & self) { return self.grid.data.zface.a3m; } )
      //
      // Expose parameters
      //
      .def_readwrite("gravity", &CartesianMHD::gravity)
      .def_property("adiabatic_index",
                    [](CartesianMHD & self)            { return self.physics.parameters.adiabatic_index ;},
                    [](CartesianMHD & self, const double val) { self.physics.parameters.adiabatic_index = val; }
                   )
      .def_property("inv_mu0",
                   [](CartesianMHD & self) {            return self.physics.parameters.inv_mu0; },
                   [](CartesianMHD & self, const double val) { self.physics.parameters.inv_mu0 = val; }
                  )
      ;

      py::class_<SphericalMHD>(m, "SphericalMHD")
        .def(py::init<>())
        //
        // Init functions
        //
        .def("initialize", &SphericalMHD::initialize)
        .def("set_coordinate_axis", [](SphericalMHD & self,
                                       const int dim,
                                       const decltype(self.grid.axis[0].coordinates) x) { self.grid.axis[dim].coordinates = x; })
        .def("get_coordinate_axis", [](SphericalMHD & self, const int dim) { return self.grid.axis[dim].coordinates;} )
        .def("finalize_init", &SphericalMHD::finalize_initialization)
        //
        // Compute functions
        //
        .def("compute_update", &SphericalMHD::compute_update)
        .def_readonly("wave_crossing_time", &SphericalMHD::minimum_wave_crossing_time)
        .def("update_solution", &SphericalMHD::update_solution)
        //
        // Expose grid data
        //
        .def("mass_density",     [](SphericalMHD & self) { return self.grid.data.zone.mass_density; } )
        .def("pressure",         [](SphericalMHD & self) { return self.grid.data.zone.pressure; } )
        .def("energy_density",   [](SphericalMHD & self) { return self.grid.data.zone.energy_density; } )
        .def("momentum_density", [](SphericalMHD & self, const int dim) { return self.grid.data.zone.momentum_density[dim]; } )
        .def("magnetic_field",   [](SphericalMHD & self, const int dim) { return self.grid.data.staggered_face.magnetic_field[dim]; } )
        .def("electric_field",   [](SphericalMHD & self, const int dim) { return self.grid.data.staggered_edge.electric_field[dim]; } )
        //
        // Expose auxiliary variables
        //
        .def("v2i1",             [](SphericalMHD & self) { return self.grid.data.xface.v2; } )
        .def("v3i1",             [](SphericalMHD & self) { return self.grid.data.xface.v3; } )
        .def("v1i2",             [](SphericalMHD & self) { return self.grid.data.yface.v1; } )
        .def("v3i2",             [](SphericalMHD & self) { return self.grid.data.yface.v3; } )
        .def("v1i3",             [](SphericalMHD & self) { return self.grid.data.zface.v1; } )
        .def("v2i3",             [](SphericalMHD & self) { return self.grid.data.zface.v2; } )
        .def("a1p",              [](SphericalMHD & self) { return self.grid.data.xface.a1p; } )
        .def("a1m",              [](SphericalMHD & self) { return self.grid.data.xface.a1m; } )
        .def("a2p",              [](SphericalMHD & self) { return self.grid.data.yface.a2p; } )
        .def("a2m",              [](SphericalMHD & self) { return self.grid.data.yface.a2m; } )
        .def("a3p",              [](SphericalMHD & self) { return self.grid.data.zface.a3p; } )
        .def("a3m",              [](SphericalMHD & self) { return self.grid.data.zface.a3m; } )
        //
        // Expose parameters
        //
        .def_readwrite("gravity", &SphericalMHD::gravity)
        .def_property("adiabatic_index",
                      [](SphericalMHD & self)            { return self.physics.parameters.adiabatic_index ;},
                      [](SphericalMHD & self, const double val) { self.physics.parameters.adiabatic_index = val; }
                     )
        .def_property("inv_mu0",
                     [](SphericalMHD & self) {            return self.physics.parameters.inv_mu0; },
                     [](SphericalMHD & self, const double val) { self.physics.parameters.inv_mu0 = val; }
                    )
      ;


  return m.ptr();
}
