/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <boost/mpl/vector.hpp>
#include <gensimcell.hpp>


#include "coco/core/grid.hpp"
#include "coco/physics/variables.hpp"
#include "coco/reconstruction/linear.hpp"
#include "coco/rsolvers/hll.hpp"
#include "coco/rsolvers/signal_speed_estimates.hpp"
#include "coco/core/limiters.hpp"
#include "coco/core/constants.hpp"
#include "coco/core/functions.hpp"


namespace coco {

namespace solvers {

namespace mhd {

// TODO: Generalize the class to a generic Stagg FVM solver class
// TODO: Clean up and document apm, aL, aR

struct Reconstructors
{
  auto reconstruct(variables::MassDensity)   { return reconstruction::Linear<limiters::VanLeer>(); };
  auto reconstruct(variables::Pressure)      { return reconstruction::Linear<limiters::MinMod>(); };
  auto reconstruct(variables::Velocity)      { return reconstruction::Linear<limiters::VanLeer>(); };
  auto reconstruct(variables::MagneticField) { return reconstruction::LinearPreserveNormal<limiters::VanLeer>(); };
};



class IdealMHDPhysics
{
public:

  struct Parameters
  {
    Parameters() : adiabatic_index(5.0/3.0),
                   inv_mu0(1.0/constants::physics::mu0) {}

    double adiabatic_index;
    double inv_mu0;
  };

  Parameters parameters;


  using FluxState = gensimcell::Cell<gensimcell::Always_Transfer,
                                     variables::MassDensity,
                                     variables::MomentumDensity,
                                     variables::EnergyDensity
                                    >;

  using InterfaceState = gensimcell::Cell<gensimcell::Always_Transfer,
                                          variables::MassDensity,
                                          variables::MomentumDensity,
                                          variables::Velocity,
                                          variables::EnergyDensity,
                                          variables::Pressure,
                                          variables::MagneticField
                                         >;

  template <class TState>
  InterfaceState convert_to_complete(const TState & U) const
  {
    using namespace coco::variables;

    InterfaceState s;

    s[MassDensity()]     = U[MassDensity()];
    s[Velocity()]        = U[Velocity()];
    s[Pressure()]        = U[Pressure()];
    s[MagneticField()]   = U[MagneticField()];

    s[MomentumDensity()] = s[MassDensity()]*s[Velocity()];

    const auto kinetic_energy_density
      = 0.5*s[MassDensity()]*s[Velocity()].squaredNorm();

    const auto magnetic_energy_density
      = 0.5*parameters.inv_mu0*s[MagneticField()].squaredNorm();

    const auto thermal_pressure
      = s[Pressure()]/(parameters.adiabatic_index-1.0);

    s[EnergyDensity()]   = kinetic_energy_density + magnetic_energy_density + thermal_pressure;

    return s;
  }


  /*!
   * \brief Compute flux
   *
   *
   */
  FluxState flux(const InterfaceState & U, const unsigned int dir) const
  {
    using namespace coco::variables;

    const double inv_mu0 = parameters.inv_mu0;

    // Fluid velocity
    const auto v       = U[Velocity()];

    // Fluid momentum density
    const auto m       = U[MassDensity()]*v;
    //U[MomentumDensity()];

    // Magnetic field
    const auto B       = U[MagneticField()];
    //const auto B0   = U[PotentialMagneticField()];
    //const auto B    = /*B0 +*/ B1;

    const auto thermal_pressure  = U[Pressure()];

    const auto magnetic_pressure = inv_mu0*(0.5*B.squaredNorm());

    // Total energy density
    const double total_energy_density
      = thermal_pressure/(parameters.adiabatic_index-1.0)
      + magnetic_pressure
      + 0.5*U[MassDensity()]*v.squaredNorm();


    FluxState flux;

    flux[ MassDensity()    ]       =  m[dir];

    flux[ MomentumDensity()]       =  (v[dir])*m + inv_mu0*(-B[dir]*B);
    flux[ MomentumDensity()][dir] +=  thermal_pressure + magnetic_pressure;

    flux[ EnergyDensity()  ]
      = (total_energy_density + thermal_pressure + magnetic_pressure)*v[dir] - inv_mu0*(B.dot(v))*B[dir];

    return flux;
  }

  /*!
   * \brief Computes the fast magnetosonic speed
   *
   * Given a state containing the MHD variables, computes the fast magnetosonic
   * speed, which is the maximum wave speed in MHD.
   *
   */
  double fast_magnetosonic_speed(const InterfaceState & U,
                                 const unsigned int dir) const
  {
    using namespace coco::variables;

    //const auto B1   = U[MagneticField()];
    //const auto B0   = U[PotentialMagneticField()];
    //const auto B    = B0 + B1;
    const auto B = U[MagneticField()];

    // Sound speed squared, c_s^2 = gamma P/rho
    const double cS2 = parameters.adiabatic_index*U[Pressure()]/U[MassDensity()];

    // Alfven speed squared, vA = B/sqrt(mu0 rho)
    const double vA2 = parameters.inv_mu0*(B.squaredNorm()/U[MassDensity()]);

    return (1.0/sqrt(2.0))*sqrt( vA2 + cS2 + sqrt( (vA2+cS2)*(vA2+cS2) - 4.0*cS2*B[dir]*B[dir]/U[MassDensity()]  ) );
  }


  /*!
   * \brief Computes the maximum signal speeds.
   *
   */
   // TODO: Make part of the signal speed estimator:
   // use variadic argument list
   // check whether velocity exists (else : zero)
  std::tuple<double, double> maximum_signal_speeds(const InterfaceState & U,
                                                   const unsigned int dir) const
  {
    using namespace coco::variables;

    const double max_wave_speed = fast_magnetosonic_speed(U, dir);

    const double flow_speed     = U[Velocity()][dir];

    return std::make_tuple(flow_speed-max_wave_speed, flow_speed+max_wave_speed);
  }

};


// TODO: Where do I put this?? Inside the solver class??
// Add as inherited class to Grid via (optional) template??
template <class TGrid>
class GridAccess
{
private:

  TGrid & grid;

public:

  GridAccess(TGrid & g) : grid(g) {}

  auto & operator[](const variables::MassDensity) { return grid.data.zone.mass_density; }
  auto & operator[](const variables::Pressure)    { return grid.data.zone.pressure; }

  auto operator()(const variables::MassDensity, const cell_idx_t idx) const
  {
    return grid.data.zone.mass_density(idx[0], idx[1], idx[2]);
  }

  auto operator()(const variables::Pressure, const cell_idx_t idx) const
  {
    return grid.data.zone.pressure(idx[0], idx[1], idx[2]);
  }

  auto operator()(const variables::Velocity, const cell_idx_t idx) const
  {
    const auto rho = grid.data.zone.mass_density(idx[0], idx[1], idx[2]);

    const auto v1  = grid.data.zone.momentum_density[0](idx[0], idx[1], idx[2])/rho;
    const auto v2  = grid.data.zone.momentum_density[1](idx[0], idx[1], idx[2])/rho;
    const auto v3  = grid.data.zone.momentum_density[2](idx[0], idx[1], idx[2])/rho;

    return variables::Velocity::data_type(v1, v2, v3);
  }

  auto operator()(const variables::MagneticField, const cell_idx_t idx) const
  {
    const auto B1  = grid.data.staggered_face.magnetic_field[0](idx[0], idx[1], idx[2]);
    const auto B2  = grid.data.staggered_face.magnetic_field[1](idx[0], idx[1], idx[2]);
    const auto B3  = grid.data.staggered_face.magnetic_field[2](idx[0], idx[1], idx[2]);

    return variables::MagneticField::data_type(B1, B2, B3);
  }


  void add(const coco::variables::MassDensity::data_type rho, coco::variables::MassDensity, const cell_idx_t idx)
  {
    grid.data.zone.mass_density(idx[0], idx[1], idx[2]) += rho;
  }

  void add(const coco::variables::EnergyDensity::data_type E, coco::variables::EnergyDensity, const cell_idx_t idx)
  {
    grid.data.zone.energy_density(idx[0], idx[1], idx[2]) += E;
  }

  void add(const coco::variables::MomentumDensity::data_type m, coco::variables::MomentumDensity, const cell_idx_t idx)
  {
    grid.data.zone.momentum_density[0](idx[0], idx[1], idx[2]) += m[0];
    grid.data.zone.momentum_density[1](idx[0], idx[1], idx[2]) += m[1];
    grid.data.zone.momentum_density[2](idx[0], idx[1], idx[2]) += m[2];
  }

};


template <class Geometry>
class IdealMHDSolverKernel
{
private:


public:

  IdealMHDSolverKernel() : geometry{grid.axis[0].coordinates,
                                    grid.axis[1].coordinates,
                                    grid.axis[2].coordinates},
                           gravity(false), access_grid(grid), access_update(update)
  {}



  // Define physics class
  using Physics        = IdealMHDPhysics;

  using InterfaceState = Physics::InterfaceState;

  // Physics and data states relevant to the model
  Physics physics;

  // Geometry definiton
  Geometry geometry;

  bool gravity;

  struct GridVariables
  {
    struct ZoneData
    {
      ScalarFieldData mass_density;
      ScalarFieldData energy_density;
      ScalarFieldData pressure;
      VectorFieldData momentum_density;
    };

    struct StaggeredFaceCenterData { VectorFieldData magnetic_field; };
    struct StaggeredEdgeCenterData { VectorFieldData electric_field; };

    struct xFaceCenterData { ScalarFieldData a1p; ScalarFieldData a1m; ScalarFieldData v2; ScalarFieldData v3; };
    struct yFaceCenterData { ScalarFieldData a2p; ScalarFieldData a2m; ScalarFieldData v1; ScalarFieldData v3; };
    struct zFaceCenterData { ScalarFieldData a3p; ScalarFieldData a3m; ScalarFieldData v1; ScalarFieldData v2; };
  };


  // Variables defined at cell center for which to compute
  // update as flux contributions
  using CellCenteredVariables
    = boost::mpl::vector<variables::MassDensity,
                         variables::MomentumDensity,
                         variables::EnergyDensity>;


  // Variables needed for computing fluxes between cells
  using FluxVariables
   = boost::mpl::vector<variables::MassDensity,
                        variables::MomentumDensity,
                        variables::EnergyDensity,
                        variables::MagneticField>;


  core::RectilinearGrid<GridVariables> grid;
  core::RectilinearGrid<GridVariables> update;

  // TODO: Better name, something like get_from_grid
  GridAccess<decltype(grid)>   access_grid;
  GridAccess<decltype(update)> access_update;


  using SignalSpeedEstimate
    = coco::riemannsolvers::DavisSignalSpeedEstimate;

  using RiemannSolver
    = coco::riemannsolvers::HLL<variables::MassDensity, variables::MomentumDensity, variables::EnergyDensity>;


  double minimum_wave_crossing_time;


public:


  void initialize()
  {

    // TODO:
    // Check num_ghost_cells > 0 in all directions


    // TODO!!!!! Determine automatically!!!!
    grid.num_ghost_cells = {{2, 2, 2}};


    //
    // Allocate arrays
    //

    // Zone data
    grid.allocate(grid.data.zone, grid.data.zone.mass_density);
    grid.allocate(grid.data.zone, grid.data.zone.pressure);
    grid.allocate(grid.data.zone, grid.data.zone.energy_density);
    grid.allocate(grid.data.zone, grid.data.zone.momentum_density);

    // Face-center staggered magnetic field
    grid.allocate(grid.data.staggered_face, grid.data.staggered_face.magnetic_field);

    // Edge-centered staggered electric field
    grid.allocate(grid.data.staggered_edge, grid.data.staggered_edge.electric_field);

    // Characteristic speeds
    grid.allocate(grid.data.xface, grid.data.xface.a1p);
    grid.allocate(grid.data.xface, grid.data.xface.a1m);

    grid.allocate(grid.data.yface, grid.data.yface.a2p);
    grid.allocate(grid.data.yface, grid.data.yface.a2m);

    grid.allocate(grid.data.zface, grid.data.zface.a3p);
    grid.allocate(grid.data.zface, grid.data.zface.a3m);

    // Tangential upwinded velocity components
    grid.allocate(grid.data.xface, grid.data.xface.v2);
    grid.allocate(grid.data.xface, grid.data.xface.v3);

    grid.allocate(grid.data.yface, grid.data.yface.v1);
    grid.allocate(grid.data.yface, grid.data.yface.v3);

    grid.allocate(grid.data.zface, grid.data.zface.v1);
    grid.allocate(grid.data.zface, grid.data.zface.v2);


    // Copy axis data
    update.axis = grid.axis;

    // Copy axis data
    update.num_ghost_cells = grid.num_ghost_cells;

    // Zone update data
    update.allocate(update.data.zone, update.data.zone.mass_density);
    update.allocate(update.data.zone, update.data.zone.energy_density);
    update.allocate(update.data.zone, update.data.zone.momentum_density);


    clear_update_array();
  }


  void clear_update_array()
  {
    update.data.zone.mass_density   *= 0.0;
    update.data.zone.energy_density *= 0.0;

    for (const int dim : {0, 1, 2}) {
      update.data.zone.momentum_density[dim] *= 0.0;
    }
  }

  void finalize_initialization()
  {

    //
    // Compute energy density
    //
    for (const auto k : grid.cell_index_range(2)) {
      for (const auto j : grid.cell_index_range(1)) {
        for (const auto i : grid.cell_index_range(0)) {

          const auto rho = grid.data.zone.mass_density(i, j, k);

          const auto m1  = grid.data.zone.momentum_density[0](i, j, k);
          const auto m2  = grid.data.zone.momentum_density[1](i, j, k);
          const auto m3  = grid.data.zone.momentum_density[2](i, j, k);

          // Thermal energy density
          const double thermal_energy_density
            = grid.data.zone.pressure(i, j, k)/(physics.parameters.adiabatic_index-1.0);

          // Kinetic energy density
          const double kinetic_energy_density = 0.5*(m1*m1+m2*m2+m3*m3)/rho;

          // Magnetic energy density

          // Cell-averaged magnetic field components
          const auto B1 = 0.5*(grid.data.staggered_face.magnetic_field[0](i,   j, k)
                             + grid.data.staggered_face.magnetic_field[0](i+1, j, k));

          const auto B2 = 0.5*(grid.data.staggered_face.magnetic_field[1](i, j,   k)
                             + grid.data.staggered_face.magnetic_field[1](i, j+1, k));

          const auto B3 = 0.5*(grid.data.staggered_face.magnetic_field[2](i, j, k)
                             + grid.data.staggered_face.magnetic_field[2](i, j, k+1));

          const double magnetic_energy_density
            = 0.5*physics.parameters.inv_mu0*(B1*B1+B2*B2+B3*B3);

          grid.data.zone.energy_density(i, j, k)
            = thermal_energy_density + kinetic_energy_density + magnetic_energy_density;

        }
      }
    }

  }



  /*
   * Compute time-derivative of MHD variables
   */
  void compute_update()
  {

    //
    // Compute dUdt of cell-centered variables
    //
    compute_cell_centered_update();

    //
    // Add geometry source terms
    //
    if (geometry.name() == "spherical") {
      add_spherical_geometry_source_term();
    }

    //
    // Add gravity source terms
    //
    if (gravity==true) {
      if (geometry.name() == "cartesian") {
        add_cartesian_gravity_source_term();
      }
      if (geometry.name() == "spherical") {
        add_spherical_gravity_source_term();
      }
    }

    //
    // Compute additional interface quantities outside the domain
    //
    compute_interface_values_at_ghosts();


    //
    // Compute electric field
    //
    compute_electric_field();
  }


  /*
   * TODO: deference to Python???
   */
  void update_solution(const double dt)
  {

    //
    // Advance cell-centered quantities
    //

    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          grid.data.zone.mass_density(i, j, k)   += dt*update.data.zone.mass_density(i, j, k);
          grid.data.zone.energy_density(i, j, k) += dt*update.data.zone.energy_density(i, j, k);

          for (const int dim : {0, 1, 2}) {
            grid.data.zone.momentum_density[dim](i, j, k) += dt*update.data.zone.momentum_density[dim](i, j, k);
          }

        }
      }
    }

    //
    // Advance magnetic field
    //
    advance_magnetic_field(dt);

    //
    // Update pressure
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const auto rho = grid.data.zone.mass_density(i, j, k);

          const auto m1  = grid.data.zone.momentum_density[0](i, j, k);
          const auto m2  = grid.data.zone.momentum_density[1](i, j, k);
          const auto m3  = grid.data.zone.momentum_density[2](i, j, k);

          //const auto B   = access_grid(variables::MagneticField{}, {{i, j, k}});

          // Kinetic energy density
          const auto kinetic_energy_density = 0.5*(m1*m1+m2*m2+m3*m3)/rho;

          // Total energy density
          const auto energy_density = grid.data.zone.energy_density(i, j, k);

          // Magnetic energy density

          // Cell-averaged magnetic field components
          const auto B1 = 0.5*(grid.data.staggered_face.magnetic_field[0](i,   j, k)
                             + grid.data.staggered_face.magnetic_field[0](i+1, j, k));

          const auto B2 = 0.5*(grid.data.staggered_face.magnetic_field[1](i, j,   k)
                             + grid.data.staggered_face.magnetic_field[1](i, j+1, k));

          const auto B3 = 0.5*(grid.data.staggered_face.magnetic_field[2](i, j, k)
                             + grid.data.staggered_face.magnetic_field[2](i, j, k+1));

          const auto magnetic_energy_density = 0.5*physics.parameters.inv_mu0*(B1*B1+B2*B2+B3*B3);

          grid.data.zone.pressure(i, j, k)
            = (energy_density - kinetic_energy_density - magnetic_energy_density)*(physics.parameters.adiabatic_index-1.0);

        }
      }
    }

    clear_update_array();
  }

  /**
   * Computes \partial U/\partial t for cell-centered variables
   *
   */
  void compute_cell_centered_update()
  {

    std::array<double, 3> shortest_wave_crossing_time
      = {{ std::numeric_limits<double>::max(),
           std::numeric_limits<double>::max(),
           std::numeric_limits<double>::max() }};


    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          // Index of current cell
          const cell_idx_t cell_idx = {{i, j, k}};

          // Compute volume of current cell
          const auto cell_volume = geometry.cell_volume(cell_idx);

          //
          // Loop over dimensions
          //
          for (const int32_t dim : {0, 1, 2}) {

            //
            // Loop over directions
            //
            for (const int32_t direction : {-1, 1}) {

              //
              // Compute flux in negative direction only at domain boundaries
              //
              if ((direction == -1) and (dim==0) and (i>grid.num_ghost_cells[0]))
                continue;

              if ((direction == -1) and (dim==1) and (j>grid.num_ghost_cells[1]))
                continue;

              if ((direction == -1) and (dim==2) and (k>grid.num_ghost_cells[2]))
                continue;


              // Index of facing cell
              auto neighbor_cell_idx  = cell_idx;
              neighbor_cell_idx[dim] += direction;


              //
              // Compute cell geometry
              //
              const auto face_area
                = geometry.cell_face_area(cell_idx, dim, direction);

              const auto neighbor_cell_volume
                = geometry.cell_volume(neighbor_cell_idx);

              const auto cell_lengths
                = geometry.cell_edge_lengths(cell_idx, dim);

              const auto cell_length
                = *std::min_element(cell_lengths.begin(), cell_lengths.end());


              //
              // Compute flux through the cell boundary
              //
              typename Physics::FluxState flux; double aL; double aR;

              std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, dim, direction);

              const double max_speed = std::max(std::fabs(aL), std::fabs(aR));


              // TODO: Provide mpl vector as template
              // TODO: How to do this generically now that arrays are separated??

              //
              // Add flux contributions to the cells sharing the face
              //
              boost::mpl::for_each< boost::mpl::vector<variables::MassDensity, variables::MomentumDensity, variables::EnergyDensity> >
              (
                [&] (auto q) {
                  const auto flow_rate = direction*(face_area*flux[q]);

                  access_update.add(-flow_rate/cell_volume,          q, cell_idx);
                  access_update.add( flow_rate/neighbor_cell_volume, q, neighbor_cell_idx);
                }
              );

              // TODO!! Should check waves in to each cell
              // TODO!!! Volume is different for the two cells!!!
              const double wave_crossing_time  = cell_length/std::abs(max_speed);

              shortest_wave_crossing_time[dim] = std::min(shortest_wave_crossing_time[dim], wave_crossing_time);

            }

          }

        }
      }
    }

    //
    // store fastest wave mode for time step determination
    //
    minimum_wave_crossing_time = *std::min_element(shortest_wave_crossing_time.begin(),
                                                   shortest_wave_crossing_time.end());

  }


  /*!
   * \brief Build interface state
   *
   * Construct the interface in the direction dir of the current cell
   */
  auto construct_interface_state(const cell_idx_t cell_idx,
                                 const int dim,
                                 const int dir) const
  {
    using namespace coco::variables;


    // TODO: make class member?
    // older GCC did not like it here, moved it inside lambda for now
    //Reconstructors reconstructors;


    //
    // Reconstruct the given variables to the requested interface
    //

    // TODO
    //ReconstructionState interface;
    InterfaceState interface;

    boost::mpl::for_each< boost::mpl::vector<MassDensity, Pressure, Velocity/*, MagneticField*/> >
    (
      [&] (const auto q) {

        // Helper function that calls the function that fetches data from the
        // grid and serves it to the reconstruction function in the form of the
        // data_type of the variable
        const auto data_mapper
          = [this, q] (const cell_idx_t idx) { return access_grid(q, idx); };

        // Instantiate reconstructor for this quantity
        Reconstructors reconstructors;
        decltype(reconstructors.reconstruct(q)) reconstructor;

        // Compute interface value.
        const auto q_at_interface
          = reconstructor.compute(cell_idx, dim, dir, data_mapper);

        // Insert result in state
        interface[q] = q_at_interface;
      }
    );

    // TODO: generalize
    // Separate reconstruction for the magnetic field for now
    Reconstructors reconstructors;
    decltype(reconstructors.reconstruct(variables::MagneticField{})) B_reconstructor;

    // face idx
    auto face_idx  = cell_idx;
    face_idx[dim] += (dir > 0 ? 1 : 0);

    // normal component
    interface[variables::MagneticField()][dim]
      = grid.data.staggered_face.magnetic_field[dim](face_idx[0], face_idx[1], face_idx[2]);

    // tangential components reconstructed using cell-centered B
    std::set<int> tangential_dimensions{0, 1, 2};
    tangential_dimensions.erase(dim);

    for (auto tdim : tangential_dimensions) {
      interface[variables::MagneticField()][tdim]
        = B_reconstructor.compute(cell_idx, dim, dir,
                    [this, tdim] (const auto idx) {
                      auto pidx   = idx;
                      pidx[tdim] += 1;
                      const auto Bp = grid.data.staggered_face.magnetic_field[tdim](pidx[0], pidx[1], pidx[2]);
                      const auto Bm = grid.data.staggered_face.magnetic_field[tdim](idx[0], idx[1], idx[2]);
                      return 0.5*(Bp+Bm);
                    });
    }

    //
    // Assemble derived quantities
    //
    return physics.convert_to_complete(interface);
  }


  /**
   * Computes upwinded flux for a given interface
   *
   *
   */
  auto compute_upwind_flux(const cell_idx_t current_cell_idx,
                           const int dim,
                           const int dir)
  {

    //
    // Index of facing cell
    //
    auto neighbor_cell_idx  = current_cell_idx;
    neighbor_cell_idx[dim] += dir;

    //
    // Compute "left" and "right" interface states
    //
    auto left_cell_idx  = current_cell_idx;
    auto right_cell_idx = neighbor_cell_idx;

    if (dir < 0) {
      std::swap(left_cell_idx, right_cell_idx);
    }

/*
    std::cout << "dim:" << dim << " dir: " << dir << std::endl;
    std::cout << "left_cell_idx:  " << left_cell_idx[0] << "," << left_cell_idx[1] << "," << left_cell_idx[2] << std::endl;
    std::cout << "right_cell_idx: " << right_cell_idx[0] << "," << right_cell_idx[1] << "," << right_cell_idx[2] << std::endl;
*/

    const auto left_state  = construct_interface_state(left_cell_idx,  dim, +1);
    const auto right_state = construct_interface_state(right_cell_idx, dim, -1);

    //
    // Get upwind flux by solving Riemann solver
    //

    // TODO: Class level def of these????
    const auto flux_func  = [this] (const auto & U, const auto direction) { return physics.flux(U, direction); };

    const auto signal_speed_func  = [this] (const auto & U, const auto direction) { return physics.maximum_signal_speeds(U, direction); };

    const auto interface_signal_speed_func  = [this, &signal_speed_func] (const auto & UL, const auto & UR, const auto direction) { return SignalSpeedEstimate()(UL, UR, direction, signal_speed_func); };

    // TODO: Return custom struct from Riemann solver instead

    typename Physics::FluxState flux; double aL; double aR;

    std::tie(flux, aL, aR)
      = RiemannSolver()(left_state, right_state, dim, flux_func, interface_signal_speed_func);

    //
    // Compute tangential upwinded velocity components
    //

    double iws = 0.0;
    if (aR != aL) iws = 1.0/(aR-aL);

    const auto upwind_velocity
     = left_state[variables::Velocity()]*(iws*aR) - right_state[variables::Velocity()]*(iws*aL);


    //
    // Store signal speeds and upwinded tangential velocity components at interfaces
    //
    cell_idx_t interface_idx = current_cell_idx;
    interface_idx[dim] += ( dir > 0 ? 1 : 0 ); // dir = -1 ==> add 0, dir = 1 ==> add 1

    if (dim==0) {
      grid.data.xface.a1p(interface_idx[0], interface_idx[1], interface_idx[2]) = aR;
      grid.data.xface.a1m(interface_idx[0], interface_idx[1], interface_idx[2]) = aL;

      grid.data.xface.v2(interface_idx[0], interface_idx[1], interface_idx[2]) = upwind_velocity[1];
      grid.data.xface.v3(interface_idx[0], interface_idx[1], interface_idx[2]) = upwind_velocity[2];
    }

    if (dim==1) {
      grid.data.yface.a2p(interface_idx[0], interface_idx[1], interface_idx[2]) = aR;
      grid.data.yface.a2m(interface_idx[0], interface_idx[1], interface_idx[2]) = aL;

      grid.data.yface.v1(interface_idx[0], interface_idx[1], interface_idx[2])  = upwind_velocity[0];
      grid.data.yface.v3(interface_idx[0], interface_idx[1], interface_idx[2])  = upwind_velocity[2];
    }

    if (dim==2) {
      grid.data.zface.a3p(interface_idx[0], interface_idx[1], interface_idx[2]) = aR;
      grid.data.zface.a3m(interface_idx[0], interface_idx[1], interface_idx[2]) = aL;

      grid.data.zface.v1(interface_idx[0], interface_idx[1], interface_idx[2])  = upwind_velocity[0];
      grid.data.zface.v2(interface_idx[0], interface_idx[1], interface_idx[2])  = upwind_velocity[1];
    }

    return std::make_tuple(flux, aL, aR);
  }


  /**
   *
   */
  void compute_interface_values_at_ghosts()
  {
    // Compute interface values at ghost cells in transverse directions

    // TODO: generalize to variable number of ghosts

    const auto num_indomain_cells = grid.num_indomain_cells();

    const std::array<unsigned long, 4> x_ghost_cell_indices = {{0, 1, 2+num_indomain_cells[0], 2+num_indomain_cells[0]+1}};
    const std::array<unsigned long, 4> y_ghost_cell_indices = {{0, 1, 2+num_indomain_cells[1], 2+num_indomain_cells[1]+1}};
    const std::array<unsigned long, 4> z_ghost_cell_indices = {{0, 1, 2+num_indomain_cells[2], 2+num_indomain_cells[2]+1}};


    typename Physics::FluxState flux; double aL; double aR;


    // Interfaces in x-ghosts
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : x_ghost_cell_indices) {

          const cell_idx_t cell_idx = {{i, j, k}};

          // Interface values in y-direction
          if (j == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 1, -1);
          }
          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 1, +1);

          // Interface values in z-direction
          if (k == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 2, -1);
          }
          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 2, +1);

        }
      }
    }

    // Interfaces in y-ghosts
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : y_ghost_cell_indices) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const cell_idx_t cell_idx = {{i, j, k}};

          // Interface values in x-direction
          if (i == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 0, -1);
          }
          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 0, +1);

          // Interface values in z-direction
          if (k == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 2, -1);
          }
          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 2, +1);

        }
      }
    }

    // Interfaces in z-ghosts
    for (const auto k : z_ghost_cell_indices) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const cell_idx_t cell_idx = {{i, j, k}};

          // Interface values in x-direction
          if (i == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 0, -1);
          }
          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 0, +1);

          // Interface values in y-direction
          if (j == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 1, -1);
          }
          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 1, +1);
        }
      }
    }
  }

  /**
   *
   */
  void compute_interface_values_at_ghosts_old()
  {
    // TODO: generalize to variable number of ghosts

    const auto num_indomain_cells = grid.num_indomain_cells();

    //std::cout << num_indomain_cells[0] << "," << num_indomain_cells[1] << std::endl;

    const std::array<unsigned long, 4> x_ghost_cell_indices = {{0, 1, 2+num_indomain_cells[0], 2+num_indomain_cells[0]+1}};
    const std::array<unsigned long, 4> y_ghost_cell_indices = {{0, 1, 2+num_indomain_cells[1], 2+num_indomain_cells[1]+1}};


    // TODO: need extra eval in z as well!?!

    typename Physics::FluxState flux; double aL; double aR;

    // x-face data
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : y_ghost_cell_indices) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const cell_idx_t cell_idx = {{i, j, k}};

          if (i == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 0, -1);
          }

          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 0, +1);
        }
      }
    }

    // y-face data
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : x_ghost_cell_indices) {

          const cell_idx_t cell_idx = {{i, j, k}};

          if (j == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 1, -1);
          }

          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 1, +1);
        }
      }
    }

#if 0
    // z-face data
    for (const auto k : ) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const cell_idx_t cell_idx = {{i, j, k}};

          if (k == 2) {
            std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 2, -1);
          }

          std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, 2, +1);
        }
      }
    }
#endif
  }




  /**
   * Advances magnetic field components at and within domain
   *
   */
  void advance_magnetic_field(const double dt)
  {

    // - \partial_t B = nabla x E
    //
    // (1/A)
    //


    //
    // - \partial_t Bx_{i-1/2, j, k}
    //             =   (Ez_{i-1/2, j+1/2, k    } - Ez_{i-1/2, j-1/2, k    })/dy
    //               - (Ey_{i-1/2, j,     k+1/2} - Ey_{i-1/2, j,     k-1/2})/dz
    //
    for (const auto k : grid.indomain_xface_index_range(2)) {
      for (const auto j : grid.indomain_xface_index_range(1)) {
        for (const auto i : grid.indomain_xface_index_range(0)) {

          const auto l2  = geometry.cell_edge_lengths({{i, j, k}}, 1);
          const auto l3  = geometry.cell_edge_lengths({{i, j, k}}, 2);

          const auto A1  = geometry.cell_face_area({{i, j, k}}, 0, -1);

          const double dB1dt
            = - ( (   grid.data.staggered_edge.electric_field[2](i, j+1, k  )*l3[2]
                    - grid.data.staggered_edge.electric_field[2](i, j  , k  )*l3[0])
                 -(   grid.data.staggered_edge.electric_field[1](i, j  , k+1)*l2[2]
                    - grid.data.staggered_edge.electric_field[1](i, j  , k  )*l2[0]) )/A1;

          grid.data.staggered_face.magnetic_field[0](i, j, k) += dt*dB1dt;


/*
          const double dy = grid.axis[1].coordinates(j+1)-grid.axis[1].coordinates(j);
          const double dz = grid.axis[2].coordinates(k+1)-grid.axis[2].coordinates(k);

          const double dB1dt
            = - ( (grid.data.staggered_edge.electric_field[2](i, j+1, k) - grid.data.staggered_edge.electric_field[2](i, j, k))/dy
                 -(grid.data.staggered_edge.electric_field[1](i, j, k+1) - grid.data.staggered_edge.electric_field[1](i, j, k))/dz );

          grid.data.staggered_face.magnetic_field[0](i, j, k) += dt*dB1dt;
*/

        }
      }
    }


    //
    //   \partial_t By_{i, j-1/2, k}
    //             =   (Ez_{i+1/2, j-1/2, k    } - Ez_{i-1/2, j-1/2, k    })/dx
    //               - (Ex_{i,     j-1/2, k+1/2} - Ex_{i,     j-1/2, k-1/2})/dz
    //
    for (const auto k : grid.indomain_yface_index_range(2)) {
      for (const auto j : grid.indomain_yface_index_range(1)) {
        for (const auto i : grid.indomain_yface_index_range(0)) {


          const auto l1  = geometry.cell_edge_lengths({{i, j, k}}, 0);
          const auto l3  = geometry.cell_edge_lengths({{i, j, k}}, 2);

          const auto A2  = geometry.cell_face_area({{i, j, k}}, 1, -1);

          const double dB2dt
            = ( (   grid.data.staggered_edge.electric_field[2](i+1, j, k  )*l3[1]
                  - grid.data.staggered_edge.electric_field[2](i  , j, k  )*l3[0])
               -(   grid.data.staggered_edge.electric_field[0](i  , j, k+1)*l1[2]
                  - grid.data.staggered_edge.electric_field[0](i  , j, k  )*l1[0]) )/A2;

          grid.data.staggered_face.magnetic_field[1](i, j, k) += dt*dB2dt;

/*
          const double dx = grid.axis[0].coordinates(i+1)-grid.axis[0].coordinates(i);
          const double dz = grid.axis[2].coordinates(k+1)-grid.axis[2].coordinates(k);

          const double dB2dt
            = ( (grid.data.staggered_edge.electric_field[2](i+1, j, k) - grid.data.staggered_edge.electric_field[2](i, j, k))/dx
               -(grid.data.staggered_edge.electric_field[0](i, j, k+1) - grid.data.staggered_edge.electric_field[0](i, j, k))/dz );

          grid.data.staggered_face.magnetic_field[1](i, j, k) += dt*dB2dt;
*/

        }
      }
    }

    //
    // - \partial_t Bz_{i, j, k-1/2}
    //             =   (Ey_{i+1/2, j,     k-1/2} - Ey_{i-1/2, j,     k-1/2})/dx
    //               - (Ex_{i,     j+1/2, k-1/2} - Ex_{i,     j-1/2, k-1/2})/dy
    //
    for (const auto k : grid.indomain_zface_index_range(2)) {
      for (const auto j : grid.indomain_zface_index_range(1)) {
        for (const auto i : grid.indomain_zface_index_range(0)) {

          const auto l1  = geometry.cell_edge_lengths({{i, j, k}}, 0);
          const auto l2  = geometry.cell_edge_lengths({{i, j, k}}, 1);

          const auto A3  = geometry.cell_face_area({{i, j, k}}, 2, -1);

          const double dB3dt
            = - ( (   grid.data.staggered_edge.electric_field[1](i+1, j  , k)*l2[1]
                    - grid.data.staggered_edge.electric_field[1](i  , j  , k)*l2[0])
                 -(   grid.data.staggered_edge.electric_field[0](i  , j+1, k)*l1[1]
                    - grid.data.staggered_edge.electric_field[0](i  , j  , k)*l1[0]) )/A3;

          grid.data.staggered_face.magnetic_field[2](i, j, k) += dt*dB3dt;

/*
          const auto l1  = geometry.cell_edge_lengths({{i, j, k}}, 0);
          const auto l2  = geometry.cell_edge_lengths({{i, j, k}}, 1);
          const auto l3  = geometry.cell_edge_lengths({{i, j, k}}, 2);

          const auto A3 = geometry.cell_face_area({{i, j, k}}, 2, -1);
*/
/*
          const double dx = grid.axis[0].coordinates(i+1)-grid.axis[0].coordinates(i);
          const double dy = grid.axis[1].coordinates(j+1)-grid.axis[1].coordinates(j);

          const double dB3dt
            = - ( (grid.data.staggered_edge.electric_field[1](i+1, j, k) - grid.data.staggered_edge.electric_field[1](i, j, k))/dx
                 -(grid.data.staggered_edge.electric_field[0](i, j+1, k) - grid.data.staggered_edge.electric_field[0](i, j, k))/dy );
*/

          //grid.data.staggered_face.magnetic_field[2](i, j, k) += dt*dB3dt;

        }
      }
    }

  }


  /*
   *
   */
  void compute_electric_field()
  {

    // Instantiate reconstructors
    Reconstructors reconstructors;

    decltype(reconstructors.reconstruct(variables::Velocity{})) v_reconstructor;
    decltype(reconstructors.reconstruct(variables::MagneticField{})) B_reconstructor;

    // Define access functions to staggered magnetic field components
    auto B1 = [this] (const cell_idx_t idx) { return grid.data.staggered_face.magnetic_field[0](idx[0], idx[1], idx[2]); };
    auto B2 = [this] (const cell_idx_t idx) { return grid.data.staggered_face.magnetic_field[1](idx[0], idx[1], idx[2]); };
    auto B3 = [this] (const cell_idx_t idx) { return grid.data.staggered_face.magnetic_field[2](idx[0], idx[1], idx[2]); };

    // Define access functions to staggered velocity components
    auto v2i1 = [this] (const cell_idx_t idx) { return grid.data.xface.v2(idx[0], idx[1], idx[2]); };
    auto v3i1 = [this] (const cell_idx_t idx) { return grid.data.xface.v3(idx[0], idx[1], idx[2]); };

    auto v1i2 = [this] (const cell_idx_t idx) { return grid.data.yface.v1(idx[0], idx[1], idx[2]); };
    auto v3i2 = [this] (const cell_idx_t idx) { return grid.data.yface.v3(idx[0], idx[1], idx[2]); };

    auto v1i3 = [this] (const cell_idx_t idx) { return grid.data.zface.v1(idx[0], idx[1], idx[2]); };
    auto v2i3 = [this] (const cell_idx_t idx) { return grid.data.zface.v2(idx[0], idx[1], idx[2]); };

    //
    // Compute E1 component
    //
    for (const auto k : grid.indomain_xedge_index_range(2)) {
      for (const auto j : grid.indomain_xedge_index_range(1)) {
        for (const auto i : grid.indomain_xedge_index_range(0)) {

          //
          // Reconstruct B2, v3 along dim=2 to i, j-1/2, k-1/2 edge
          //

          // B2(x1_i, x2_{j-1/2}, x3_{k-1/2}-eps)
          const double B2L = B_reconstructor.compute({{i, j, k-1}}, 2, +1, B2);

          // B2(x1_i, x2_{j-1/2}, x3_{k-1/2}+eps)
          const double B2R = B_reconstructor.compute({{i, j, k}}, 2, -1, B2);

          // v3(x1_i, x2_{j-1/2}, x3_{k-1/2}-eps)
          const double v3L = v_reconstructor.compute({{i, j, k-1}}, 2, +1, v3i2);

          // v3(x1_i, x2_{j-1/2}, x3_{k-1/2}+eps)
          const double v3R = v_reconstructor.compute({{i, j, k}}, 2, -1, v3i2);


          //
          // Reconstruct B3, v2 along dim=1 to i, j-1/2, k-1/2 edge
          //

          // B3(x1_i, x2_{j-1/2}-eps, x3_{k-1/2})
          const double B3L = B_reconstructor.compute({{i, j-1, k}}, 1, +1, B3);

          // B3(x1_i, x2_{j-1/2}+eps, x3_{k-1/2})
          const double B3R = B_reconstructor.compute({{i, j, k}}, 1, -1, B3);

          // v2(x1_i, x2_{j-1/2}-eps, x3_{k-1/2})
          const double v2L = v_reconstructor.compute({{i, j-1, k}}, 1, +1, v2i3);

          // v2(x1_i, x2_{j-1/2}+eps, x3_{k-1/2})
          const double v2R = v_reconstructor.compute({{i, j, k}}, 1, -1, v2i3);


          //
          // Estimate characteristic speeds at i, j-1/2, k-1/2 edge
          //

          const double a2m = std::max(grid.data.yface.a2m(i, j, k), grid.data.yface.a2m(i, j, k-1));
          const double a2p = std::max(grid.data.yface.a2p(i, j, k), grid.data.yface.a2p(i, j, k-1));

          const double a3m = std::max(grid.data.zface.a3m(i, j, k), grid.data.zface.a3m(i, j-1, k));
          const double a3p = std::max(grid.data.zface.a3p(i, j, k), grid.data.zface.a3p(i, j-1, k));

          //
          // Compute upwinded electric field
          //

          double iws_a2          = 0.0;
          if (a2p != a2m) iws_a2 = 1.0/(a2p-a2m);

          double iws_a3          = 0.0;
          if (a3p != a3m) iws_a3 = 1.0/(a3p-a3m);

          const double v2B3 = iws_a2*(a2p*v2L*B3L - a2m*v2R*B3R + a2m*a2p*(B3R-B3L));
          const double v3B2 = iws_a3*(a3p*v3L*B2L - a3m*v3R*B2R + a3m*a3p*(B2R-B2L));

          grid.data.staggered_edge.electric_field[0](i, j, k) = - v2B3 + v3B2;

        }
      }
    }


    //
    // Compute E2 component
    //
    for (const auto k : grid.indomain_yedge_index_range(2)) {
      for (const auto j : grid.indomain_yedge_index_range(1)) {
        for (const auto i : grid.indomain_yedge_index_range(0)) {

          //
          // Reconstruct B1, v3 along dim=2 to i-1/2, j, k-1/2 edge
          //

          // B1(x1_{i-1/2}, x2_{j}, x3_{k-1/2}-eps)
          const double B1L = B_reconstructor.compute({{i, j, k-1}}, 2, +1, B1);

          // B1(x1_{i-1/2}, x2_{j}, x3_{k-1/2}+eps)
          const double B1R = B_reconstructor.compute({{i, j, k}}, 2, -1, B1);

          // v3(x1_{i-1/2}, x2_{j}, x3_{k-1/2}-eps)
          const double v3L = v_reconstructor.compute({{i, j, k-1}}, 2, +1, v3i1);

          // v3(x1_{i-1/2}, x2_{j}, x3_{k-1/2}+eps)
          const double v3R = v_reconstructor.compute({{i, j, k}}, 2, -1, v3i1);


          //
          // Reconstruct B3, v1 along dim=0 to i-1/2, j, k-1/2 edge
          //

          // B3(x1_{i-1/2}-eps, x2_{j}, x3_{k-1/2})
          const double B3L = B_reconstructor.compute({{i-1, j, k}}, 0, +1, B3);

          // B3(x1_{i-1/2}+eps, x2_{j}, x3_{k-1/2})
          const double B3R = B_reconstructor.compute({{i, j, k}}, 0, -1, B3);

          // v1(x1_{i-1/2}-eps, x2_{j}, x3_{k-1/2})
          const double v1L = v_reconstructor.compute({{i-1, j, k}}, 0, +1, v1i3);

          // v1(x1_{i-1/2}+eps, x2_{j}, x3_{k-1/2})
          const double v1R = v_reconstructor.compute({{i, j, k}}, 0, -1, v1i3);


          //
          // Estimate characteristic speeds at i-1/2, j, k-1/2 edge
          //

          const double a1m = std::max(grid.data.xface.a1m(i, j, k), grid.data.xface.a1m(i, j, k-1));
          const double a1p = std::max(grid.data.xface.a1p(i, j, k), grid.data.xface.a1p(i, j, k-1));

          const double a3m = std::max(grid.data.zface.a3m(i, j, k), grid.data.zface.a3m(i-1, j, k));
          const double a3p = std::max(grid.data.zface.a3p(i, j, k), grid.data.zface.a3p(i-1, j, k));

          //
          // Compute upwinded electric field
          //

          double iws_a1          = 0.0;
          if (a1p != a1m) iws_a1 = 1.0/(a1p-a1m);

          double iws_a3          = 0.0;
          if (a3p != a3m) iws_a3 = 1.0/(a3p-a3m);

          const double v1B3 = iws_a1*(a1p*v1L*B3L - a1m*v1R*B3R + a1m*a1p*(B3R-B3L));
          const double v3B1 = iws_a3*(a3p*v3L*B1L - a3m*v3R*B1R + a3m*a3p*(B1R-B1L));

          grid.data.staggered_edge.electric_field[1](i, j, k) = v1B3 - v3B1;

        }
      }
    }

    //
    // Compute E3 component
    //
    for (const auto k : grid.indomain_zedge_index_range(2)) {
      for (const auto j : grid.indomain_zedge_index_range(1)) {
        for (const auto i : grid.indomain_zedge_index_range(0)) {

          //
          // Reconstruct B1, v2 along dim=1 to i-1/2, j-1/2, k edge
          //

          // B1(x1_{i-1/2}, x2_{j-1/2}-eps, x3_{k})
          const double B1L = B_reconstructor.compute({{i, j-1, k}}, 1, +1, B1);

          // B1(x1_{i-1/2}, x2_{j-1/2}+eps, x3_{k})
          const double B1R = B_reconstructor.compute({{i, j, k}}, 1, -1, B1);

          // v2(x1_{i-1/2}, x2_{j-1/2}-eps, x3_{k})
          const double v2L = v_reconstructor.compute({{i, j-1, k}}, 1, +1, v2i1);

          // v2(x1_{i-1/2}, x2_{j-1/2}+eps, x3_{k})
          const double v2R = v_reconstructor.compute({{i, j, k}}, 1, -1, v2i1);

          //
          // Reconstruct B2, v1 along dim=0 to i-1/2, j-1/2, k edge
          //

          // B2(x1_{i-1/2}-eps, x2_{j-1/2}, x3_{k})
          const double B2L = B_reconstructor.compute({{i-1, j, k}}, 0, +1, B2);

          // B2(x1_{i-1/2}+eps, x2_{j-1/2}, x3_{k})
          const double B2R = B_reconstructor.compute({{i, j, k}}, 0, -1, B2);

          // v1(x1_{i-1/2}-eps, x2_{j-1/2}, x3_{k})
          const double v1L = v_reconstructor.compute({{i-1, j, k}}, 0, +1, v1i2);

          // v1(x1_{i-1/2}+eps, x2_{j-1/2}, x3_{k})
          const double v1R = v_reconstructor.compute({{i, j, k}}, 0, -1, v1i2);

          //
          // Estimate characteristic speeds at i-1/2, j-1/2, k edge
          //

          const double a1m = std::max(grid.data.xface.a1m(i, j, k), grid.data.xface.a1m(i, j-1, k));
          const double a1p = std::max(grid.data.xface.a1p(i, j, k), grid.data.xface.a1p(i, j-1, k));

          const double a2m = std::max(grid.data.yface.a2m(i, j, k), grid.data.yface.a2m(i-1, j, k));
          const double a2p = std::max(grid.data.yface.a2p(i, j, k), grid.data.yface.a2p(i-1, j, k));

          //
          // Compute upwinded electric field
          //

          double iws_a1          = 0.0;
          if (a1p != a1m) iws_a1 = 1.0/(a1p-a1m);

          double iws_a2          = 0.0;
          if (a2p != a2m) iws_a2 = 1.0/(a2p-a2m);

          const double v1B2 = iws_a1*(a1p*v1L*B2L - a1m*v1R*B2R + a1m*a1p*(B2R-B2L));
          const double v2B1 = iws_a2*(a2p*v2L*B1L - a2m*v2R*B1R + a2m*a2p*(B1R-B1L));

          grid.data.staggered_edge.electric_field[2](i, j, k) = -v1B2 + v2B1;

        }
      }
    }

  }


  void add_spherical_geometry_source_term()
  {

    const auto inv_mu0 = physics.parameters.inv_mu0;


    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const auto delta = geometry.delta({{i, j, k}});
          const auto cell_volume = geometry.cell_volume({{i, j, k}});

          const auto r   = grid.axis[0].center(i);
          const auto th  = grid.axis[1].center(j);

          const auto dr  = delta[0];
          const auto dth = delta[1];
          const auto dph = delta[2];

          const auto cotangent  = (sin(th+0.5*dth)-sin(th-0.5*dth))/(dth*sin(th));

          const auto cotangent_alt
            = (0.5/cell_volume)*(functions::sqr(r+0.5*dr) - functions::sqr(r-0.5*dr))*dph*(sin(th + 0.5*dth)-sin(th - 0.5*dth));

          //
          // Compute cell volume-averaged quantities
          //

          const auto rho = grid.data.zone.mass_density(i, j, k);
          const auto P   = grid.data.zone.pressure(i, j, k);

          const Eigen::Vector3d v(grid.data.zone.momentum_density[0](i, j, k)/rho,
                                  grid.data.zone.momentum_density[1](i, j, k)/rho,
                                  grid.data.zone.momentum_density[2](i, j, k)/rho);

          // Dynamic field
          const Eigen::Vector3d
            b1(0.5*(grid.data.staggered_face.magnetic_field[0](i, j, k)+grid.data.staggered_face.magnetic_field[0](i+1, j,   k) ),
               0.5*(grid.data.staggered_face.magnetic_field[1](i, j, k)+grid.data.staggered_face.magnetic_field[1](i  , j+1, k) ),
               0.5*(grid.data.staggered_face.magnetic_field[2](i, j, k)+grid.data.staggered_face.magnetic_field[2](i  , j  , k+1)));

          // potential field
          const Eigen::Vector3d b0(0.0, 0.0, 0.0);

          //const auto b   = b0 + b1;



          update.data.zone.momentum_density[0](i, j, k)
            += (1.0/r)*(rho*(v[1]*v[1]+v[2]*v[2]) + 2.0*P + inv_mu0*(b1[0]*b1[0] + 2.0*b1[0]*b0[0]));

          update.data.zone.momentum_density[1](i, j, k)
            += (1.0/r)*( - rho*v[0]*v[1] + inv_mu0*(b1[0]*b1[1] + b0[0]*b1[1] + b0[1]*b1[0]))
              + cotangent_alt*( rho*v[2]*v[2] + P
                                         + inv_mu0*(0.5*b1.squaredNorm()
                                                  + b1.dot(b0) - b1[2]*b1[2] - 2.0*b1[2]*b0[2]) );

          update.data.zone.momentum_density[2](i, j, k)
            += (1.0/r)*( - rho*v[0]*v[2] + inv_mu0*(b1[0]*b1[2] + b1[2]*b0[0] + b0[2]*b1[0])
                         - cotangent*( rho*v[1]*v[2]
                                        + inv_mu0*(- b1[2]*b1[1] - b1[2]*b0[1] - b0[2]*b1[1]) )  );

        }
      }
    }

  }

  void add_cartesian_gravity_source_term()
  {

    const auto g = -constants::solar::gravitational_acceleration;

    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          update.data.zone.momentum_density[2](i, j, k)
            += grid.data.zone.mass_density(i, j, k)*g;

          update.data.zone.energy_density(i, j, k)
            += grid.data.zone.momentum_density[2](i, j, k)*g;

        }
      }
    }
  }


  void add_spherical_gravity_source_term()
  {


    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const auto r       = grid.axis[0].center(i);

          const double g_r   = -constants::solar::GM/(r*r);

          update.data.zone.momentum_density[0](i, j, k)
            += grid.data.zone.mass_density(i, j, k)*g_r;

          update.data.zone.energy_density(i, j, k)
            += grid.data.zone.momentum_density[0](i, j, k)*g_r;

        }
      }
    }
  }



};

}
}
}
