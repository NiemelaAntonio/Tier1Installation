# This file is part of CoCo.
#
# Copyright 2016, 2017 Jens Pomoell
#
# CoCo is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# CoCo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with CoCo. If not, see <http://www.gnu.org/licenses/>.


"""CoCo Ideal-MHD solver.
"""

import numpy as np

from .kernels import ideal as kernel


class IdealMagnetohydrodynamicsSolver(object):
    """CoCo MHD solver.

    Solves the MHD equations using upwind finite volume scheme with constrained
    transport for the induction equation. All quantities are (by default) in SI.

    This class acts as an interface to the C++ compute kernel.

    Attributes:
        t    : Simulation time (in seconds)
        grid : coco::elements::Grid class
    """

    def __init__(self):

        # Computational kernel
        self.kernel = None

        # Courant number
        # TODO: Define here or elsewhere!!!
        self.courant_number = 0.3

        # TODO: MAGIC NUMBER!!!, TAKE FROM SOLVER KERNEL!!!
        self.num_ghost_cells = (2, 2, 2)

    def initialize(self, grid):
        """Initializes the solver.

        Reserves memory for the computation and sets the connections to the
        compute kernel. Must be called before any computation can take place.

        Raises:
            ValueError : Grid has not been set
        """

        #
        # Instantiate the solver kernel.
        #

        # Select solver based on geometry
        if grid.geometry == "cartesian":
            MHDSolver = kernel.CartesianMHD
        elif grid.geometry == "spherical":
            MHDSolver = kernel.SphericalMHD
        else:
            raise ValueError("Unknown grid geometry")

        self.kernel = MHDSolver()

        #
        # Pass grid coordinates to solver
        #
        for dim in (0, 1, 2):
            self.kernel.set_coordinate_axis(dim, grid.axis[dim].coordinates)

        #
        # Initialize kernel
        #
        self.kernel.initialize()

        # Set ignorable direction
        # TODO
        # if len(grid.ignorable_axes) == 1:
        #    self.kernel.ignore_dimension = grid.ignorable_axes[0]
        # elif len(grid.ignorable_axes) == 2:
        #    raise ValueError("More than one ignorable direction not supported")

    def pre_run_finalization(self):
        self.kernel.finalize_init()

    def compute_update(self):
        self.kernel.compute_update()

    def update_solution(self, dt):
        self.kernel.update_solution(dt)

    def get_stable_time_step(self):
        return self.courant_number * self.kernel.wave_crossing_time

    def set_periodic_ghost_data(self, dim):

        data_to_left, data_to_right = self.pack_data(dim)

        self.unpack_data(dim, data_to_right, True, data_to_left, True)

    def pack_data(self, dim):

        cell_center_variables = (
            self.kernel.mass_density(),
            self.kernel.energy_density(),
            self.kernel.pressure(),
            self.kernel.momentum_density(0),
            self.kernel.momentum_density(1),
            self.kernel.momentum_density(2),
        )

        data_to_right = np.array([])
        data_to_left = np.array([])

        if dim == 0:

            for q in cell_center_variables:

                # Data to send to process to the left
                data_to_left = np.append(data_to_left, q[2:4, :, :].flatten())

                # Data to send to process to the right
                data_to_right = np.append(data_to_right, q[-4:-2, :, :].flatten())

            data_to_left = np.append(
                data_to_left,
                np.concatenate(
                    (
                        self.kernel.magnetic_field(0)[3:5, :, :].flatten(),
                        self.kernel.magnetic_field(1)[2:4, :, :].flatten(),
                        self.kernel.magnetic_field(2)[2:4, :, :].flatten(),
                    )
                ),
            )

            data_to_right = np.append(
                data_to_right,
                np.concatenate(
                    (
                        self.kernel.magnetic_field(0)[-5:-3, :, :].flatten(),
                        self.kernel.magnetic_field(1)[-4:-2, :, :].flatten(),
                        self.kernel.magnetic_field(2)[-4:-2, :, :].flatten(),
                    )
                ),
            )

        elif dim == 1:

            for q in cell_center_variables:

                # Data to send to process to the left
                data_to_left = np.append(data_to_left, q[:, 2:4, :].flatten())

                # Data to send to process to the right
                data_to_right = np.append(data_to_right, q[:, -4:-2, :].flatten())

            data_to_left = np.append(
                data_to_left,
                np.concatenate(
                    (
                        self.kernel.magnetic_field(0)[:, 2:4, :].flatten(),
                        self.kernel.magnetic_field(1)[:, 3:5, :].flatten(),
                        self.kernel.magnetic_field(2)[:, 2:4, :].flatten(),
                    )
                ),
            )

            data_to_right = np.append(
                data_to_right,
                np.concatenate(
                    (
                        self.kernel.magnetic_field(0)[:, -4:-2, :].flatten(),
                        self.kernel.magnetic_field(1)[:, -5:-3, :].flatten(),
                        self.kernel.magnetic_field(2)[:, -4:-2, :].flatten(),
                    )
                ),
            )

        elif dim == 2:

            for q in cell_center_variables:

                # Data to send to process to the left
                data_to_left = np.append(data_to_left, q[:, :, 2:4].flatten())

                # Data to send to process to the right
                data_to_right = np.append(data_to_right, q[:, :, -4:-2].flatten())

            data_to_left = np.append(
                data_to_left,
                np.concatenate(
                    (
                        self.kernel.magnetic_field(0)[:, :, 2:4].flatten(),
                        self.kernel.magnetic_field(1)[:, :, 2:4].flatten(),
                        self.kernel.magnetic_field(2)[:, :, 3:5].flatten(),
                    )
                ),
            )

            data_to_right = np.append(
                data_to_right,
                np.concatenate(
                    (
                        self.kernel.magnetic_field(0)[:, :, -4:-2].flatten(),
                        self.kernel.magnetic_field(1)[:, :, -4:-2].flatten(),
                        self.kernel.magnetic_field(2)[:, :, -5:-3].flatten(),
                    )
                ),
            )

        return data_to_left, data_to_right

    def unpack_data(self, dim, data_from_left, do_unpack_left, data_from_right, do_unpack_right):

        cell_center_variables = (
            self.kernel.mass_density(),
            self.kernel.energy_density(),
            self.kernel.pressure(),
            self.kernel.momentum_density(0),
            self.kernel.momentum_density(1),
            self.kernel.momentum_density(2),
        )

        if dim == 0:

            # Data consists of 6 cell centered variables followed by three
            # staggered magnetic field components

            shape = self.kernel.mass_density()[0:2, :, :].shape
            num = np.prod(shape)

            # Unpack data (conditionally) coming from the left
            if do_unpack_left:

                idx = 0
                for q in cell_center_variables:
                    q[0:2, :, :] = np.copy(data_from_left[idx : (idx + num)].reshape(shape))
                    idx += num

                magnetic_field_shapes = (
                    self.kernel.magnetic_field(0)[0:2, :, :].shape,
                    self.kernel.magnetic_field(1)[0:2, :, :].shape,
                    self.kernel.magnetic_field(2)[0:2, :, :].shape,
                )

                for d in range(3):
                    numB = np.prod(magnetic_field_shapes[d])
                    self.kernel.magnetic_field(d)[0:2, :, :] = np.copy(
                        data_from_left[idx : (idx + numB)].reshape(magnetic_field_shapes[d])
                    )
                    idx += numB

            # Unpack data (conditionally) coming from the right
            if do_unpack_right:

                idx = 0
                for q in cell_center_variables:
                    q[-2::, :, :] = np.copy(data_from_right[idx : (idx + num)].reshape(shape))
                    idx += num

                magnetic_field_shapes = (
                    self.kernel.magnetic_field(0)[-2::, :, :].shape,
                    self.kernel.magnetic_field(1)[-2::, :, :].shape,
                    self.kernel.magnetic_field(2)[-2::, :, :].shape,
                )

                for d in range(3):
                    numB = np.prod(magnetic_field_shapes[d])
                    self.kernel.magnetic_field(d)[-2::, :, :] = np.copy(
                        data_from_right[idx : (idx + numB)].reshape(magnetic_field_shapes[d])
                    )
                    idx += numB

        elif dim == 1:

            shape = self.kernel.mass_density()[:, 0:2, :].shape
            num = np.prod(shape)

            # Unpack data (conditionally) coming from the left
            if do_unpack_left:

                idx = 0
                for q in cell_center_variables:
                    q[:, 0:2, :] = np.copy(data_from_left[idx : (idx + num)].reshape(shape))
                    idx += num

                magnetic_field_shapes = (
                    self.kernel.magnetic_field(0)[:, 0:2, :].shape,
                    self.kernel.magnetic_field(1)[:, 0:2, :].shape,
                    self.kernel.magnetic_field(2)[:, 0:2, :].shape,
                )

                for d in range(3):
                    numB = np.prod(magnetic_field_shapes[d])
                    self.kernel.magnetic_field(d)[:, 0:2, :] = np.copy(
                        data_from_left[idx : (idx + numB)].reshape(magnetic_field_shapes[d])
                    )
                    idx += numB

            # Unpack data (conditionally) coming from the right
            if do_unpack_right:

                idx = 0
                for q in cell_center_variables:
                    q[:, -2::, :] = np.copy(data_from_right[idx : (idx + num)].reshape(shape))
                    idx += num

                magnetic_field_shapes = (
                    self.kernel.magnetic_field(0)[:, -2::, :].shape,
                    self.kernel.magnetic_field(1)[:, -2::, :].shape,
                    self.kernel.magnetic_field(2)[:, -2::, :].shape,
                )

                for d in range(3):
                    numB = np.prod(magnetic_field_shapes[d])
                    self.kernel.magnetic_field(d)[:, -2::, :] = np.copy(
                        data_from_right[idx : (idx + numB)].reshape(magnetic_field_shapes[d])
                    )
                    idx += numB

        elif dim == 2:

            shape = self.kernel.mass_density()[:, :, 0:2].shape
            num = np.prod(shape)

            # Unpack data (conditionally) coming from the left
            if do_unpack_left:

                idx = 0
                for q in cell_center_variables:
                    q[:, :, 0:2] = np.copy(data_from_left[idx : (idx + num)].reshape(shape))
                    idx += num

                magnetic_field_shapes = (
                    self.kernel.magnetic_field(0)[:, :, 0:2].shape,
                    self.kernel.magnetic_field(1)[:, :, 0:2].shape,
                    self.kernel.magnetic_field(2)[:, :, 0:2].shape,
                )

                for d in range(3):
                    numB = np.prod(magnetic_field_shapes[d])
                    self.kernel.magnetic_field(d)[:, :, 0:2] = np.copy(
                        data_from_left[idx : (idx + numB)].reshape(magnetic_field_shapes[d])
                    )
                    idx += numB

            # Unpack data (conditionally) coming from the right
            if do_unpack_right:

                idx = 0
                for q in cell_center_variables:
                    q[:, :, -2::] = np.copy(data_from_right[idx : (idx + num)].reshape(shape))
                    idx += num

                magnetic_field_shapes = (
                    self.kernel.magnetic_field(0)[:, :, -2::].shape,
                    self.kernel.magnetic_field(1)[:, :, -2::].shape,
                    self.kernel.magnetic_field(2)[:, :, -2::].shape,
                )

                for d in range(3):
                    numB = np.prod(magnetic_field_shapes[d])
                    self.kernel.magnetic_field(d)[:, :, -2::] = np.copy(
                        data_from_right[idx : (idx + numB)].reshape(magnetic_field_shapes[d])
                    )
                    idx += numB

    def update_internal(self, comm, boundary):

        #
        # Get ranks of process neighbors
        #
        left = np.zeros(3)  # in negative coordinate direction
        right = np.zeros(3)  # in positive coordinate direction

        left[0], right[0] = comm.Shift(0, 1)
        left[1], right[1] = comm.Shift(1, 1)
        left[2], right[2] = comm.Shift(2, 1)

        #
        # Get Cartesian communicator topology information
        #
        num_blocks, periods, block_pos = comm.topo

        #
        # Transfer data
        #
        for dim in (0, 1, 2):

            # Get data to send
            data_to_left, data_to_right = self.pack_data(dim)

            # Allocate space for incoming data
            data_from_left = np.zeros(data_to_left.shape)
            data_from_right = np.zeros(data_to_right.shape)

            # Transfer step 1: Send data to the process to the right, receive
            # data from the process to the left
            comm.Sendrecv(data_to_right, dest=right[dim], recvbuf=data_from_left, source=left[dim])

            # Transfer step 2: Send data to the process to the left, receive
            # data from the process to the right
            comm.Sendrecv(data_to_left, dest=left[dim], recvbuf=data_from_right, source=right[dim])

            #
            # Unpack transferred data
            #

            do_unpack_from_left = left[dim] >= 0
            do_unpack_from_right = right[dim] >= 0

            # Make sure not to unpack data at blocks that are at the edge
            # and that are not periodic
            if block_pos[dim] == 0 and boundary[dim].lower != "periodic":
                do_unpack_from_left = False

            if block_pos[dim] == (num_blocks[dim] - 1) and boundary[dim].upper != "periodic":
                do_unpack_from_right = False

            self.unpack_data(dim, data_from_left, do_unpack_from_left, data_from_right, do_unpack_from_right)
