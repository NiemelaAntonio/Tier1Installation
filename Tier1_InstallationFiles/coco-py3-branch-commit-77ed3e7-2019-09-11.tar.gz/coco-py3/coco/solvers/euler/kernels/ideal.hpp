/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <boost/mpl/vector.hpp>
#include <gensimcell.hpp>


#include "coco/core/grid.hpp"
#include "coco/physics/variables.hpp"
#include "coco/reconstruction/linear.hpp"
#include "coco/rsolvers/hll.hpp"
#include "coco/rsolvers/signal_speed_estimates.hpp"
#include "coco/core/limiters.hpp"
#include "coco/core/constants.hpp"


namespace coco {

namespace solvers {

namespace euler {

// TODO: Generalize the class to a generic Stagg FVM solver class
// TODO: Clean up and document apm, aL, aR

struct Reconstructors
{
  auto reconstruct(variables::MassDensity)   { return reconstruction::Linear<limiters::VanLeer>(); };
  auto reconstruct(variables::Pressure)      { return reconstruction::Linear<limiters::VanLeer>();   };
  auto reconstruct(variables::Velocity)      { return reconstruction::Linear<limiters::VanLeer>();   };
};



class IdealEulerFlowPhysics
{
public:

  struct Parameters
  {
    Parameters() : adiabatic_index(5.0/3.0) {}

    double adiabatic_index;
  };

  Parameters parameters;


  using FluxState = gensimcell::Cell<gensimcell::Always_Transfer,
                                     variables::MassDensity,
                                     variables::MomentumDensity,
                                     variables::EnergyDensity
                                    >;

  using InterfaceState = gensimcell::Cell<gensimcell::Always_Transfer,
                                          variables::MassDensity,
                                          variables::MomentumDensity,
                                          variables::Velocity,
                                          variables::EnergyDensity,
                                          variables::Pressure
                                         >;

  template <class TState>
  InterfaceState convert_to_complete(const TState & U) const
  {
    using namespace coco::variables;

    InterfaceState s;

    s[MassDensity()]     = U[MassDensity()];
    s[Velocity()]        = U[Velocity()];
    s[Pressure()]        = U[Pressure()];

    s[MomentumDensity()] = s[MassDensity()]*s[Velocity()];

    const auto kinetic_energy_density
      = 0.5*s[MassDensity()]*s[Velocity()].squaredNorm();

    const auto thermal_pressure
      = s[Pressure()]/(parameters.adiabatic_index-1.0);

    s[EnergyDensity()]   = kinetic_energy_density + thermal_pressure;

    return s;
  }


  /*!
   * \brief Compute flux
   *
   *
   */
  FluxState flux(const InterfaceState & U, const unsigned int dir) const
  {
    using namespace coco::variables;

    // Fluid velocity
    const auto v       = U[Velocity()];

    // Fluid momentum density
    const auto m       = U[MassDensity()]*v;

    const auto thermal_pressure  = U[Pressure()];

    // Total energy density
    const double total_energy_density
      = thermal_pressure/(parameters.adiabatic_index-1.0)
      + 0.5*U[MassDensity()]*v.squaredNorm();

    FluxState flux;

    flux[ MassDensity()    ]       =  m[dir];

    flux[ MomentumDensity()]       =  (v[dir])*m;
    flux[ MomentumDensity()][dir] +=  thermal_pressure;

    flux[ EnergyDensity()  ]
      = (total_energy_density + thermal_pressure)*v[dir];

    return flux;
  }

  /*!
   */
  double sound_speed(const InterfaceState & U, const unsigned int) const
  {
    using namespace coco::variables;

    // Sound speed squared, c_s^2 = gamma P/rho
    const double cS2 = parameters.adiabatic_index*U[Pressure()]/U[MassDensity()];

    return sqrt(cS2);
  }


  /*!
   * \brief Computes the maximum signal speeds.
   *
   */
   // TODO: Make part of the signal speed estimator:
   // use variadic argument list
   // check whether velocity exists (else : zero)
  std::tuple<double, double> maximum_signal_speeds(const InterfaceState & U,
                                                   const unsigned int dir) const
  {
    using namespace coco::variables;

    const double max_wave_speed = sound_speed(U, dir);

    const double flow_speed     = U[Velocity()][dir];

    return std::make_tuple(flow_speed-max_wave_speed, flow_speed+max_wave_speed);
  }

};


// TODO: Where do I put this?? Inside the solver class??
// Add as inherited class to Grid via (optional) template??
template <class TGrid>
class GridAccess
{
private:

  TGrid & grid;

public:

  GridAccess(TGrid & g) : grid(g) {}

  auto & operator[](const variables::MassDensity) { return grid.data.zone.mass_density; }
  auto & operator[](const variables::Pressure)    { return grid.data.zone.pressure; }

  auto operator()(const variables::MassDensity, const cell_idx_t idx) const
  {
    return grid.data.zone.mass_density(idx[0], idx[1], idx[2]);
  }

  auto operator()(const variables::Pressure, const cell_idx_t idx) const
  {
    return grid.data.zone.pressure(idx[0], idx[1], idx[2]);
  }

  auto operator()(const variables::Velocity, const cell_idx_t idx) const
  {
    const auto rho = grid.data.zone.mass_density(idx[0], idx[1], idx[2]);

    const auto v1  = grid.data.zone.momentum_density[0](idx[0], idx[1], idx[2])/rho;
    const auto v2  = grid.data.zone.momentum_density[1](idx[0], idx[1], idx[2])/rho;
    const auto v3  = grid.data.zone.momentum_density[2](idx[0], idx[1], idx[2])/rho;

    return variables::Velocity::data_type(v1, v2, v3);
  }


  void add(const coco::variables::MassDensity::data_type rho, coco::variables::MassDensity, const cell_idx_t idx)
  {
    grid.data.zone.mass_density(idx[0], idx[1], idx[2]) += rho;
  }

  void add(const coco::variables::EnergyDensity::data_type E, coco::variables::EnergyDensity, const cell_idx_t idx)
  {
    grid.data.zone.energy_density(idx[0], idx[1], idx[2]) += E;
  }

  void add(const coco::variables::MomentumDensity::data_type m, coco::variables::MomentumDensity, const cell_idx_t idx)
  {
    grid.data.zone.momentum_density[0](idx[0], idx[1], idx[2]) += m[0];
    grid.data.zone.momentum_density[1](idx[0], idx[1], idx[2]) += m[1];
    grid.data.zone.momentum_density[2](idx[0], idx[1], idx[2]) += m[2];
  }

};


template <class Geometry>
class IdealEulerFlowSolverKernel
{
private:


public:

  IdealEulerFlowSolverKernel() : geometry{grid.axis[0].coordinates,
                                          grid.axis[1].coordinates,
                                          grid.axis[2].coordinates},
                                 ignorable_dimension(10),
                                 gravity(false),
                                 access_grid(grid),
                                 access_update(update)
  {}



  // Define physics class
  using Physics        = IdealEulerFlowPhysics;

  using InterfaceState = Physics::InterfaceState;

  // Physics and data states relevant to the model
  Physics physics;

  // Geometry definiton
  Geometry geometry;

  int ignorable_dimension;

  bool gravity;

  struct GridVariables
  {
    struct ZoneData
    {
      ScalarFieldData mass_density;
      ScalarFieldData energy_density;
      ScalarFieldData pressure;
      VectorFieldData momentum_density;
    };
  };


  // Variables defined at cell center for which to compute
  // update as flux contributions
  using CellCenteredVariables
    = boost::mpl::vector<variables::MassDensity,
                         variables::MomentumDensity,
                         variables::EnergyDensity>;


  // Variables needed for computing fluxes between cells
  using FluxVariables
   = boost::mpl::vector<variables::MassDensity,
                        variables::MomentumDensity,
                        variables::EnergyDensity>;


  core::RectilinearGrid<GridVariables> grid;
  core::RectilinearGrid<GridVariables> update;

  // TODO: Better name, something like get_from_grid
  GridAccess<decltype(grid)>   access_grid;
  GridAccess<decltype(update)> access_update;


  using SignalSpeedEstimate
    = coco::riemannsolvers::DavisSignalSpeedEstimate;

  using RiemannSolver
    = coco::riemannsolvers::HLL<variables::MassDensity, variables::MomentumDensity, variables::EnergyDensity>;


  double minimum_wave_crossing_time;


public:


  void initialize()
  {

    // TODO:
    // Check num_ghost_cells > 0 in all directions


    // TODO!!!!! Determine automatically!!!!
    grid.num_ghost_cells = {{2, 2, 2}};


    //
    // Allocate arrays
    //

    // Zone data
    grid.allocate(grid.data.zone, grid.data.zone.mass_density);
    grid.allocate(grid.data.zone, grid.data.zone.pressure);
    grid.allocate(grid.data.zone, grid.data.zone.energy_density);
    grid.allocate(grid.data.zone, grid.data.zone.momentum_density);

    // Copy axis data
    update.axis = grid.axis;

    // Copy axis data
    update.num_ghost_cells = grid.num_ghost_cells;

    // Zone update data
    update.allocate(update.data.zone, update.data.zone.mass_density);
    update.allocate(update.data.zone, update.data.zone.energy_density);
    update.allocate(update.data.zone, update.data.zone.momentum_density);

    clear_update_array();
  }


  void clear_update_array()
  {
    update.data.zone.mass_density   *= 0.0;
    update.data.zone.energy_density *= 0.0;

    for (const int dim : {0, 1, 2}) {
      update.data.zone.momentum_density[dim] *= 0.0;
    }
  }

  void finalize_initialization()
  {

    //
    // Compute energy density
    //
    for (const auto k : grid.cell_index_range(2)) {
      for (const auto j : grid.cell_index_range(1)) {
        for (const auto i : grid.cell_index_range(0)) {

          const auto rho = grid.data.zone.mass_density(i, j, k);

          const auto m1  = grid.data.zone.momentum_density[0](i, j, k);
          const auto m2  = grid.data.zone.momentum_density[1](i, j, k);
          const auto m3  = grid.data.zone.momentum_density[2](i, j, k);

          // Thermal energy density
          const double thermal_energy_density
            = grid.data.zone.pressure(i, j, k)/(physics.parameters.adiabatic_index-1.0);

          // Kinetic energy density
          const double kinetic_energy_density = 0.5*(m1*m1+m2*m2+m3*m3)/rho;

          grid.data.zone.energy_density(i, j, k)
            = thermal_energy_density + kinetic_energy_density;

        }
      }
    }
  }

  /*
   * Compute time-derivative of MHD variables
   */
  void compute_update()
  {

    //
    // Compute dUdt of cell-centered variables
    //
    compute_cell_centered_update();

    //
    // Add geometry source terms
    //
    if (geometry.name() == "spherical") {
      add_spherical_geometry_source_term();
    }

    //
    // Add gravity source terms
    //
    if (gravity==true) {
      if (geometry.name() == "cartesian") {
        add_cartesian_gravity_source_term();
      }
      if (geometry.name() == "spherical") {
        add_spherical_gravity_source_term();
      }
    }

  }


  /*
   * TODO: deference to Python???
   */
  void update_solution(const double dt)
  {

    //
    // Advance cell-centered quantities
    //

    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          grid.data.zone.mass_density(i, j, k)   += dt*update.data.zone.mass_density(i, j, k);
          grid.data.zone.energy_density(i, j, k) += dt*update.data.zone.energy_density(i, j, k);

          for (const int dim : {0, 1, 2}) {
            grid.data.zone.momentum_density[dim](i, j, k) += dt*update.data.zone.momentum_density[dim](i, j, k);
          }

        }
      }
    }


    //
    // Update pressure
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const auto rho = grid.data.zone.mass_density(i, j, k);

          const auto m1  = grid.data.zone.momentum_density[0](i, j, k);
          const auto m2  = grid.data.zone.momentum_density[1](i, j, k);
          const auto m3  = grid.data.zone.momentum_density[2](i, j, k);

          //const auto B   = access_grid(variables::MagneticField{}, {{i, j, k}});

          // Kinetic energy density
          const auto kinetic_energy_density = 0.5*(m1*m1+m2*m2+m3*m3)/rho;

          // Total energy density
          const auto energy_density = grid.data.zone.energy_density(i, j, k);

          // Magnetic energy density
          grid.data.zone.pressure(i, j, k)
            = (energy_density - kinetic_energy_density)*(physics.parameters.adiabatic_index-1.0);

        }
      }
    }

    clear_update_array();
  }

  /**
   * Computes \partial U/\partial t for cell-centered variables
   *
   */
  void compute_cell_centered_update()
  {

    std::array<double, 3> shortest_wave_crossing_time
      = {{ std::numeric_limits<double>::max(),
           std::numeric_limits<double>::max(),
           std::numeric_limits<double>::max() }};


    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          // Index of current cell
          const cell_idx_t cell_idx = {{i, j, k}};

          // Compute volume of current cell
          const auto cell_volume = geometry.cell_volume(cell_idx);

          //
          // Loop over dimensions
          //
          for (const int32_t dim : {0, 1, 2}) {

            if (dim == ignorable_dimension)
              continue;

            //
            // Loop over directions
            //
            for (const int32_t direction : {-1, 1}) {

              //
              // Compute flux in negative direction only at domain boundaries
              //
              if ((direction == -1) and (dim==0) and (i>grid.num_ghost_cells[0]))
                continue;

              if ((direction == -1) and (dim==1) and (j>grid.num_ghost_cells[1]))
                continue;

              if ((direction == -1) and (dim==2) and (k>grid.num_ghost_cells[2]))
                continue;


              // Index of facing cell
              auto neighbor_cell_idx  = cell_idx;
              neighbor_cell_idx[dim] += direction;


              //
              // Compute cell geometry
              //
              const auto face_area
                = geometry.cell_face_area(cell_idx, dim, direction);

              const auto neighbor_cell_volume
                = geometry.cell_volume(neighbor_cell_idx);

              const auto cell_lengths
                = geometry.cell_edge_lengths(cell_idx, dim);

              const auto cell_length
                = *std::min_element(cell_lengths.begin(), cell_lengths.end());


              //
              // Compute flux through the cell boundary
              //
              typename Physics::FluxState flux; double aL; double aR;

              std::tie(flux, aL, aR) = compute_upwind_flux(cell_idx, dim, direction);

              const double max_speed = std::max(std::fabs(aL), std::fabs(aR));


              // TODO: Provide mpl vector as template
              // TODO: How to do this generically now that arrays are separated??

              //
              // Add flux contributions to the cells sharing the face
              //
              boost::mpl::for_each< boost::mpl::vector<variables::MassDensity, variables::MomentumDensity, variables::EnergyDensity> >
              //boost::mpl::for_each< boost::mpl::vector<variables::MassDensity> >
              (
                [&] (auto q) {
                  const auto flow_rate = direction*(face_area*flux[q]);

                  access_update.add(-flow_rate/cell_volume,          q, cell_idx);
                  access_update.add( flow_rate/neighbor_cell_volume, q, neighbor_cell_idx);
                }
              );

              // TODO!! Should check waves in to each cell
              // TODO!!! Volume is different for the two cells!!!
              const double wave_crossing_time  = cell_length/std::abs(max_speed);

              shortest_wave_crossing_time[dim] = std::min(shortest_wave_crossing_time[dim], wave_crossing_time);

            }

          }

        }
      }
    }

    //
    // store fastest wave mode for time step determination
    //
    minimum_wave_crossing_time = *std::min_element(shortest_wave_crossing_time.begin(),
                                                   shortest_wave_crossing_time.end());

  }


  /*!
   * \brief Build interface state
   *
   * Construct the interface in the direction dir of the current cell
   */
  auto construct_interface_state(const cell_idx_t cell_idx,
                                 const int dim,
                                 const int dir) const
  {
    using namespace coco::variables;


    // TODO: make class member?
    //Reconstructors reconstructors;


    //
    // Reconstruct the given variables to the requested interface
    //

    // TODO
    //ReconstructionState interface;
    InterfaceState interface;

    boost::mpl::for_each< boost::mpl::vector<MassDensity, Pressure, Velocity> >
    (
      [&] (const auto q) {

        // Helper function that calls the function that fetches data from the
        // grid and serves it to the reconstruction function in the form of the
        // data_type of the variable
        const auto data_mapper
          = [this, q] (const cell_idx_t idx) { return access_grid(q, idx); };

        // Instantiate reconstructor for this quantity
        Reconstructors reconstructors;
        decltype(reconstructors.reconstruct(q)) reconstructor;

        // Compute interface value.
        const auto q_at_interface
          = reconstructor.compute(cell_idx, dim, dir, data_mapper);

        // Insert result in state
        interface[q] = q_at_interface;
      }
    );


    //
    // Assemble derived quantities
    //
    return physics.convert_to_complete(interface);
  }


  /**
   * Computes upwinded flux for a given interface
   *
   *
   */
  auto compute_upwind_flux(const cell_idx_t current_cell_idx,
                           const int dim,
                           const int dir)
  {

    //
    // Index of facing cell
    //
    auto neighbor_cell_idx  = current_cell_idx;
    neighbor_cell_idx[dim] += dir;

    //
    // Compute "left" and "right" interface states
    //
    auto left_cell_idx  = current_cell_idx;
    auto right_cell_idx = neighbor_cell_idx;

    if (dir < 0) {
      std::swap(left_cell_idx, right_cell_idx);
    }

    const auto left_state  = construct_interface_state(left_cell_idx,  dim, +1);
    const auto right_state = construct_interface_state(right_cell_idx, dim, -1);

    //
    // Get upwind flux by solving Riemann solver
    //

    // TODO: Class level def of these????
    const auto flux_func  = [this] (const auto & U, const auto direction) { return physics.flux(U, direction); };

    const auto signal_speed_func  = [this] (const auto & U, const auto direction) { return physics.maximum_signal_speeds(U, direction); };

    const auto interface_signal_speed_func  = [this, &signal_speed_func] (const auto & UL, const auto & UR, const auto direction) { return SignalSpeedEstimate()(UL, UR, direction, signal_speed_func); };


    // TODO: Return custom struct from Riemann solver instead

    typename Physics::FluxState flux; double aL; double aR;

    std::tie(flux, aL, aR)
      = RiemannSolver()(left_state, right_state, dim, flux_func, interface_signal_speed_func);

    return std::make_tuple(flux, aL, aR);
  }


  void add_spherical_geometry_source_term()
  {


    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const auto delta = geometry.delta({{i, j, k}});
          const auto cell_volume = geometry.cell_volume({{i, j, k}});

          const auto r   = grid.axis[0].center(i);
          const auto th  = grid.axis[1].center(j);

          const auto dr  = delta[0];
          const auto dth = delta[1];
          const auto dph = delta[2];

          const auto cotangent  = (sin(th+0.5*dth)-sin(th-0.5*dth))/(dth*sin(th));

          const auto cotangent_alt
            = (0.5/cell_volume)*(functions::sqr(r+0.5*dr) - functions::sqr(r-0.5*dr))*dph*(sin(th + 0.5*dth)-sin(th - 0.5*dth));

          //
          // Compute cell volume-averaged quantities
          //

          const auto rho = grid.data.zone.mass_density(i, j, k);
          const auto P   = grid.data.zone.pressure(i, j, k);

          const Eigen::Vector3d v(grid.data.zone.momentum_density[0](i, j, k)/rho,
                                  grid.data.zone.momentum_density[1](i, j, k)/rho,
                                  grid.data.zone.momentum_density[2](i, j, k)/rho);


          update.data.zone.momentum_density[0](i, j, k)
            += (1.0/r)*(rho*(v[1]*v[1]+v[2]*v[2]) + 2.0*P);

          update.data.zone.momentum_density[1](i, j, k)
            += (1.0/r)*(-rho*v[0]*v[1])
              + cotangent_alt*( rho*v[2]*v[2] + P);

          update.data.zone.momentum_density[2](i, j, k)
            += (1.0/r)*( - rho*v[0]*v[2]
                         - cotangent*(rho*v[1]*v[2]) );

        }
      }
    }

  }


  void add_cartesian_gravity_source_term()
  {

    const auto g = -constants::solar::gravitational_acceleration;

    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          update.data.zone.momentum_density[2](i, j, k)
            += grid.data.zone.mass_density(i, j, k)*g;

          update.data.zone.energy_density(i, j, k)
            += grid.data.zone.momentum_density[2](i, j, k)*g;

        }
      }
    }
  }


  void add_spherical_gravity_source_term()
  {

    //
    // Loop through in-domain cells
    //
    for (const auto k : grid.indomain_cell_index_range(2)) {
      for (const auto j : grid.indomain_cell_index_range(1)) {
        for (const auto i : grid.indomain_cell_index_range(0)) {

          const auto r       = grid.axis[0].center(i);

          const double g_r   = -constants::solar::GM/(r*r);

          update.data.zone.momentum_density[0](i, j, k)
            += grid.data.zone.mass_density(i, j, k)*g_r;

          update.data.zone.energy_density(i, j, k)
            += grid.data.zone.momentum_density[0](i, j, k)*g_r;

        }
      }
    }
  }


};

}
}
}
