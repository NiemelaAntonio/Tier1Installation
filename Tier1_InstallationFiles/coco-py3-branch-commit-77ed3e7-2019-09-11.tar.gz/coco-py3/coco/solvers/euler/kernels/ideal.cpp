/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#define USE_XTENSORPYTHON_ARRAY

#include "coco/core/coco.hpp"

#include "coco/geometry/cartesian.hpp"
#include "coco/geometry/spherical.hpp"

#include "coco/solvers/euler/kernels/ideal.hpp"



PYBIND11_PLUGIN(ideal)
{
    namespace py = pybind11;

    py::module m("ideal", "Kernel for ideal Euler flow solver");


    using CartesianEuler = coco::solvers::euler::IdealEulerFlowSolverKernel<coco::geometry::Cartesian>;
    using SphericalEuler = coco::solvers::euler::IdealEulerFlowSolverKernel<coco::geometry::Spherical>;


    py::class_<CartesianEuler>(m, "CartesianEuler")
      .def(py::init<>())
      //
      // Init functions
      //
      .def("initialize", &CartesianEuler::initialize)
      .def("set_coordinate_axis", [](CartesianEuler & self,
                                     const int dim,
                                     const decltype(self.grid.axis[0].coordinates) x) { self.grid.axis[dim].coordinates = x; })
      .def("get_coordinate_axis", [](CartesianEuler & self, const int dim) { return self.grid.axis[dim].coordinates;} )
      .def("finalize_init", &CartesianEuler::finalize_initialization)
      //
      // Compute functions
      //
      .def("compute_update", &CartesianEuler::compute_update)
      .def_readonly("wave_crossing_time", &CartesianEuler::minimum_wave_crossing_time)
      .def("update_solution", &CartesianEuler::update_solution)
      //
      // Expose grid data
      //
      .def("mass_density",     [](CartesianEuler & self) { return self.grid.data.zone.mass_density; } )
      .def("pressure",         [](CartesianEuler & self) { return self.grid.data.zone.pressure; } )
      .def("energy_density",   [](CartesianEuler & self) { return self.grid.data.zone.energy_density; } )
      .def("momentum_density", [](CartesianEuler & self, const int dim) { return self.grid.data.zone.momentum_density[dim]; } )
      //
      // Expose parameters
      //
      .def_readwrite("gravity", &CartesianEuler::gravity)
      .def_readwrite("ignore_dimension", &CartesianEuler::ignorable_dimension)
      .def_property("adiabatic_index",
                    [](CartesianEuler & self)            { return self.physics.parameters.adiabatic_index ;},
                    [](CartesianEuler & self, const double val) { self.physics.parameters.adiabatic_index = val; }
                   )
      ;


    py::class_<SphericalEuler>(m, "SphericalEuler")
      .def(py::init<>())
      //
      // Init functions
      //
      .def("initialize", &SphericalEuler::initialize)
      .def("set_coordinate_axis", [](SphericalEuler & self,
                                     const int dim,
                                     const decltype(self.grid.axis[0].coordinates) x) { self.grid.axis[dim].coordinates = x; })
      .def("get_coordinate_axis", [](SphericalEuler & self, const int dim) { return self.grid.axis[dim].coordinates;} )
      .def("finalize_init", &SphericalEuler::finalize_initialization)
      //
      // Compute functions
      //
      .def("compute_update", &SphericalEuler::compute_update)
      .def_readonly("wave_crossing_time", &SphericalEuler::minimum_wave_crossing_time)
      .def("update_solution", &SphericalEuler::update_solution)
      //
      // Expose grid data
      //
      .def("mass_density",     [](SphericalEuler & self) { return self.grid.data.zone.mass_density; } )
      .def("pressure",         [](SphericalEuler & self) { return self.grid.data.zone.pressure; } )
      .def("energy_density",   [](SphericalEuler & self) { return self.grid.data.zone.energy_density; } )
      .def("momentum_density", [](SphericalEuler & self, const int dim) { return self.grid.data.zone.momentum_density[dim]; } )
      //
      // Expose parameters
      //
      .def_readwrite("gravity", &SphericalEuler::gravity)
      .def_readwrite("ignore_dimension", &SphericalEuler::ignorable_dimension)
      .def_property("adiabatic_index",
                    [](SphericalEuler & self)            { return self.physics.parameters.adiabatic_index ;},
                    [](SphericalEuler & self, const double val) { self.physics.parameters.adiabatic_index = val; }
                   )
      ;


return m.ptr();
}
