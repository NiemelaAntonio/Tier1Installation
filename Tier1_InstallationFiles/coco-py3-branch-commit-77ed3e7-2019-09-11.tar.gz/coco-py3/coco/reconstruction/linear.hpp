/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <set>
#include <utility>

namespace coco {

namespace reconstruction {


// TODO: This is rather messy, need to clean up: make loop on dim.

template <class Limiter>
class Linear
{
public:

  template <class ExtractFunctor>
  auto compute(const cell_idx_t idx,
               const int dim,
               const int dir,
               ExtractFunctor extract)
  {
    std::array<decltype(extract(idx)), 3> q;

    //
    // Fill array along one dimension
    //
    for (const int offset : {-1, 0, 1}) {

      auto idx_at_offset  = idx;
      idx_at_offset[dim] += offset;

      q[offset+1] = extract(idx_at_offset);
    }

    return interface(q, dir);
  }

  double interface(std::array<double, 3> q, const int dir)
  {
    const int i       = 1;

    //
    // Compute limited slope
    //
    const double slope = Limiter()(q[i+1]-q[i], q[i]-q[i-1]);

    //
    // Return interface value
    //
    return q[i] + 0.5*dir*slope;
  }

  auto interface(std::array<Eigen::Vector3d, 3> q, const int dir)
  {
    const int i      = 1;

    Eigen::Vector3d interface;

    // Loop over components of the vector
    for (const int d : {0, 1, 2}) {

      //
      // Compute limited slope
      //
      const auto slope = Limiter()(q[i+1][d]-q[i][d], q[i][d]-q[i-1][d]);

      //
      // Return interface value
      //
      interface[d] = q[i][d] + 0.5*dir*slope;
    }

    return interface;
  }

};


template <class Limiter>
class LinearPreserveNormal
{
public:

  // If a scalar is given, reconstructs it as a regular scalar
  // If a vector is given, reconstructs it in a special way
  template <class ExtractFunctor>
  auto compute(const cell_idx_t idx,
               const int dim,
               const int dir,
               ExtractFunctor extract)
  {
    return reconstruct(idx, dim, dir, extract, decltype(extract(idx))());
  }


  auto interface(std::array<double, 3> q, const int dir)
  {
    const int i      = 1;

    //
    // Compute limited slope
    //
    const auto slope = Limiter()(q[i+1]-q[i], q[i]-q[i-1]);

    //
    // Return interface value
    //
    return q[i] + 0.5*dir*slope;
  }


  template <class ExtractFunctor>
  auto reconstruct(const cell_idx_t idx,
                   const int dim,
                   const int dir,
                   ExtractFunctor extract, double)
  {
    std::array<decltype(extract(idx)), 3> q;

    //
    // Fill array along one dimension
    //
    for (int offset : {-1, 0, 1}) {

      auto idx_at_offset  = idx;
      idx_at_offset[dim] += offset;

      q[offset+1] = extract(idx_at_offset);
    }

    const int i      = 1;

    //
    // Compute limited slope
    //
    const auto slope = Limiter()(q[i+1]-q[i], q[i]-q[i-1]);

    //
    // Return interface value
    //
    return q[i] + 0.5*dir*slope;
  }


  template <class ExtractFunctor>
  auto reconstruct(const cell_idx_t idx,
                   const int dim,
                   const int dir,
                   ExtractFunctor extract, Eigen::Vector3d)
  {

    Eigen::Vector3d iface;

    // NOTE: this is not the most efficient code

    //
    // Reconstruct tangential components
    //

    std::set<int> tangential_dimensions{0, 1, 2};
    tangential_dimensions.erase(dim);

    for (const auto tdim : tangential_dimensions) {

      auto idx_neg_face = idx;
      auto idx_pos_face = idx; idx_pos_face[tdim] += 1;

      std::array<double, 3> Bavg;

      for (int offset : {-1, 0, 1}) {
        Bavg[offset+1] = 0.5*(extract(idx_neg_face)[tdim] + extract(idx_pos_face)[tdim]);
      }

      iface[tdim] = interface(Bavg, dir);
    }

    //
    // Normal component is directly available
    //
    auto idx_to_normal_component  = idx;
    idx_to_normal_component[dim] += (dir > 0 ? 1 : 0);

    iface[dim] = extract(idx_to_normal_component)[dim];


    return iface;
  }

};

}
}
