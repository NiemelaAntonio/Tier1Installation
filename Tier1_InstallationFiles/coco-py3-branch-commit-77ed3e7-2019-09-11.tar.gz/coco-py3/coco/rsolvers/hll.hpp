/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <tuple>
#include <algorithm>
#include <boost/mpl/for_each.hpp>
#include <boost/mpl/vector.hpp>


namespace coco {

namespace riemannsolvers {


 /*!
 * \brief Generic HLL flux applicable to any system of conservation laws.
 *
 * The HLL solver approximates the Riemann fan to consist of three states:
 * the left (L) and right (R) constant states that defines the Riemann problem
 * and a third constant average state that connects L and R.
 * The flux is given by (see e.g. Eq. 3.15a in \[1\])
 *
 * \f{equation*}{
 *   f_{HLL} = \begin{cases}
 *               f_L, & S_L > 0\\
 *               f_*, & S_L \leq 0 \leq S_R \\
 *               f_R, & S_R < 0\\
 *             \end{cases}
 * \f}
 *
 * where
 *
 * \f{equation*}{
 *   f_{*} = \frac{S_R f_L - S_L f_R + S_L S_R ( U_R - U_L) }{ S_R - S_L }
 * \f}
 *
 * S_L and S_R denote the speeds of the two outermost (fastest) waves. These can be
 * estimated in various ways, see e.g. \[2\] for a short discussion and relevant
 * references.
 *
 * Note that the piecewise-defined flux can be written equivalently as
 *
 * \f{equation*}{
 *   f_{HLL} = \frac{S_R' f_L - S_L' f_R + S_L' S_R' ( U_R - U_L) }{ S_R' - S_L' }
 * \f}
 *
 * where \f$ S_R'= max(0, S_R) \f$ and \f$ S_L'= min(0, S_L) \f$. This is the form
 * used in the code below.
 *
 * \b References
 *
 * \[1\] [Harten, Lax & van Leer, SIAM Review 25, 1983](http://dx.doi.org/10.1137/1025002)
 *
 * \[2\] [Miyoshi & Kusano, JCP 208, 2005](http://dx.doi.org/10.1016/j.jcp.2005.02.017)
 *
 */
template <class... Variables>
class HLL
{

public:

  template <class TState, class FluxFunctor, class SignalSpeedFunctor>
  auto operator() (const TState & UL,
                   const TState & UR,
                   const unsigned int dir,
                   FluxFunctor flux,
                   SignalSpeedFunctor max_signal_speeds) const
  {
    // Compute fluxes
    const auto fL = flux(UL, dir);
    const auto fR = flux(UR, dir);

    // Get maximum signal speeds in both directions
    double SL,SR;
    std::tie(SL, SR) = max_signal_speeds(UL, UR, dir);

    // Supersonic cases, see doc
    SL = std::min(0.0, SL);
    SR = std::max(0.0, SR);

    // Compute inverse of the wave speed sums taking care of
    // pathological case when the wave speeds are equal
    double iws = 0.0;
    if (SR != SL) iws = 1.0/(SR-SL);

    decltype(flux(UL, dir)) hll_flux{};
    hll_flux *= 0.0;

    // Compute HLL flux for the given variables
    boost::mpl::for_each< boost::mpl::vector<Variables...> >
    (
      [&] (auto variable) {
        const auto UR_minus_UL = UR[variable]-UL[variable];
        hll_flux[variable] = fL[variable]*(SR*iws) - fR[variable]*(SL*iws) + UR_minus_UL*(SR*SL*iws);
      }
    );

    return std::make_tuple(hll_flux, SL, SR);
  }

};

}
}
