/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

namespace coco {

namespace riemannsolvers {


/*!
 * \brief Davis' signal speed estimator.
 *
 * Computes the maximum and minimum signal speeds for use in a HLL solver.
 * Uses the method described in \[1\] (equation 4.5).
 *
 * \see
 *    HLL
 *
 * \b References
 *
 * \[1\] [Davis, SIAM J. Sci. and Stat. Comput. 9, 1988](http://dx.doi.org/10.1137/0909030)
 */
class DavisSignalSpeedEstimate
{
public:

  template <class TState, class SignalSpeedFunctor>
  std::tuple<double, double> operator()(const TState & UL,
                                        const TState & UR,
                                        const unsigned int dir,
                                        SignalSpeedFunctor signal_speed) const
  {
    // Compute the maximum negative and positive characteristics due to state UL
    double signal_UL_neg, signal_UL_pos;
    std::tie(signal_UL_neg, signal_UL_pos) = signal_speed(UL, dir);

    // Compute the maximum characteristics due to state UR
    double signal_UR_neg, signal_UR_pos;
    std::tie(signal_UR_neg, signal_UR_pos) = signal_speed(UR, dir);

    // Davis: the largest and smallest of the two states
    return std::make_tuple(std::min(signal_UR_neg, signal_UL_neg),
                           std::max(signal_UR_pos, signal_UL_pos));
  }

};

}
}
