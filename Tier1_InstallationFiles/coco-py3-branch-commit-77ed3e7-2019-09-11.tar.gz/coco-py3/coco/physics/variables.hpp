/**
 *
 * This file is part of CoCo.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * CoCo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * CoCo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with CoCo. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <Eigen/Core>


namespace coco {

namespace variables {


struct MassDensity
{
  using data_type = double;

  static const std::string name() { return std::string("mass_density"); }
};


struct MomentumDensity
{
  using data_type = Eigen::Vector3d;

  static const std::string name() { return std::string("momentum_density"); }
};


struct Velocity
{
  using data_type = Eigen::Vector3d;

  static const std::string name() { return std::string("velocity"); }
};


struct EnergyDensity
{
  using data_type = double;

  static const std::string name() { return std::string("total_energy_density"); }
};

struct Pressure
{
  using data_type = double;

  static const std::string name() { return std::string("pressure"); }
};

struct MagneticField
{
 using data_type = Eigen::Vector3d;

 static const std::string name() { return std::string("magnetic_field"); }
};

}
}
