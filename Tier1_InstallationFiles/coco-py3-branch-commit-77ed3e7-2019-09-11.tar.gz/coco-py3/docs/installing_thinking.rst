Installation on ThinKing
========================


#. Load the correct modules
   ::

     source switch_to_2015a
     module load ScientificPython/2.9.4-foss-2015a-Python-2.7.9

#. Installation of namedlist python module
   ::

     mkdir -p "${VSC_HOME}/python_lib/lib/python2.7/site-packages/"
     export PYTHONPATH="${VSC_HOME}/python_lib/lib/python2.7/site-packages/:${PYTHONPATH}"
     echo 'export PYTHONPATH="${VSC_HOME}/python_lib/lib/python2.7/site-packages/:${PYTHONPATH}"' >> ~/.bashrc
     python -m easy_install --prefix="${VSC_HOME}/python_lib" namedlist

#. We install in $VSC_HOME
   ::

      cd; git clone https://USERNAME@github.com/jpomoell/coco.git
      cd coco
      cp makefiles/thinking.make Makefile
      make
