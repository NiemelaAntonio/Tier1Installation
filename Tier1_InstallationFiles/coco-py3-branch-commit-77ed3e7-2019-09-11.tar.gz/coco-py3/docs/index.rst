Welcome to CoCo's documentation!
=================================

Welcome to CoCo! CoCo is intended to be a light-weight, extensible, robust and
easy to use solver for hyperbolic conservation law-type equations. A particular
emphasis is to enable quick setup and prototyping of new simulation models.

Contents:

.. toctree::
   :maxdepth: 1

   installing
   installing_thinking

   example
