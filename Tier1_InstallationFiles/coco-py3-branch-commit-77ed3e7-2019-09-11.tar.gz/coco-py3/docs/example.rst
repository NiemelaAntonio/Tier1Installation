Running an example
==================

The quickest way to get started using CoCo is to run, study and play
with the provided example applications. In the following, we will take
a look at how to run the Orszag and Tang vortex example located in
:file:`examples/orszag-tang`.

Serial run
----------

To run the app on a single core:
::

   ./orszag-tang.py

The computation should not take more than a few minutes. The app accepts
a couple of command line parameters, run
::

  ./orszag-tang.py --help

to get basic information on those.

Parallel run
------------

To perform a parallel run, do:
::

   mpirun -np 8 ./orszag-tang


Visualizing using VisIt
-----------------------

The VTK output files produced by the code can be directly viewed by
e.g. `VisIt <https://wci.llnl.gov/simulation/computer-codes/visit/>`_.

When running, do:
::

    Open --> output/ot.visit
    Add --> Pseudocolor --> vx
    Draw

After rotating the view a bit, this should produce an image similar to

.. image:: ot_vx_initial.png

Using the play button or dragging the time slider, the last output should look
similar to

.. image:: ot_vx_final.png
