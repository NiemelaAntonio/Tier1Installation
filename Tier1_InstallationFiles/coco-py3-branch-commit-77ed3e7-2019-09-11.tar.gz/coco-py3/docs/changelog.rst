=========
Changelog
=========

0.2 (June 2019)
---------------------

* Transition to Python 3.7
* coco.tools.ConfigurationParser has been removed. Please use the standard library
  class configparser.ConfigParser instead.
