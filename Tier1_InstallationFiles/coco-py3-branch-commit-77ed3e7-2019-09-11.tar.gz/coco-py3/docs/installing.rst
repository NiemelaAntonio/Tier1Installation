Installation
============

CoCo is a C++14/Python 3.7 code that uses a number of external libraries, both in the
C++ portions of the codebase as well as in the Python parts.

For the C++ part, all the required libraries are contained in the :file:`external/`
directory and are header-only, i.e. they do not need to be compiled. Thus, to
compile the code, only a C++ compiler as well as the Python libraries are
needed. However, note that CoCo uses rather new features of C++, which means
that a fairly recent compiler is required (gcc >= 4.9, clang >= 3.6).

To actually run the code, a number of Python libraries are additionally
needed, see below.


Typical installation
--------------------

The installation typically proceeds by copying one of the template Makefile in the
:file:`makefiles/` directory and editing the settings according to the specifications
of the system. Note that if the system Python is used, the Python library
directories generally do not need to be specified.


Required Python dependencies
----------------------------

A number of standard Python libraries are used, including:

- `NumPy <http://www.numpy.org/>`__ (1.7 or later)
- `SciPy <http://www.scipy.org/>`_
- `Matplotlib <http://matplotlib.org/>`_

In addition, a few non-standard libraries are required:

- `namedlist <https://bitbucket.org/ericvsmith/namedlist/>`_

Often, output to the VTK format is requested in which case the
`PyEVTK package <https://bitbucket.org/pauloh/pyevtk/>`_ is needed.


MPI
---

For performing parallel runs, MPI is required. CoCo uses `mpi4py <http://mpi4py.readthedocs.org/>`__.
