CoCo
====

Welcome to CoCo! CoCo is intended to be a light-weight, extensible, robust and
easy to use solver for hyperbolic conservation law-type equations. A particular
emphasis is to enable quick setup and prototyping of new simulation models.

Before proceeding any further, the first thing you need to do is to build the
documentation that tells you what to do after you have finished reading this
file.


Building the documentation
--------------------------

If you do not have access to the documentation, you can build it as
follows:

    cd docs
    make html

This will generate html documentation that you read by opening the

    docs/_build/html/index.html

file. For the build to be successful, you need to have

 * [Sphinx](http://sphinx-doc.org/)
 * [Sphinx RTD theme](https://github.com/snide/sphinx_rtd_theme)

available on your system.
