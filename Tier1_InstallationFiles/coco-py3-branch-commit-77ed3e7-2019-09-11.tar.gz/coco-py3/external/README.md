This folder contains third party libraries used by CoCo
===========================================================

**Please note that these libraries are copyrighted by others than the CoCo
authors, but are included as allowed by their respective licenses. Please
consult the license of each library for details.**

Below is a list of the libraries and details of how they were included in the
repository.

Boost
--------------------------

A subset of Boost is used, and prepared as follows:

::
    mkdir boost
    mkdir boost/include
    mkdir tmp
    cd tmp
    wget https://downloads.sourceforge.net/project/boost/boost/1.63.0/boost_1_63_0.tar.bz2
    tar xf boost_1_63_0.tar.bz2
    cd boost_1_63_0
    ./bootstrap.sh
    ./b2 tools/bcp
    mkdir blibs
    ./dist/bin/bcp boost/range/irange.hpp boost/mpl/vector.hpp boost/function_types/property_tags.hpp boost/tti/has_member_function.hpp boost/logic/tribool.hpp boost/mpl/for_each.hpp boost/mpl/filter_view.hpp boost/mpl/contains.hpp blibs/
    mv blibs/boost ../../boost/include/
    cp LICENSE_1_0.txt ../../boost/
    cd ..
    cd ..
    rm -rf tmp
    cd boost
    git add *


gensimcell
--------------------------

::
    git clone https://github.com/nasailja/gensimcell
    cd gensimcell
    rm -rf .git/
    git add *


pybind11
--------------------------

::
    git clone https://github.com/pybind/pybind11
    cd pybind11
    git checkout tags/v2.0.1
    rm -rf .git
    git add *

xtensor
--------------------------

::
    git clone https://github.com/QuantStack/xtensor
    cd xtensor/
    git checkout tags/0.3.1
    rm -rf .git
    git add *

xtensor-python
--------------------------

::
    git clone https://github.com/QuantStack/xtensor-python
    cd xtensor-python/
    git checkout tags/0.3.0
    rm -rf .git
    git add *

Eigen
--------------------------

::
    wget http://bitbucket.org/eigen/eigen/get/3.3.2.tar.bz2
    tar xf 3.3.2.tar.bz2
    mv eigen-eigen-da9b4e14c255/ eigen
    cd eigen
    rm -rf bench/ blas/ cmake/ debug/ demos/ doc/ failtest/ lapack/ scripts/ test/ unsupported/
    rm -f .hg*
    git add *
