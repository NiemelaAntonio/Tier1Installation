/**
 *
 * This file is part of EUHFORIA.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * EUHFORIA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * EUHFORIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.
 *
 */


#define USE_XTENSORPYTHON_ARRAY

#include "coco/core/coco.hpp"
#include <pybind11/eigen.h>

#include "tracer.hpp"


PYBIND11_PLUGIN(tracer)
{
    namespace py = pybind11;

    py::module m("tracer", "Kernel for stream line tracing");


    py::class_<euhforia::tools::EulerStreamLine>(m, "EulerStreamLine")
      .def(py::init<>())
      .def("set_coordinate_axis", [](euhforia::tools::EulerStreamLine & self,
                                     const int dim,
                                     const decltype(self.grid.axis[0].coordinates) x) { self.grid.axis[dim].coordinates = x; })
      .def_readwrite("rmax", &euhforia::tools::EulerStreamLine::rmax)
      .def_readwrite("rmin", &euhforia::tools::EulerStreamLine::rmin)
      .def_readwrite("V1",   &euhforia::tools::EulerStreamLine::V1)
      .def_readwrite("V2",   &euhforia::tools::EulerStreamLine::V2)
      .def_readwrite("V3",   &euhforia::tools::EulerStreamLine::V3)
      .def("compute",        &euhforia::tools::EulerStreamLine::compute)
      ;

    py::class_<euhforia::tools::MidpointStreamLine>(m, "MidpointStreamLine")
      .def(py::init<>())
      .def("set_coordinate_axis", [](euhforia::tools::MidpointStreamLine & self,
                                     const int dim,
                                     const decltype(self.grid.axis[0].coordinates) x) { self.grid.axis[dim].coordinates = x; })
      .def_readwrite("rmax", &euhforia::tools::MidpointStreamLine::rmax)
      .def_readwrite("rmin", &euhforia::tools::MidpointStreamLine::rmin)
      .def_readwrite("V1",   &euhforia::tools::MidpointStreamLine::V1)
      .def_readwrite("V2",   &euhforia::tools::MidpointStreamLine::V2)
      .def_readwrite("V3",   &euhforia::tools::MidpointStreamLine::V3)
      .def("compute",        &euhforia::tools::MidpointStreamLine::compute)
      ;


  return m.ptr();
}
