/**
 *
 * This file is part of EUHFORIA.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * EUHFORIA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * EUHFORIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

/**
 * \brief Stream line tracing tools
 *
 */

#include <math.h>
#include <Eigen/Core>
#include <Eigen/Geometry>

#include "coco/core/coco.hpp"
#include "coco/core/grid.hpp"
#include "coco/core/constants.hpp"
#include "coco/core/functions.hpp"
#include "coco/geometry/transforms.hpp"


namespace euhforia {

namespace tools {


/*!
 * \brief Performs trilinear interpolation to a point p surrounded by 8 data points
 *        that form a cuboid enclosing p.
 *
 * \param[in]  p   Eigen::Vector3d containing the coordinates of the point at
 *                 which to compute
 *
 * \param[in]  cuboid_min_coordinates  Eigen::Vector3d containing the minimum coordinates
 *                                     of the nodes of the cuboid (0,0,0 for unit cube)
 *
 * \param[in]  cuboid_max_coordinates  Eigen::Vector3d containing the maximum coordinates
 *                                     of the nodes of the cuboid (1,1,1 for unit cube)
 *
 * \param[in]  cuboid_vertex_data      std::array containing the 8 data nodes (vertices)
 *                                     forming the cuboid, ordered as follows:
 *                                     (0,0,0), (1,0,0), (0,1,0), (1,1,0),
 *                                     (0,0,1), (1,0,1), (0,1,1), (1,1,1)
 *
 * \returns    data T interpolated to point p
 *
 */
template <class T>
T trilinear_interpolation(const Eigen::Vector3d & p,
                             const Eigen::Vector3d & cuboid_min_coordinates,
                             const Eigen::Vector3d & cuboid_max_coordinates,
                             const std::array<T, 8> & cuboid_vertex_data)
{

  //
  // Transform the interpolation point to the local unit cube (uc) coordinate system
  //

  // Translate
  Eigen::Vector3d p_uc = p - cuboid_min_coordinates;

  // Scale
  for (size_t d=0; d<3; ++d) {
    p_uc[d] = p_uc[d] / (cuboid_max_coordinates[d] - cuboid_min_coordinates[d]);
  }

  //
  // Perform unit cube interpolation
  //
  return  cuboid_vertex_data[0]*(1.0-p_uc[0])*(1.0-p_uc[1])*(1.0-p_uc[2])
        + cuboid_vertex_data[1]*(    p_uc[0])*(1.0-p_uc[1])*(1.0-p_uc[2])
        + cuboid_vertex_data[2]*(1.0-p_uc[0])*(    p_uc[1])*(1.0-p_uc[2])
        + cuboid_vertex_data[3]*(    p_uc[0])*(    p_uc[1])*(1.0-p_uc[2])
        + cuboid_vertex_data[4]*(1.0-p_uc[0])*(1.0-p_uc[1])*(    p_uc[2])
        + cuboid_vertex_data[5]*(    p_uc[0])*(1.0-p_uc[1])*(    p_uc[2])
        + cuboid_vertex_data[6]*(1.0-p_uc[0])*(    p_uc[1])*(    p_uc[2])
        + cuboid_vertex_data[7]*(    p_uc[0])*(    p_uc[1])*(    p_uc[2]);
}


double wrap_zero(const double x, const double max)
{
  return fmod(max + fmod(x, max), max);
}

/* wrap x -> [min,max) */
double wrap_to_interval(const double x, const double min, const double max)
{
  return min + wrap_zero(x - min, max - min);
}


template <class TGrid, class TData>
Eigen::Vector3d interpolate_nodal(const Eigen::Vector3d & point,
                                  const TGrid & grid,
                                  const TData & node_data)
{

  //
  // Find indices of the node that is the corner in the negative direction from
  // the current point
  //
  const auto i = grid.axis[0].get_left_index_of(point[0]);
  const auto j = grid.axis[1].get_left_index_of(point[1]);
  const auto k = grid.axis[2].get_left_index_of(point[2]);

  // TODO: check sanity of indices
  // TODO: check that idx+1 does not overflow

  //
  // Construct the coordinates of a cuboid of nearby
  // grid points enclosing p
  //
  Eigen::Vector3d
    cuboid_min_coordinate(grid.axis[0].coordinates(i),
                          grid.axis[1].coordinates(j),
                          grid.axis[2].coordinates(k));

  Eigen::Vector3d
    cuboid_max_coordinate(grid.axis[0].coordinates(i+1),
                          grid.axis[1].coordinates(j+1),
                          grid.axis[2].coordinates(k+1));


  //
  // Assign cuboid vertex data. The order of the vertices is:
  //
  //   (0,0,0), (1,0,0), (0,1,0), (1,1,0), (0,0,1), (1,0,1), (0,1,1), (1,1,1)
  //
  // where vertex (0,0,0) corresponds to index (i,j,k)
  //

  // NOTE NOTE Assumes Vector3d!!! decltype!!!
  std::array<Eigen::Vector3d, 8> cuboid_data;

  // NOTE NOTE provide functor that returns the data
  for (const auto dim : {0, 1, 2}) {
    cuboid_data[0][dim] = node_data[dim](i,   j,   k);
    cuboid_data[1][dim] = node_data[dim](i+1, j,   k);
    cuboid_data[2][dim] = node_data[dim](i,   j+1, k);
    cuboid_data[3][dim] = node_data[dim](i+1, j+1, k);

    cuboid_data[4][dim] = node_data[dim](i,   j,   k+1);
    cuboid_data[5][dim] = node_data[dim](i+1, j,   k+1);
    cuboid_data[6][dim] = node_data[dim](i,   j+1, k+1);
    cuboid_data[7][dim] = node_data[dim](i+1, j+1, k+1);
  }

  // Perform trilinear interpolation, return data
  return trilinear_interpolation(point, cuboid_min_coordinate, cuboid_max_coordinate, cuboid_data);
}



/**
 * \brief Stream line tracing using Euler stepping.
 *
 */
class EulerStreamLine
{
public:

  double rmin;
  double rmax;

  coco::xarray_t<double> V1;
  coco::xarray_t<double> V2;
  coco::xarray_t<double> V3;


public:

  EulerStreamLine() {}


  // start is a spherical coordinate
  Eigen::Vector3d compute(const Eigen::Vector3d start,
                          const bool follow_field_direction,
                          const double step_length,
                          const double max_path_length)
  {
    namespace transform = coco::geometry::transform;

    std::array<coco::xarray_t<double>, 3> V = {{V1, V2, V3}};


    // Cartesian coordinates of starting point
    Eigen::Vector3d x = transform::spherical::to_cartesian_coordinates(start);


    // Size of constant step taking into account direction.
    // NOTE: assumes step_length > 0
    const double ds = (follow_field_direction) ? step_length : -step_length;


    // Trace the stream line
    for (double s = 0.0; s < max_path_length; s += step_length) {

      // Current point in spherical basis
      const auto spherical_crd  = transform::cartesian::to_spherical_coordinates(x);

      // Field vector at current point
      const auto field_at_point
        = interpolate_nodal(spherical_crd, grid, V);

      // Compute Cartesian unit vector of the vector field at the current point
      const auto unit_direction_vector
        = transform::spherical::to_cartesian_vector(field_at_point, spherical_crd, false).normalized();

      // Next Cartesian point on field line: move a step ds in direction of field
      const Eigen::Vector3d xnext = x + ds*unit_direction_vector;

      // Check whether to accept the new point
      // If yes, update point
      if (do_stop(xnext)) {
        break;
      } else {
        x    = xnext;
      }
    }

    // Done. Convert final point to spherical basis
    const Eigen::Vector3d x_to_sph
      = transform::cartesian::to_spherical_coordinates(x);

    return x_to_sph;
  }

  // x cartesian coord
  bool do_stop(const Eigen::Vector3d & x) const
  {
    bool ret_val = false;

    const auto r = coco::geometry::transform::cartesian::to_spherical_coordinates(x)[0];

    if ((r <= rmin) or (r >= rmax)) ret_val = true;

    return ret_val;
  }


public:

  struct EmptyStruct {};

  coco::core::RectilinearGrid<EmptyStruct> grid;

};


/**
 * \brief Stream line tracing using second-order midpoint method
 *
 */
class MidpointStreamLine
{
public:

  double rmin;
  double rmax;

  coco::xarray_t<double> V1;
  coco::xarray_t<double> V2;
  coco::xarray_t<double> V3;


public:

  MidpointStreamLine() {}


  // start is a spherical coordinate
  Eigen::Vector3d compute(const Eigen::Vector3d start,
                          const bool follow_field_direction,
                          const double fractional_step_length,
                          const double max_path_length,
                          const double min_step_size)
  {
    namespace transform = coco::geometry::transform;

    std::array<coco::xarray_t<double>, 3> V = {{V1, V2, V3}};

    // Set longitudinal extent
    lon_min = grid.axis[2].coordinates(0);
    lon_max = grid.axis[2].coordinates(grid.axis[2].num_crds()-1);

    // Cartesian coordinates of starting point
    Eigen::Vector3d x = transform::spherical::to_cartesian_coordinates(start);

    // Follow field direction?
    const double reverse_direction = (follow_field_direction) ? 1.0 : -1.0;

    // Factor to scale step length with
    const double scale_step = fractional_step_length*reverse_direction;

    // Keep track of path length
    double path_length = 0.0;

    // Trace until maximum path length is reached (or exited otherwise)
    while (max_path_length > path_length) {

      // Compute approximate local grid size
      const auto xs = wrap(transform::cartesian::to_spherical_coordinates(x));

      const auto i  = grid.axis[0].get_left_index_of(xs[0]);
      const auto j  = grid.axis[1].get_left_index_of(xs[1]);
      const auto k  = grid.axis[2].get_left_index_of(xs[2]);

      const auto dr  = grid.axis[0].coordinates(i+1)-grid.axis[0].coordinates(i);
      const auto dth = grid.axis[1].coordinates(j+1)-grid.axis[1].coordinates(j);
      const auto dph = grid.axis[2].coordinates(k+1)-grid.axis[2].coordinates(k);

      const double local_grid_size
        = std::min({dr, xs[0]*dth, xs[0]*sin(xs[1])*dph});

      const double step_size = std::max(local_grid_size, min_step_size);

      // Step size
      const double ds  = step_size*scale_step;

      // Move a half step forward
      const Eigen::Vector3d xhalf = x + 0.5*ds*direction_vector(x, V);

      // Are we still inside the domain?
      if (do_stop(xhalf) == true) {
        break;
      }

      // Move a full step forward using the field at the half step
      const Eigen::Vector3d xnext = x + ds*direction_vector(xhalf, V);

      // Is the next point inside the domain? If not, return half point that
      // was still inside the domain
      if (do_stop(xnext) == true) {
        x            = xhalf;
        path_length += 0.5*std::abs(ds);
        break;
      }

      // Add segment to path length
      path_length += std::abs(ds);

      // Update point
      x = xnext;
    }

    // Done. Convert final point to spherical basis
    return wrap(transform::cartesian::to_spherical_coordinates(x));
  }


  template <class TVectorField>
  Eigen::Vector3d direction_vector(const Eigen::Vector3d x, const TVectorField & V) const
  {
    namespace transform = coco::geometry::transform;

    // Current point in spherical basis
    const Eigen::Vector3d spherical_crd
      = transform::cartesian::to_spherical_coordinates(x);

    // Wrap coordinate
    const Eigen::Vector3d wrapped_spherical_crd
      = wrap(spherical_crd);

    // Field vector at current point
    const Eigen::Vector3d field_at_point
      = interpolate_nodal(wrapped_spherical_crd, grid, V);

    // Compute Cartesian unit vector of the vector field at the current point
    const Eigen::Vector3d unit_direction_vector
      = transform::spherical::to_cartesian_vector(field_at_point, wrapped_spherical_crd, false).normalized();

    return unit_direction_vector;
  }


  Eigen::Vector3d wrap(const Eigen::Vector3d xs) const
  {

    // Wrap longitudinal coordinate
    const double lon = xs[2];
    const double lon_wrapped = lon_min + wrap_zero(lon - lon_min, lon_max - lon_min);

    return Eigen::Vector3d(xs[0], xs[1], lon_wrapped);
  }

  // x cartesian coord
  bool do_stop(const Eigen::Vector3d & x) const
  {
    bool ret_val = false;

    const auto r = coco::geometry::transform::cartesian::to_spherical_coordinates(x)[0];

    if ((r <= rmin) or (r >= rmax)) ret_val = true;

    return ret_val;
  }

private:

  double lon_min, lon_max;

public:

  struct EmptyStruct {};

  coco::core::RectilinearGrid<EmptyStruct> grid;

};



}
}
