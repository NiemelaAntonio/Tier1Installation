# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Magnetic field line tracer
"""

import copy

import astropy.coordinates
import euhforia.core.constants as constants
import euhforia.core.map
import euhforia.tools.tracer.tracer
import numpy as np
import sunpy.map


class FieldlineTracer(object):
    """Magnetic field line tracer.

    Traces magnetic field lines given a gridded vector field.

    Args:
        field (coco.core.VectorField)  :  Gridded vector field object
    """

    def __init__(self, field, method="rk2", rmin=0, rmax=np.inf):

        if method == "euler":
            self.tracer = euhforia.tools.tracer.tracer.EulerStreamLine()
        elif method == "rk2":
            self.tracer = euhforia.tools.tracer.tracer.MidpointStreamLine()
        else:
            raise ValueError("Unknown method" + method)

        # Pass coordinates to tracer kernel
        self.tracer.set_coordinate_axis(0, field.grid.axis[0].coordinates)
        self.tracer.set_coordinate_axis(1, field.grid.axis[1].coordinates)
        self.tracer.set_coordinate_axis(2, field.grid.axis[2].coordinates)

        # Pass field data to tracer kernel
        self.tracer.V1 = field.data["Br"]
        self.tracer.V2 = field.data["Bt"]
        self.tracer.V3 = field.data["Bp"]

        # TODO: Check that number of coordinates and data points matches
        # the (pointwise) assumptions of the tracer method. This should be
        # done by the tracer kernel.

        # Set domain limits
        self.tracer.rmax = min(rmax, field.grid.axis.r.coordinates[-1])
        self.tracer.rmin = max(rmin, field.grid.axis.r.coordinates[0])


class SynopticFieldLineTracer(object):
    """Synoptic field line tracing and storage

    This class provides functionality to compute magnetic field lines
    passing through a spherical shell. Basic data related to the connectivity of
    the traced field lines are stored.

    Args:
        radius (float)          : Radius of the spherical shell from which the
                                  tracing is performed (i.e. the starting points)
        deg_per_pixel (float)   : Angular resolution of the starting points
        direction (str)         : Trace towards smaller radial coordinates r ("inward"), or larger r ("outward")
        max_path_length (float) : Cutoff distance at which tracing is stopped
    """

    def __init__(
        self,
        radius,
        deg_per_pixel,
        direction,
        max_path_length,
        min_step_size,
        fractional_step_size=0.5,
        tracer=None,
        field_model=None,
        date=None,
        crval1=180.0,
    ):

        # TODO: REMOVE field_model dependency!!! It is there only due to the at()
        # call, functionality that should be part of the VectorField object in the tracer!

        self.tracer = tracer
        self.field_model = field_model
        self.date = date

        self.radius = radius
        self.deg_per_pixel = deg_per_pixel
        self.max_path_length = max_path_length
        self.min_step_size = min_step_size
        self.fractional_step_size = fractional_step_size
        self.crval1 = crval1

        #
        # Set direction of tracing
        #
        if direction == "inward":
            self.trace_outward = False
        elif direction == "outward":
            self.trace_outward = True
        else:
            raise ValueError("Unknown trace direction " + direction)

    def _create_empty_synoptic_map(self, bunit=None):

        m = euhforia.core.map.create_empty_map(
            date=self.date, deg_per_pixel=self.deg_per_pixel, bunit=bunit, crval1=self.crval1
        )

        return m

    def initialize_maps(self):
        """Create dict of maps containing the coordinates of the starting and ending points.

        The maps of the coordinates are created essentially for convenience, as the
        data they contain is also included in the metadata of the maps.
        """

        #
        # Get coordinates
        #
        lon, lat = euhforia.core.map.get_center_coordinates(self._create_empty_synoptic_map())

        #
        # Add them to dict as separate maps
        #
        self.at_start_pt = {}

        # Longitude coordinates
        self.at_start_pt["lon"] = self._create_empty_synoptic_map(bunit="deg")
        for j in range(len(lat)):
            self.at_start_pt["lon"].data[j, :] = lon

        # Latitude coordinates
        self.at_start_pt["lat"] = self._create_empty_synoptic_map(bunit="deg")
        for k in range(len(lon)):
            self.at_start_pt["lat"].data[:, k] = lat

        # Heliocentric radial height
        # self.at_start_pt["r"] = self._create_empty_synoptic_map(bunit="m")
        # self.at_start_pt["r"].data = np.ones(self.at_start_pt["lon"].data.shape) * self.radius
        self.at_start_pt["r"] = sunpy.map.Map(
            np.ones(self.at_start_pt["lon"].data.shape)*self.radius, self._create_empty_synoptic_map(bunit="m").meta
        )

        #
        # Add end points as separate dict
        #
        self.at_end_pt = {}
        self.at_end_pt["lon"] = copy.deepcopy(self.at_start_pt["lon"])
        self.at_end_pt["lat"] = copy.deepcopy(self.at_start_pt["lat"])
        self.at_end_pt["r"] = copy.deepcopy(self.at_start_pt["r"])

        #
        # Magnetic field components
        #
        mag_unit = self.field_model.magnetogram.meta["bunit"]

        self.at_start_pt["Br"] = self._create_empty_synoptic_map(bunit=mag_unit)
        self.at_start_pt["Bt"] = self._create_empty_synoptic_map(bunit=mag_unit)
        self.at_start_pt["Bp"] = self._create_empty_synoptic_map(bunit=mag_unit)

        self.at_end_pt["Br"] = self._create_empty_synoptic_map(bunit=mag_unit)
        self.at_end_pt["Bt"] = self._create_empty_synoptic_map(bunit=mag_unit)
        self.at_end_pt["Bp"] = self._create_empty_synoptic_map(bunit=mag_unit)

    def compute(self):

        if self.tracer is None or self.field_model is None:
            raise ValueError("Tracer of Field model not set")

        self.initialize_maps()

        #
        # Get coordinates
        #
        lons, lats = euhforia.core.map.get_center_coordinates(self.at_start_pt["lon"])

        #
        # For each point on map, trace field line and record results
        #
        for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
            for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

                start_pt = (self.radius, 0.5*np.pi - lat.radian, lon.radian)
                B_at_start = self.field_model.at_coordinate(start_pt)

                trace_outward = bool(self.trace_outward == (B_at_start[0] > 0))

                end_pt = self.tracer.tracer.compute(
                    start_pt, trace_outward, self.fractional_step_size, self.max_path_length, self.min_step_size
                )

                B_at_end = self.field_model.at_coordinate(end_pt)

                # Record data
                self.at_start_pt["Br"].data[j, k] = B_at_start[0]
                self.at_start_pt["Bt"].data[j, k] = B_at_start[1]
                self.at_start_pt["Bp"].data[j, k] = B_at_start[2]

                self.at_start_pt["r"].data[j, k] = start_pt[0]
                self.at_start_pt["lat"].data[j, k] = 90.0 - 180.0*start_pt[1]/np.pi
                self.at_start_pt["lon"].data[j, k] = start_pt[2]*180.0/np.pi

                self.at_end_pt["r"].data[j, k] = end_pt[0]
                self.at_end_pt["lat"].data[j, k] = 90.0 - 180.0*end_pt[1]/np.pi
                self.at_end_pt["lon"].data[j, k] = end_pt[2] * 180.0/np.pi

                self.at_end_pt["Br"].data[j, k] = B_at_end[0]
                self.at_end_pt["Bt"].data[j, k] = B_at_end[1]
                self.at_end_pt["Bp"].data[j, k] = B_at_end[2]
