# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module that defines useful physical and astronomical constants.
"""

import scipy.constants

#
# Astronomical constants
#

# The nominal solar radius as defined by the IAU, m
solar_radius = 695700.0e3

# The astronomical unit as defined by the IAU, m
astronomical_unit = 149597870700.0

# Carrington synodic rotation period, s
solar_synodic_rotation_period = 27.2753*24.0*60.0*60.0

# The nominal solar mass as defined by the IAU, kg
# In fact, IAU defines only GM
solar_GM = 1.3271244e20
solar_mass = solar_GM / scipy.constants.G

#
# Physics constants
#

# Mass of proton, kg
proton_mass = scipy.constants.proton_mass

# Boltzmann constant, J/K
kB = scipy.constants.k

# Gravitational constant
G = scipy.constants.G

# Magnetic constant
mu0 = scipy.constants.mu_0
