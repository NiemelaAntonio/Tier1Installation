version_info = (1, 1, 0)
__version__ = ".".join(map(str, version_info))


def check_coco_version():
    from distutils.version import LooseVersion
    import coco

    required_version = "0.2.0"

    if not (LooseVersion(coco.__version__) == LooseVersion(required_version)):
        raise ImportError(
            "Version " + coco.__version__ + " of CoCo imported, "
            "but " + required_version + " required. "
            "Please update!"
        )
