# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""I/O modules
"""

import glob
import os

import numpy as np

import coco.io.point


def load_heliospheric_data(file_pattern):

    loader = HeliosphericDataLoader()

    return loader.load(file_pattern)


class HeliosphericDataLoader(object):
    """Class for loading data from the heliospheric model.

    This class acts as a generic front-end for loading data from the
    heliospheric MHD simulation.
    """

    def __init__(self):

        # Supported file formats by file extension
        self.supported_formats = (".npz",)

    def load(self, file_pattern):

        #
        # Select supported files
        #
        files = self.select_supported(file_pattern)

        #
        # Load based on file extension
        #
        _, file_extension = os.path.splitext(files[0])

        if file_extension in (".npz"):
            from . import io_numpy

            data = io_numpy.LoadNumpyOutputData(files)
        else:
            raise AttributeError("Loader matching the given files not available")

        return data

    def select_supported(self, file_pattern):

        #
        # Select supported files
        #
        _, file_extension = os.path.splitext(file_pattern)

        if len(file_extension) > 0:
            # An extension has been specified: the user is opting for a more
            # specific choice
            if file_extension not in self.supported_formats:
                raise ValueError("Unsupported file format: " + file_extension)
            else:
                files = glob.glob(file_pattern)

        else:
            # Grab all possible supported formats.
            all_supported_files = []
            for file_format in self.supported_formats:
                all_supported_files.append(glob.glob(file_pattern + "*" + file_format))

            # Select (promoted):
            files = all_supported_files[0]

        if len(files) == 0:
            raise ValueError("No files found")

        return files


class VirtualSpacecraftPointOutput(coco.io.point.PointDataOutputEvent):
    def __init__(self, file_name, p, sim, data, vs, **kwargs):

        coco.io.point.PointDataOutputEvent.__init__(self, file_name, p, sim, data, **kwargs)

        self.vs = vs

    def get_position(self):

        r, lat, lon = self.vs.position(self._sim.datetime)

        return (r, 0.5*np.pi - lat, lon)
