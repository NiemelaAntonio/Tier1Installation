# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""NumPy data I/O
"""

import glob

import numpy as np

import coco.core
import euhforia.core.constants as constants


class LoadNumpyOutputData(object):
    """Load npz data output stored in separate files per process to one file.
    """

    def __init__(self, file_base_name=None):

        if file_base_name is not None:
            self.load(file_base_name)

    def load(self, files):

        #
        # Load data from files associated with the given base name
        #
        # files = glob.glob(file_base_name)

        data_from_file = []
        for f in files:
            data_from_file.append(np.load(f, allow_pickle=True))

        #
        # Construct global grid
        #
        self.grid = coco.core.Grid(num_ghost_cells=data_from_file[0]["num_ghosts"])
        self.grid.geometry = "spherical"

        r = coco.CoordinateAxis(name="r", unit=constants.astronomical_unit)
        r.coordinates = np.unique(np.concatenate([data["r"] for data in data_from_file]))

        clt = coco.CoordinateAxis(name="clt")
        clt.coordinates = np.unique(np.concatenate([data["clt"] for data in data_from_file]))

        lon = coco.CoordinateAxis(name="lon")
        lon.coordinates = np.unique(np.concatenate([data["lon"] for data in data_from_file]))

        self.grid.set_coordinate_axes(r, clt, lon, add_ghost_coordinates=False)

        #
        # Save time
        #
        self.time = data_from_file[0]["time"]
        self.datetime = data_from_file[0]["datetime"]
        # self.units = data_from_file[0]['units']

        #
        # Initialize global variables
        #
        self.vr = np.zeros(self.grid.num_cells)
        self.vclt = np.zeros(self.grid.num_cells)
        self.vlon = np.zeros(self.grid.num_cells)

        self.P = np.zeros(self.grid.num_cells)
        self.n = np.zeros(self.grid.num_cells)

        self.Br = np.zeros([len(crds) for crds in self.grid.face_center_coords(0)])
        self.Bclt = np.zeros([len(crds) for crds in self.grid.face_center_coords(1)])
        self.Blon = np.zeros([len(crds) for crds in self.grid.face_center_coords(2)])

        # Make accessible via dict
        self.data = {
            "vr": self.vr,
            "vclt": self.vclt,
            "vlon": self.vlon,
            "P": self.P,
            "n": self.n,
            "Br": self.Br,
            "Bclt": self.Bclt,
            "Blon": self.Blon,
        }

        # Attach units
        self.units = {
            "vr": "km/s",
            "vclt": "km/s",
            "vlon": "km/s",
            "P": "Pa",
            "n": "cm$^{-3}$",
            "Br": "nT",
            "Bclt": "nT",
            "Blon": "nT",
        }

        #
        # Merge data
        #
        for data in data_from_file:

            i = abs(self.grid.axis.r.coordinates - data["r"][0]).argmin()
            j = abs(self.grid.axis.clt.coordinates - data["clt"][0]).argmin()
            k = abs(self.grid.axis.lon.coordinates - data["lon"][0]).argmin()

            for key in ("vr", "vclt", "vlon", "P", "n", "Br", "Bclt", "Blon"):

                shape = data[key].shape

                self.data[key][i : (i + shape[0]), j : (j + shape[1]), k : (k + shape[2])] = data[key][:, :, :]

    def add_variable(self, data, name, unit, inject=False):

        # Inject the data
        if inject:
            setattr(self, name, data)

        # Add to variable dict
        self.data[name] = data

        # Add unit
        self.units[name] = unit
