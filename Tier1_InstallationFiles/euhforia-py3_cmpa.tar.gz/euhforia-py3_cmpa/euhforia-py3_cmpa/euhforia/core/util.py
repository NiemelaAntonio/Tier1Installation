# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

"""Miscellaneous utility functions
"""

import errno
import os

import astropy.time
import numpy as np
import sunpy.time
import sunpy.util.net


def time_of_carrington_rotation_number(cr):
    """Compute time from given Carrington rotation number

    The algorithm is the one given in
    Astronomical Algorithms, 2nd ed., Chapter 29. Inspired by the code in
    https://github.com/Helioviewer-Project/helioviewer.org

    Args:
        cr (float) : Carrington rotation number

    Returns:
        astropy Time object
    """

    # Compute approximate Julian date
    jd = 2398140.2270 + 27.2752316*cr

    # Compute correction
    m = (281.96 + 26.882476*cr)*np.pi/180.0

    corr = 0.1454*np.sin(m) - 0.0085*np.sin(2.0*m) - 0.0141*np.cos(2.0*m)

    jd += corr

    return astropy.time.Time(jd, format="jd")


def carrington_rotation_number(t):
    """Compute Carrington rotation number from given time
    """

    # Julian day corresponding to the given time
    jd = astropy.time.Time(sunpy.time.parse_time(t)).jd

    # Approximate result
    cr = (jd - 2398140.2270)/27.2752316

    #
    # Apply correction
    #

    # Compute the time given by the approximate cr
    jd_approx_cr = time_of_carrington_rotation_number(cr).jd

    # Deviation
    err = (jd - jd_approx_cr)/27.2752316

    return cr + err


def carrington_longitude(t):
    """Compute the Carrington longitude in degrees at given time
    """

    cr = carrington_rotation_number(t)

    return 360.0 - 360.0*(cr - int(cr))


def get_subset_of_spherical_surface(input_array, extract_at_idx, hwidth):
    """Return a window of a map of a spherical surface
    """

    #
    # Create a 3x3 duplicated array that is periodic in lon, shear-periodic in lat
    #
    shape = np.array(input_array.shape, dtype=int)

    m = np.zeros(shape*3)

    # Shear-periodic in Latitdunial direction
    m[0*shape[0] : 1*shape[0], shape[1] : 2*shape[1]] \
        = np.flipud(np.roll(input_array, shift=int(shape[1]/2), axis=1))

    m[1*shape[0] : 2*shape[0], shape[1] : 2*shape[1]] = input_array

    m[2*shape[0] : 3*shape[0], shape[1] : 2*shape[1]] \
        = np.flipud(np.roll(input_array, shift=int(shape[1]/2), axis=1))

    # Periodic in Longitudinal direction
    for k in (0, 2):
        m[:, k*shape[1] : (k + 1)*shape[1]] = m[:, shape[1] : 2*shape[1]]

    #
    # Extract subset from composite
    #
    window_size = np.array((hwidth, hwidth)) if np.isscalar(hwidth) else np.array(hwidth)

    start = shape - window_size + np.array(extract_at_idx, dtype=int)
    end = start + window_size*2

    return m[start[0] : (end[0] + 1), start[1] : (end[1] + 1)]


def replace_nan_with_average(arr):
    """Given a 2D array, replaces NaNs in the array by averaging neighboring
    array entries. Edges are handled using sphere-periodicity.
    """

    if not np.any(np.isnan(arr)):
        return arr

    #
    # Get bad pixels
    #
    bad_pixels = np.where(np.isnan(arr) == True)

    num_bad_pixels = len(bad_pixels[0])

    cleaned_arr = np.copy(arr)

    # For each bad pixel, extract a neighbourhood of pixels to average
    for idx in range(num_bad_pixels):

        i, j = bad_pixels[0][idx], bad_pixels[1][idx]

        # Compute average value excluding nans
        avg = np.nanmean(get_subset_of_spherical_surface(arr, (i, j), hwidth=1))

        if np.isnan(avg):
            avg = np.nanmean(get_subset_of_spherical_surface(arr, (i, j), hwidth=2))

        if np.isnan(avg):
            raise ValueError("Too many NaNs in array")

        cleaned_arr[i, j] = avg

    return cleaned_arr


def download_remote_file(remote_file_URL, **kwargs):
    """Downloads a file given a URL.

    Downloads a file given by the URL to the
    specified directory.

    Args:
        file_URL               : full URL of file
    Returns:
        Path+name of the file that has been stored
    """

    save_directory = kwargs.get("save_directory", "./")

    # Create the directory if it does not exist
    # Avoids race condition: http://stackoverflow.com/a/5032238/720077
    try:
        os.makedirs(save_directory)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise

    replace = kwargs.get("replace", False)

    # Full path and name of local file to be stored
    #
    local_file_name = save_directory + remote_file_URL.split("/")[-1]

    # Download file if it doesn't already exist (and replace is False)
    #
    if (not os.path.isfile(local_file_name)) or replace:

        print("Retrieving file", remote_file_URL)

        # data = urllib.URLopener()
        # data.retrieve(remote_file_URL, local_file_name)

        sunpy.util.net.download_file(remote_file_URL, save_directory, overwrite=True)

    return local_file_name
