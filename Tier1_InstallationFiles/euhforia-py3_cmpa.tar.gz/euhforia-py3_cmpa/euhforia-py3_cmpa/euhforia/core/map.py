# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

"""Tools for working with data maps.
"""

import copy
import datetime

import astropy
import astropy.coordinates
import astropy.units
import numpy as np
import sunpy
import sunpy.map
import sunpy.sun

import euhforia.core.util as util


def create_map_meta(enforce_even_num_of_pixels=True, **kwargs):
    """Create meta data for map.

    Creates meta data for a map. By default, Carrington Lat-Lon Plate Carre map
    is created with 180 (0) as the Carrington longitude (latitude) of the map
    center. However, the angular resolution of the map needs to be specified
    for a map to be created.

    Note that the requested degrees per pixel for non-divisible cases will be
    rounded so that it is consistent with the integer number of pixels.

    Returns:
        sunpy MapMeta
    """

    date = kwargs.pop("date", datetime.datetime.now())
    deg_per_pixel = kwargs.pop("deg_per_pixel", None)
    dlon = kwargs.pop("dlon", None)
    dlat = kwargs.pop("dlat", None)
    dsinlat = kwargs.pop("dsinlat", None)
    ctype1 = kwargs.pop("ctype1", "CRLN-CAR")
    ctype2 = kwargs.pop("ctype2", "CRLT-CAR")
    crval1 = kwargs.pop("crval1", 180.0)
    crval2 = kwargs.pop("crval2", 0.0)

    if ctype1.split("-")[0][-2::] != "LN":
        raise ValueError("CTYPE1 should correspond to Longitude")

    if ctype2.split("-")[0][-2::] != "LT":
        raise ValueError("CTYPE2 should correspond to Latitude")

    # Projection
    proj = ctype1.split("-")[-1]

    if ctype1.split("-")[-1] != ctype2.split("-")[-1]:
        raise ValueError("Projections for axes not the same")

    if proj not in ("CAR", "CEA"):
        raise ValueError("Unsupported projection: " + proj)

    # Carrington/Stonyhurst
    hgtype = ctype1.split("-")[0][0:-2]

    if ctype1.split("-")[0][0:-2] != ctype2.split("-")[0][0:-2]:
        raise ValueError("Heliographic coordinate type for axes not the same")

    if hgtype not in ("CR", "HG"):
        raise ValueError("Unsupported coordinate type: " + hgtype)

    # Get pixel spacing
    dlon = deg_per_pixel if dlon is None else dlon

    if dlon is None:
        raise ValueError("Unspecified dlon")

    if proj == "CAR":
        dlat = deg_per_pixel if dlat is None else dlat
        if dlat is None:
            raise ValueError("Unspecified dlat")
    elif proj == "CEA":
        if dsinlat is None:
            raise ValueError("Unspecified dsinlat")

    # Determine number of pixels
    num_lon_pixels = int(360.0/dlon)

    if proj == "CAR":
        num_lat_pixels = int(180.0/dlat)
    elif proj == "CEA":
        num_lat_pixels = int(2.0/dsinlat)

    if enforce_even_num_of_pixels:
        num_lat_pixels = num_lat_pixels & (~1)
        num_lon_pixels = num_lon_pixels & (~1)

    # Set metadata
    meta = {
        "date": date,
        "date-obs": date,
        "naxis1": num_lon_pixels,
        "naxis2": num_lat_pixels,
        "ctype1": ctype1,
        "ctype2": ctype2,
        "cunit1": "deg",
        "cunit2": "deg",
        "cdelt1": 360.0/num_lon_pixels,
        "cdelt2": 180.0/num_lat_pixels if proj == "CAR" else (2.0/num_lat_pixels)/(np.pi/180.0),
        "crpix1": (num_lon_pixels + 1)/2.0,
        "crpix2": (num_lat_pixels + 1)/2.0,
        "crval1": crval1,
        "crval2": crval2,
        "dsun_obs": sunpy.coordinates.sun.earth_distance(date).to(astropy.units.m),
        "crln_obs": sunpy.coordinates.sun.L0(date).to(astropy.units.deg),
        "crlt_obs": sunpy.coordinates.sun.B0(date).to(astropy.units.deg),
    }

    # Add additional arguments that are potentially passed in
    meta.update(kwargs)

    return sunpy.util.MetaDict(meta)


def create_empty_map(enforce_even_num_of_pixels=True, **kwargs):
    """Creates an empty SunPy map.

    Creates data and meta for an empty SunPy map, see create_map_meta for more
    details.
    """

    # Create metadata
    meta = create_map_meta(enforce_even_num_of_pixels, **kwargs)

    # Init data container
    data = np.zeros((meta["naxis2"], meta["naxis1"]))

    return sunpy.map.GenericMap(data, meta)


def regrid(input_map, deg_per_pixel):
    """Regrids a map to a uniform Plate Carree map.

    Args:
        input_map (sunpy.Map) : Input map to regrid
        deg_per_pixel (float) : Degrees per pixel of the new map

    Returns:
        sunpy.Map

    """

    #
    # Create new map
    #
    m = create_empty_map(
        deg_per_pixel=deg_per_pixel,
        bunit=input_map.meta["bunit"],
        detector=input_map.meta["detector"],
        date=input_map.meta["date"],
        crval1=input_map.meta["crval1"],
        ctype1=input_map.meta["ctype1"][0:2] + "LN-CAR",
        ctype2=input_map.meta["ctype2"][0:2] + "LT-CAR"
        # crval2   = input_map.meta['crval2'],
    )

    # Regrid using the new map
    m = regrid_to_grid_of_map(input_map, m)

    return m


def regrid_to_grid_of_map(input_map, grid_map):
    """Regrids a map.

    Rebins a map to the grid of a given new map. The regridding is done by
    summing the flux contributions from the input map to the pixels of the new
    map. As a result, the flux is conserved in the regridding. In this procedure,
    the physical quantity is assumed to be constant within each pixel. The exact
    integrated spherical area element is used to compute the area of each pixel.

    Args:
        input_map (sunpy.Map) : Input map to regrid
        grid_map (sunpy.Map)  : Map defining the grid to which to regrid

    Returns:
        sunpy.Map containing the rebinned map. The metadata is copied from grid_map.
    """

    # Edge coordinates of pixels of the input map
    input_lon, input_lat = get_edge_coordinates(input_map)

    # Edge coordinates of the new map
    output_lon, output_lat = get_edge_coordinates(grid_map)

    # Transform longitude so as to have a monotonically increasing coordinate from 0 to 360
    output_lon = astropy.coordinates.Longitude(output_lon - output_lon[0], unit="deg").value
    input_lon = astropy.coordinates.Longitude(input_lon - input_lon[0], unit="deg").value

    # Make sure lon edge coordinates are not the same
    output_lon[-1] = output_lon[0] + 360.0
    input_lon[-1] = input_lon[0] + 360.0

    # Finally, convert to rad
    for crd in (output_lon, input_lon, output_lat, input_lat):
        crd *= np.pi/180.0

    #
    # Find pixels in lat that overlap, and store the indices to their edges
    #
    j_indices = []
    for j, lat in enumerate(get_center_coordinates(grid_map)[1]):

        jlower = np.where(output_lat[j] >= input_lat)[0][-1]
        jupper = np.where(output_lat[j + 1] <= input_lat)[0][0]

        j_indices.append(range(jlower, jupper))

    #
    # Same in lon
    #
    k_indices = []
    for k, lon in enumerate(get_center_coordinates(grid_map)[0]):

        klower = np.where(output_lon[k] >= input_lon)[0][-1]
        kupper = np.where(output_lon[k + 1] <= input_lon)[0][0]

        k_indices.append(range(klower, kupper))

    #
    # Perform regridding
    #
    data = np.zeros((len(output_lat) - 1, len(output_lon) - 1))
    for j, lat in enumerate(get_center_coordinates(grid_map)[1]):
        for k, lon in enumerate(get_center_coordinates(grid_map)[0]):

            # Area of the output pixel (without R^2 as it will cancel out)
            output_area = (output_lon[k + 1] - output_lon[k])*(np.sin(output_lat[j + 1]) - np.sin(output_lat[j]))

            # Compute flux
            # NOTE: This could be made faster by computing the area in a separate loop,
            # and using broadcasting here
            flux = 0.0
            for ji in j_indices[j]:
                for ki in k_indices[k]:

                    #
                    # Compute the area of the region where the two pixels overlap
                    #
                    lon_lower = max(input_lon[ki], output_lon[k])
                    lon_upper = min(input_lon[ki + 1], output_lon[k + 1])
                    lat_lower = max(input_lat[ji], output_lat[j])
                    lat_upper = min(input_lat[ji + 1], output_lat[j + 1])

                    overlap_area = (lon_upper - lon_lower)*(np.sin(lat_upper) - np.sin(lat_lower))

                    # Flux from this pixel area
                    flux += input_map.data[ji, ki]*overlap_area

            data[j, k] = flux/output_area

    return sunpy.map.GenericMap(data, copy.copy(grid_map.meta))


def to_stonyhurst(m):
    """Transforms the map to the Stonyhurst system

    The transformation is done by changing the metadata only. No relocation/rotation
    of pixels is performed.

    Args:
        m (sunpy.Map) : Input map
    Return:
        Transformed sunpy.Map
    """

    if "HG" in m.meta["ctype1"]:
        return m

    meta = copy.copy(m.meta)

    meta["ctype1"] = meta["ctype1"].replace("CR", "HG")
    meta["ctype2"] = meta["ctype2"].replace("CR", "HG")

    # Carrington longitude of central meridian
    crln_cm = util.carrington_longitude(m.meta["date"])

    meta["crval1"] = astropy.coordinates.Longitude(
        meta["crval1"] - crln_cm, unit="deg", wrap_angle=180*astropy.units.deg
    ).value

    return sunpy.map.GenericMap(m.data, meta)


def rotate_map_in_longitude(m, angle, wrap_angle=360):
    """Rotates the map in longitude

    The rotation is done by changing the metadata only. No relocation
    of pixels is performed.

    Args:
        m (sunpy.Map) : Input map
        angle (float) : Angle to rotate by, deg
        wrap_angle (float) : Angle at which the longitudinal coordinate is wrapped, deg
    Return:
        Transformed sunpy.Map
    """

    meta = copy.copy(m.meta)

    meta["crval1"] = astropy.coordinates.Longitude(
        meta["crval1"] + angle, unit="deg", wrap_angle=wrap_angle*astropy.units.deg
    ).value

    return sunpy.map.GenericMap(m.data, meta)


def compute_flux(m):
    """Computes the total flux of the map.

    Args:
        input_map (sunpy.Map) : Input map
    """

    # Get map edge coordinates
    output_lon, output_lat = get_edge_coordinates(m)

    # Translate longitude so as to have a monotonically increasing coordinate from 0 to 360
    output_lon = astropy.coordinates.Longitude(output_lon - output_lon[0], unit="deg").value
    output_lon[-1] = output_lon[0] + 360.0

    # Finally, convert to rad
    # NOTE: this assumes coordinates are in deg
    for crd in (output_lon, output_lat):
        crd *= np.pi/180.0

    # Compute area element factors
    sin_lat = np.sin(output_lat)
    dsin_lat = sin_lat[1::] - sin_lat[0:-1]
    dlon = output_lon[1::] - output_lon[0:-1]

    flux = 0.0
    for j, lat in enumerate(get_center_coordinates(m)[1]):
        for k, lon in enumerate(get_center_coordinates(m)[0]):

            # Area of the output pixel (without R^2 as it will cancel out)
            area = dlon[k]*dsin_lat[j]
            flux += m.data[j, k]*area

    return flux


def compute_unsigned_flux(m):
    """Computes the total unsigned flux of the map.

    Args:
        input_map (sunpy.Map) : Input map
    """

    # Get map edge coordinates
    output_lon, output_lat = get_edge_coordinates(m)

    # Translate longitude so as to have a monotonically increasing coordinate from 0 to 360
    output_lon = astropy.coordinates.Longitude(output_lon - output_lon[0], unit="deg").value
    output_lon[-1] = output_lon[0] + 360.0

    # Finally, convert to rad
    # NOTE: this assumes coordinates are in deg
    for crd in (output_lon, output_lat):
        crd *= np.pi/180.0

    # Compute area element factors
    sin_lat = np.sin(output_lat)
    dsin_lat = sin_lat[1::] - sin_lat[0:-1]
    dlon = output_lon[1::] - output_lon[0:-1]

    unsigned_flux = 0.0
    for j, lat in enumerate(get_center_coordinates(m)[1]):
        for k, lon in enumerate(get_center_coordinates(m)[0]):

            # Area of the output pixel (without R^2 as it will cancel out)
            # NOTE: Assumes the coordinates returned by get_edge_coordinates
            # are degrees
            # area  = (np.pi/180.0)*(output_lon[k+1]-output_lon[k])*(np.sin(output_lat[j+1]*np.pi/180.0)-np.sin(output_lat[j]*np.pi/180.0))
            area = dlon[k]*dsin_lat[j]
            unsigned_flux += abs(m.data[j, k])*area

    return unsigned_flux


def smooth(input_map, num_steps=5, coarse_res=180.0/174.0, fine_res=0.25, final_res=1.0):
    """Flux-conserving smoothing of map.

    Uses flux-conserving regridding in a sequence of alternating interpolations
    from a map with a coarse resolution to a map with a finer resolution.

    Args:
        input_map (sunpy.Map) : Input map
        num_steps (int)       : Number of smoothing cycles to perform
        coarse_res (float)    : deg_per_pixel resolution of coarse map
        fine_res (float)      : deg_per_pixel resolution of fine map
        final_res (float)     : deg_per_pixel resolution of final map
    """

    m = input_map

    for step in range(num_steps):

        m_coarse = regrid(m, deg_per_pixel=coarse_res)
        m = regrid(m_coarse, deg_per_pixel=fine_res)

    return regrid(m, deg_per_pixel=final_res)


def get_center_coordinates(m):
    """Computes the center coordinates of the pixels of the map.

    Args:
        m (sunpy.Map) : Input map
    Returns:
        tuple containing the x1 and x2 center coordinates
    """

    x = m.wcs.wcs_pix2world(np.arange(int(m.meta["naxis1"])), 0, 0)[0]
    y = m.wcs.wcs_pix2world(0, np.arange(int(m.meta["naxis2"])), 0)[1]

    return x, y


def get_edge_coordinates(m):
    """Computes the edge coordinates of the pixels of the map.

    Args:
        m (sunpy.Map) : Input map
    Returns:
        tuple containing the x1 and x2 edge coordinates
    """
    x = m.wcs.wcs_pix2world(np.arange(int(m.meta["naxis1"]) + 1) - 0.5, 0, 0)[0]
    y = m.wcs.wcs_pix2world(0, np.arange(int(m.meta["naxis2"]) + 1) - 0.5, 0)[1]

    return x, y


def get_ascending_longitudinal_coordinates(lon):
    """Provides periodic longitudinal coordinates that are strictly increasing.

    Given an array of longitudinal coordinates, transforms the coordinates
    using periodicity so that the coordinate values are strictly increasing.

    Args:
        lon (np.array) : Array of coordinate values, degrees
    Returns:
        np.array of the transformed coordinate values
    """

    # Wrap to 180 deg
    lon_180 = astropy.coordinates.Longitude(lon, unit="deg", wrap_angle=180.0*astropy.units.deg).value

    # Find point closest (in absolute sense) to zero
    min_lon_180_idx = abs(lon_180).argmin()

    # Wrap separately left of zero and right of zero coordinates
    lon_left = lon_180[0:min_lon_180_idx]
    lon_right = lon_180[min_lon_180_idx::]

    lon_left[np.where(lon_left > 0.0)] -= 360.0
    lon_right[np.where(lon_right < 0.0)] += 360.0

    # Make sure no spurious jump was created at the interface
    lon_left[-4::][np.where(lon_left[-4::] < -180.0)] += 360.0
    lon_right[0:4][np.where(lon_right[0:4] > 180.0)] -= 360.0

    return np.concatenate((lon_left, lon_right))
