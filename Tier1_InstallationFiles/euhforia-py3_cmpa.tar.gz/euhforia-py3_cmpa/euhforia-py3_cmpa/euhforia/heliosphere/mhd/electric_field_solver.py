# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""PTD Electric field solver
"""

import numpy as np

import pyfishpack


class ElectricFieldSolver(object):
    def __init__(self):

        self.poisson_solver = pyfishpack.HelmholtzSolver(geometry="spherical", dim="2D", colocation="centered")

        self.poisson_solver.lam = 0.0

    def set_grid(self, clt_edges, lon_edges, R):
        """Set grid coordinates.

        The poloidal potential is computed at positions identical to those of Br.
        These are centered positions as compared to the grid edges.

        Args:
            clt_edges : In-domain edge coordinates of the co-latitudinal grid
            lon_edges : In-domain edge coordinates of the longitudinal grid
            R         : Radius of sphere
        """

        # TODO: Check that the grid is uniform

        self.R = R

        # Number of in-domain cells
        self.Nclt, self.Nlon = len(clt_edges) - 1, len(lon_edges) - 1

        # Grid spacing
        self.dclt = clt_edges[1] - clt_edges[0]
        self.dlon = lon_edges[1] - lon_edges[0]

        # Store coordinates
        self.indomain_clt_edges = clt_edges
        self.indomain_lon_edges = lon_edges

        # Compute potential on centered co-latitudinal coordinates.
        # In order to compute the Elon electric field at the
        # co-latitudinal boundary edges, an extra point is
        # needed as compared to the given in-domain cells
        clt_indomain = 0.5*(clt_edges[1::] + clt_edges[0:-1])
        clt = np.zeros(len(clt_indomain) + 2)
        clt[1:-1] = clt_indomain
        clt[0] = clt_edges[0] - 0.5*self.dclt
        clt[-1] = clt_edges[-1] + 0.5*self.dclt

        # Compute potential on shifted longitudinal coordinates:
        # Fishpack requires the periodic longitudinal domain
        # to run from 0 to 2*pi (inclusive). Since the periodic point is
        # "duplicated" in Fishpack, one additional cell is added
        self.poisson_solver.set_domain({"clt": clt}, {"lon": np.linspace(0.0, 2.0, self.Nlon + 1)*np.pi})

        #
        # Set boundary conditions
        #
        self.poisson_solver.boundary.clt.lower.type = "neumann"
        self.poisson_solver.boundary.clt.upper.type = "neumann"

        self.poisson_solver.boundary.clt.lower.data = np.zeros(len(self.poisson_solver.coordinates[1]))
        self.poisson_solver.boundary.clt.upper.data = np.zeros(len(self.poisson_solver.coordinates[1]))

        # Store geometry term for Eclt computation
        cltmesh, lonmesh = np.meshgrid(clt_indomain, self.indomain_lon_edges, indexing="ij")

        self.minus_one_over_R_sin_clt = -1.0/(self.R*np.sin(cltmesh[:, 1::]))

    def compute_electric_field(self, given_dBrdt):
        """Solves the poloidal potential and computes electric field components

        Args:
            given_dBrdt   :  Time-derivative of Br at the indomain boundary
                             cell face centers
        """

        #
        # Compute RHS
        #

        # Extend dBrdt to include periodic point as required by Fishpack
        dBrdt = np.zeros((self.Nclt + 2, self.Nlon + 1))
        dBrdt[:, 0:-1] = given_dBrdt[:, :]
        dBrdt[:, -1] = given_dBrdt[:, 0]

        self.poisson_solver.rhs = -(self.R**2)*dBrdt

        #
        # Solve Poisson problem
        #
        Pdot = self.poisson_solver.solve()

        # Compute derivatives of the poloidal potential
        dPdotdclt = (Pdot[1::, :] - Pdot[0:-1, :])/self.dclt
        dPdotdlon = (Pdot[:, 1::] - Pdot[:, 0:-1])/self.dlon

        #
        # Compute co-latitudinal electric field
        #
        Eclt = np.zeros((self.Nclt, self.Nlon + 1))
        Eclt[:, 1::] = self.minus_one_over_R_sin_clt*dPdotdlon[1:-1, :]

        # Periodicity
        Eclt[:, 0] = Eclt[:, -1]

        #
        # Compute longitudinal electric field
        #
        Elon = (1.0/self.R)*dPdotdclt[:, 0:-1]

        return Eclt, Elon
