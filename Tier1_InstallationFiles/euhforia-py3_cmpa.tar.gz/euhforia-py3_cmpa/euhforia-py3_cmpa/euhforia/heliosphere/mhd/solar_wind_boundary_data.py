# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Solar wind boundary data models.
"""

import datetime
import os

import numpy as np
import scipy.interpolate
import scipy.ndimage

import coco
import euhforia.core.constants as constants


class SingleSynopticSolarWindBoundaryModel(object):
    """Solar wind boundary data model using a single synoptic chart.

    This class implements the model that
    constructs a time-dependent solar wind boundary condition in the
    inertial frame by rotating rigidly a single synoptic chart of
    the solar wind parameters at a given radius. Note that due to this assumption,
    if the model is run for a sufficiently long period of time, the solution
    will repeat itself.

    Attributes:

        time_of_chart (datetime): Time of solar wind synoptic chart

    """

    def __init__(self, **kwargs):

        # rad/s
        self.rotation_rate = 2.66622373e-6

    def compute_interpolation_coordinates(self, clt, lon, t):
        """Computes the interpolation coordinates by mapping time
        to a rotation in longitude
        """

        # Create surface mesh
        colatmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")

        # Rotate map by angle
        rotation_angle = np.fmod(-self.rotation_rate*t, 2.0*np.pi)

        # Array of rotated coordinate tuples
        p = zip(lonmesh.flatten() + rotation_angle, colatmesh.flatten())

        return p, colatmesh.shape

    def vr(self, clt, lon, t):
        """Computes radial velocity on spherical surface using interpolation.

        Args:
            clt : Co-latitude grid points
            lon : Longitudinal grid points
            t   : Time in seconds from the time of the synoptic chart
        """

        # Get coordinates to use in interpolation
        crds, shape = self.compute_interpolation_coordinates(clt, lon, t)

        return np.reshape(self.interpolator["vr"](list(crds)).T, shape)

    def Br(self, clt, lon, t):
        """Computes radial magnetic field on spherical surface using interpolation.
        """

        # Get coordinates to use in interpolation
        crds, shape = self.compute_interpolation_coordinates(clt, lon, t)

        return np.reshape(self.interpolator["Br"](list(crds)).T, shape)

    def Bp(self, clt, lon, t):
        """Computes azimuthal magnetic field on spherical surface.
        """

        # Get coordinates to use in interpolation
        # crds, shape = self.compute_interpolation_coordinates(clt, lon, t)

        colatmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")

        Br = self.Br(clt, lon, t)
        vr = self.vr(clt, lon, t)

        return -(Br/vr)*np.sin(colatmesh)*self.rotation_rate*self.radius

    def number_density(self, clt, lon, t):
        """Computes number density on spherical surface using interpolation.
        """

        # Get coordinates to use in interpolation
        crds, shape = self.compute_interpolation_coordinates(clt, lon, t)
        # print(np.array(tuple(crds)).shape[-1])

        return np.reshape(self.interpolator["number_density"](list(crds)).T, shape)

    def temperature(self, clt, lon, t):
        """Computes temperature on spherical surface using interpolation.
        """

        # Get coordinates to use in interpolation
        crds, shape = self.compute_interpolation_coordinates(clt, lon, t)

        return np.reshape(self.interpolator["temperature"](list(crds)).T, shape)

    def load(self, file_name, **kwargs):
        """Loads a file containing a synoptic chart of solar wind parameters at a given time.
        """

        try:
            fp = open(file_name, "r")
        except IOError:
            raise IOError("Solar wind data file not found: " + os.path.abspath(file_name))

        #
        # Read time
        #
        title = fp.readline()
        time_str = fp.readline()

        self.time_of_chart = datetime.datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S\n")

        #
        # Read grid coordinates of input data.
        #

        # Radius
        title = fp.readline()
        radius = float(fp.readline())

        # Support for legacy format of radius
        if radius < 100.0:
            self.radius = radius * constants.solar_radius
        elif radius < 1.0:
            self.radius = radius * constants.astronomical_unit
        else:
            self.radius = radius

        # Colatitude grid points
        title = fp.readline()
        num_colat = int(fp.readline())
        title = fp.readline()

        self.colat = np.zeros(num_colat)
        for idx in range(num_colat):
            self.colat[idx] = float(fp.readline())

        # Longitudinal grid points
        title = fp.readline()
        num_lon = int(fp.readline())
        title = fp.readline()

        self.lon = np.zeros(num_lon)
        for idx in range(num_lon):
            self.lon[idx] = float(fp.readline())

        num_grid_points = (len(self.lon), len(self.colat))

        #
        # Read data variables
        #
        self.var = {}

        for var in range(4):
            name = fp.readline().rstrip()
            var = np.zeros(num_grid_points)
            for i in range(num_grid_points[0]):
                for j in range(num_grid_points[1]):  # (lon_0, colat_0), (lon_0, colat_1), etc
                    var[i, j] = float(fp.readline())

            #
            # Repeat in longitude to make sure interpolation operates
            # in a periodic way at longitudinal edges
            #
            self.var[name] = np.concatenate((var, var, var))

            #
            # Optional smoothing of data
            #
            if kwargs.get("smooth") is not None:
                self.var[name] = scipy.ndimage.gaussian_filter(self.var[name], kwargs.get("smooth"))

        #
        # Extend lon coordinates according to repetition in lon
        #
        self.lon = np.concatenate((-2.0*np.pi + self.lon, self.lon, 2.0*np.pi + self.lon))

        #
        # Create data interpolators
        #
        self.interpolator = {}

        for variable_name in self.var.keys():
            self.interpolator[variable_name] = scipy.interpolate.RegularGridInterpolator(
                (self.lon, self.colat), self.var[variable_name]
            )

        fp.close()

        self.initialized = True
