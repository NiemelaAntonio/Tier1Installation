# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module providing synoptic plotting support.
"""

import copy

import astropy.units as u
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from astropy.coordinates import frame_transform_graph
from astropy.wcs import WCS


def plot(magnetogram, **kwargs):
    """Plot synoptic magnetogram.

    Args:
        magnetogram : sunpy.map synoptic magnetogram

    Returns:
    """

    # Make a hardcopy of the map. This is needed due to tweaks to the map meta
    # that are required to produce a correct plot
    m = copy.deepcopy(magnetogram)

    # Scale data for plot
    if kwargs.get("scale", False):
        m.data *= kwargs.get("scale")

    # For synoptic plots, CRVAL for longitude needs to be corrected
    m.meta["CRVAL1"] += -360.0

    # Create a figure using the projection of the map
    fig = plt.figure(figsize=kwargs.get("figsize", (12, 5)))
    axes = plt.subplot(projection=m)

    # Plot the image
    im = m.plot()

    # Set coordinate axes types
    x = axes.coords[0]
    y = axes.coords[1]

    x.set_coord_type("longitude")  # , coord_wrap=360)
    y.set_coord_type("latitude")

    #
    # Adjust annotations
    #

    # Lables

    x_axis_label = "Longitude [deg]"

    if "CRLN" in m.meta["CTYPE1"].upper():
        x_axis_label = "Carrington " + x_axis_label
    if "HGLN" in m.meta["CTYPE1"].upper():
        x_axis_label = "Stonyhurst " + x_axis_label

    x.set_axislabel(x_axis_label)

    y_axis_label = "Latitude [deg]"

    y.set_axislabel(y_axis_label)

    # Ticks

    x.set_ticklabel(exclude_overlapping=True)
    x.set_ticks(number=11, color="black")
    y.set_ticklabel(exclude_overlapping=True)
    y.set_ticks(spacing=10*u.deg, color="black")

    #
    # Add colorbar
    #

    # Create a colorbar
    cb = plt.colorbar(im, fraction=0.019, pad=0.1)

    if m.meta.get("bunit", None) is not None:
        cb.set_label(m.meta["BUNIT"])

    return fig, axes
