#!/usr/bin/env python
#
# This file is part of EUHFORIA.
#
# Copyright 2016, 2017, 2018 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

import matplotlib
import matplotlib.patches
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np
import scipy.interpolate

import pyvista as pv

import coco.core.grid
import euhforia.core.constants as constants
import euhforia.plot.marker

w_S = 2.6*10**(-6)
R_S = 0.1

def where(array, value):
    for i in range(len(array)):
        if array[i] > value:
            return i
        
def lines(data_dir, date, d, **kwargs):
    
    num = 500
    input_dir = data_dir + "\\"
    cmap ='seismic'
    # Load file
    filename = input_dir + date + '.vts'
    mesh = pv.read(filename)
    # mesh = mesh.cell_data_to_point_data() # pas besoin

    # Convert to units
    mesh['x'] = mesh.points[:,0]*6.955e8 # m
    mesh['y'] = mesh.points[:,1]*6.955e8 # m
    mesh['z'] = mesh.points[:,2]*6.955e8 # m

    mesh['vr_dim'] = mesh['vr']*4.378e2 # km/s
    mesh['vtheta_dim'] = mesh['vclt']*4.378e2 # km/s
    mesh['vphi_dim'] = mesh['vlon']*4.378e2 # km/s

    mesh['br_dim'] = mesh['Br']*2.006 # G
    mesh['btheta_dim'] = mesh['Bclt']*2.006 # G
    mesh['bphi_dim'] = mesh['Blon']*2.006 # G

    # Convert to cartesian
    x = mesh['x']
    y = mesh['y']
    z = mesh['z']
    vr_dim = mesh['vr_dim']
    vtheta_dim = mesh['vtheta_dim']
    vphi_dim = mesh['vphi_dim']
    br_dim = mesh['br_dim']
    btheta_dim = mesh['btheta_dim']
    bphi_dim = mesh['bphi_dim']
    mesh['r'] = np.sqrt(x*x + y*y + z*z)
    r = mesh['r']
    mesh['rxy'] = np.sqrt(x*x + y*y) + 1.0e-20
    rxy = mesh['rxy']
    mesh['vx'] = x*vr_dim/r + x*z*vtheta_dim/(rxy*r) - y*vphi_dim/rxy
    mesh['vy'] = y*vr_dim/r + y*z*vtheta_dim/(rxy*r) + x*vphi_dim/rxy
    mesh['vz'] = z*vr_dim/r - rxy*vtheta_dim/r
    mesh['bx'] = x*br_dim/r + x*z*btheta_dim/(rxy*r) - y*bphi_dim/rxy
    mesh['by'] = y*br_dim/r + y*z*btheta_dim/(rxy*r) + x*bphi_dim/rxy
    mesh['bz'] = z*br_dim/r - rxy*btheta_dim/r

    # Create vector for magnetic field
    mesh['B'] = np.column_stack((mesh['bx'], mesh['by'], mesh['bz'])) # attention syntax
    mesh['v'] = np.column_stack((mesh['vx'], mesh['vy'], mesh['vz']))
    mesh.set_active_vectors('B')
    mesh.set_active_vectors('v')
    
    # sources
    heliospheric_objects = kwargs.get("heliospheric_objects", [])
    source = pv.PolyData()
    points = np.zeros((len(heliospheric_objects),3))
    i = 0
    
    for obj in heliospheric_objects:       
        r_obj, lat_obj, lon_obj = obj.position(d.datetime)
        x_obj = r_obj*np.cos(lat_obj)*np.cos(lon_obj)/constants.astronomical_unit
        y_obj = r_obj*np.cos(lat_obj)*np.sin(lon_obj)/constants.astronomical_unit
        z_obj = r_obj*np.sin(lat_obj)/constants.astronomical_unit
        
        points[i] = np.array([x_obj, y_obj, z_obj])
        source = pv.PolyData(points)
        
        i += 1

    streamlines_b = mesh.streamlines_from_source(source,vectors='B',max_time=500.,initial_step_length=0.01,integration_direction='backward')
    streamlines_f = mesh.streamlines_from_source(source,vectors='B',max_time=500.,initial_step_length=0.01,integration_direction='forward')

    # create lines
    fig_e = []
    fig_m = []

    for i in range(streamlines_b.n_cells):

        line_b = streamlines_b.cell_points(i)
        line_f = streamlines_f.cell_points(i)
        
        px_f = np.flip(line_f[:,0])
        py_f = np.flip(line_f[:,1])
        pz_f = np.flip(line_f[:,2])
        
        px_b = line_b[:,0]
        py_b = line_b[:,1]
        pz_b = line_b[:,2]
        
        px = np.zeros((len(px_b)+len(px_f)))
        py = np.zeros((len(py_b)+len(py_f)))
        pz = np.zeros((len(pz_b)+len(pz_f)))
        
        px[0:len(px_f)], px[len(px_f):] = px_f, px_b
        py[0:len(py_f)], py[len(py_f):] = py_f, py_b
        pz[0:len(pz_f)], pz[len(pz_f):] = pz_f, pz_b
        
        fig_e.append([px,py])
        fig_m.append([px,pz])

    return fig_e, fig_m
    