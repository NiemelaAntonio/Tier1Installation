"""Module for analyzing field lines.
"""

import numpy as np
import scipy.constants as constants
import euhforia.plot.interpolation as interpolation
import euhforia.plot.tracer as tracer


class EmptyContainer(object):
    pass

class FieldLineAnalyzer(object):
    """Traces and computes various quantities along field lines
    """
    def __init__(self):

        # Adiabatic index used in computations. By default, EUHFORIA uses 1.5
        self.adiabatic_index = 1.5

    def initialize(self, data):

        self.interpolator = EmptyContainer()

        #
        # Setup interpolator for the staggered magnetic field
        #
        self.interpolator.magnetic_field = interpolation.MagneticFieldInterpolator()
        self.interpolator.magnetic_field.set_grid_data(data.grid.edge_coords.r/constants.astronomical_unit,
                                                       data.grid.edge_coords.clt,
                                                       data.grid.edge_coords.lon,
                                                       data.Br, data.Bclt, data.Blon)

        # Magnetic field line tracer
        self.tracer = tracer.MidPointStreamLineTracer()
        self.tracer.set_domain_extent(data.grid.indomain_edge_coords.r/constants.astronomical_unit,
                                      data.grid.indomain_edge_coords.clt,
                                      data.grid.indomain_edge_coords.lon)

        #
        # Interpolators for cell-centered scalar quantities
        #

        if "n" in data.data.keys():
            self.interpolator.rho    = self.cell_centered_interpolator("n",   data, scale_by=0.5*constants.proton_mass)
        if "P" in data.data.keys():
            self.interpolator.P      = self.cell_centered_interpolator("P",   data)
        if "vr" in data.data.keys():
            self.interpolator.vr     = self.cell_centered_interpolator("vr",  data)
        if "vlon" in data.data.keys():
            self.interpolator.vclt   = self.cell_centered_interpolator("vclt",data)
        if "vclt" in data.data.keys():
            self.interpolator.vlon   = self.cell_centered_interpolator("vlon",data)

    def cell_centered_interpolator(self, variable, data, scale_by=1.0):
        """Initialize a cell centered interpolator
        """
        q = interpolation.CellCenteredScalarInterpolator()

        q.set_grid_data(data.grid.center_coords.r/constants.astronomical_unit,
                        data.grid.center_coords.clt,
                        data.grid.center_coords.lon,
                        data.data[variable]*scale_by)
        return q

    def trace(self, start_pt):
        """trace field line from start_pt in both directions 
        """
        start_pt     = np.asarray(start_pt, dtype=np.double)
        start_pt[1] *= np.pi/180.; start_pt[2] *= np.pi/180. 
        points0  = self.tracer.compute(start_pt, self.interpolator.magnetic_field,-1)
        points1  = self.tracer.compute(start_pt, self.interpolator.magnetic_field, 1)
        
        assert (len(points0) > 0  or len(points1) > 0 ), "no fieldline"

        if len(points0) > 0 and points0[-1][0] > start_pt[0]:
            self.coordinates = np.asarray(points0[::-1] + points1[1:])
        else:
            self.coordinates = np.asarray(points1[::-1] + points0[1:])
    @property
    def rho(self):
        """Compute mass density along a field line
        """
        return self.interpolator.rho.values_at(self.coordinates)

    @property
    def P(self):
        """Compute the thermal pressure along a field line
        """
        return self.interpolator.P.values_at(self.coordinates)

    @property
    def vr(self):
        """Compute the radial velocity along a field line
        """
        return self.interpolator.vr.values_at(self.coordinates)

    @property
    def vclt(self):
        """Compute the co-latitudinal velocity along a field line
        """
        return self.interpolator.vclt.values_at(self.coordinates)

    @property
    def vlon(self):
        """Compute the longitudinal velocity along a field line
        """
        return self.interpolator.vlon.values_at(self.coordinates)

    @property
    def Br(self):
        """Compute the radial magnetic field along a field line
        """
        return self.interpolator.magnetic_field.Br_at(self.coordinates)

    @property
    def Bclt(self):
        """Compute the co-latitudinal magnetic field along a field line
        """
        return self.interpolator.magnetic_field.Bt_at(self.coordinates)

    @property
    def Blon(self):
        """Compute the longitudinal magnetic field along a field line
        """
        return self.interpolator.magnetic_field.Bp_at(self.coordinates)

    @property
    def entropy(self):
        """Computes the entropy S = P \rho^-\gamma along a field line
        """
        return self.P*self.rho**(-self.adiabatic_index)

    @property
    def entropy_density(self):
        """Computes the entropy density S \rho along a field line
        """
        return self.P*self.rho**(1.0 - self.adiabatic_index)

    @property
    def path_length(self):
        """Compute the path length along the field line
        """

        def to_cart(crd):

            r, t, p = crd
            return np.array((r*np.sin(t)*np.cos(p), r*np.sin(t)*np.sin(p), r*np.cos(t)))

        s = np.zeros(len(self.coordinates))

        for idx in range(len(self.coordinates)-1):

            # Compute distance between consecutive points
            pA = to_cart(self.coordinates[idx])
            pB = to_cart(self.coordinates[idx+1])
            ds = np.linalg.norm(pA-pB)

            # Add up distances
            s[idx+1] = s[idx] + ds

        return s

    @property
    def get_coordinates(self):
        """Returns the Cartesian coordinates of the field line
        """
        r, th, ph = self.coordinates.T

        crds = EmptyContainer()

        crds.r   = r
        crds.clt = th
        crds.lon = ph

        crds.x = r*np.sin(th)*np.cos(ph)
        crds.y = r*np.sin(th)*np.sin(ph)
        crds.z = r*np.cos(th)

        return crds
        
