#!/usr/bin/env python
#
# This file is part of EUHFORIA.
#
# Copyright 2016, 2017, 2018 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

import matplotlib
import matplotlib.patches
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np
import scipy.interpolate

import coco.core.grid
import euhforia.core.constants as constants
import euhforia.plot.marker

w_S = 2.6*10**(-6)
R_S = 0.1

def where(array, value):
    for i in range(len(array)):
        if array[i] > value:
            return i
        
def lines(d, **kwargs):
    
    print('entrer')
    variable = 'vr'
    
    element_type = coco.core.grid.get_element_type(d.grid, d.data[variable])
    interpolator = scipy.interpolate.RegularGridInterpolator(
        d.grid.get_coordinates(element_type), d.data[variable], method="linear"
    )
    
    r = kwargs.get("radial_coordinates", np.linspace(0.1, 2.0, 256)*constants.astronomical_unit)
    r = np.unique(np.clip(r, d.grid.indomain_edge_coords.r[0], d.grid.indomain_edge_coords.r[-1]))
    
    
    clt = 0.5*np.pi

    lon = d.grid.indomain_edge_coords.lon   # lon :angle de -pi a pi
                                            # r : longeur de 0.1 à 2
            

    
    # Array of points for RegularGridInterpolator
    interpolation_coordinates = np.vstack(np.meshgrid(r, clt, lon, indexing="ij")).reshape(3, -1).T # céation du cercle

    # Interpolate
    interpolated_data = interpolator(interpolation_coordinates).reshape((len(r), len(lon)))
    heliospheric_objects = kwargs.get("heliospheric_objects", [])
    
    fig_e = []
    fig_m = []
    
    
    for obj in heliospheric_objects:
        
        r_obj, lat_obj, lon_obj = obj.position(d.datetime) # extraire les coordonnée dans interpolated data
        v_sw = interpolated_data[where(r,r_obj), where(lon, lon_obj)] # ->v
        phi_r = lon_obj # ->phi_0
        
        #  création des lignes de champs
        r_line = r/constants.astronomical_unit
        r_obj = r_obj/constants.astronomical_unit
        v_sw = v_sw*10**(3)/constants.astronomical_unit
        
        phi_line = [ -w_S*(r_line[j]-(r_obj))/v_sw + phi_r for j in range(len(r)) ]
        
        # equatorial plane     
        fig_e.append([r_line*np.cos(phi_line), r_line*np.sin(phi_line)])
        
        # meridional plane
        fig_m.append([r_line*np.cos(phi_line)*np.cos(lat_obj), r_line*np.sin(lat_obj)])
        
        
    return fig_e, fig_m
      
      
        