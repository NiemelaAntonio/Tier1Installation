#!/usr/bin/env python
#
# This file is part of EUHFORIA.
#
# Copyright 2016, 2017, 2018 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

import numpy as np
import matplotlib.pyplot as plt

import coco.core.grid
import euhforia.core.constants as constants
import euhforia.plot.marker
import euhforia.plot.field_line_analyzer as field_line_analyzer

def lines(data_dir, date, d, **kwargs):
    
    field_line = field_line_analyzer.FieldLineAnalyzer()
    field_line.initialize(d)
    
    fig_e = []
    fig_m = []
    
    # sources
    heliospheric_objects = kwargs.get("heliospheric_objects", [])
   
    for obj in heliospheric_objects:       
        r_obj, lat_obj, lon_obj = obj.position(d.datetime)
        
        r_obj = r_obj = r_obj/constants.astronomical_unit
        colatitude = (np.pi/2-lat_obj)*180/np.pi
        lon = lon_obj*180/np.pi
        point = (r_obj, colatitude, lon)
        
        field_line.trace(point) 
        
        fig_e.append([field_line.get_coordinates.x, field_line.get_coordinates.y])
        fig_m.append([field_line.get_coordinates.x, field_line.get_coordinates.z])
    
    return fig_e, fig_m