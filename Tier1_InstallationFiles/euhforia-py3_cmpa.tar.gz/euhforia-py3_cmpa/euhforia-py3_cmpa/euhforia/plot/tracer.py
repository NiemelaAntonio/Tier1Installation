"""Module for tracing stream lines.
"""

import numpy as np
import numba
from numba.experimental import jitclass

spec = [("max_path_length", numba.float64),
        ("step_size_relative_to_mesh_spacing", numba.float64),
        ("follow_field_direction", numba.boolean),
        ("min_step_size", numba.float64),
        ("xmin", numba.float64),
        ("xmax", numba.float64),
        ("ymin", numba.float64),
        ("ymax", numba.float64),
        ("zmin", numba.float64),
        ("zmax", numba.float64)]


@jitclass(spec)
class MidPointStreamLineTracer(object):
    """Stream line tracer.

    Traces stream lines given a vector field defined on a grid. The integration
    is performed using a second-order midpoint scheme.

    Attributes:
        max_path_length (float)        : Maximum path length after which tracing is stopped
        min_step_size (float)          : Limit the minimum allowable step size
        step_size_relative_to_mesh_spacing (float)  : Length of step relative to the local grid size
    """

    def __init__(self):

        self.max_path_length = 0.0

        self.step_size_relative_to_mesh_spacing = 0.1

        self.min_step_size = 0.0

    def set_domain_extent(self, xdomain, ydomain, zdomain):
        """Set the size of the domain.
        """

        self.xmin = xdomain[1];  self.xmax = xdomain[-2];
        self.ymin = ydomain[1];  self.ymax = ydomain[-2];
        self.zmin = zdomain[1];  self.zmax = zdomain[-2];
        # Provide the max path length with a reasonable value if it has
        # not been set
        if self.max_path_length == 0.0:
            self.max_path_length = 3 * (self.xmax-self.xmin)

    def is_inside_domain(self, pt):
        """Checks if the given point is inside the domain.
        """
        x, y, z = pt

        is_inside = False
        if (x > self.xmin) and (x < self.xmax) and (y > self.ymin) and (y < self.ymax):
            is_inside = True

        return is_inside

    def wrap_z(self,lon):

        return lon  - 2 * np.pi * np.floor( (lon - self.zmin)/(2*np.pi))

    def compute(self, start_pt, magnetic_field_interpolator,direction):
        """Computes the stream line

        Args:
            start_point (array) : Coordinates of the starting point
            interpolator        : Interpolator class

        Returns:
            Array of coordinates of the points of the field line
        """

        # List of coordinates of the field line
        points = []


        # Starting point
        x = start_pt
        points.append(x)

        scale_step_size = self.step_size_relative_to_mesh_spacing*direction

        path_length = 0
        ds = 0.0
        while path_length < self.max_path_length:

            # Get cell size
            cell_size = magnetic_field_interpolator.cell_length_at(x[0], x[1], x[2])

            # Determine step size
            ds = max(np.min(cell_size), self.min_step_size)*scale_step_size

            # Move half step
            xhalf = x + 0.5*ds*magnetic_field_interpolator.displacement_vector(x[0], x[1], x[2])
            xhalf[2] = self.wrap_z(xhalf[2])

            # Outside domain?
            if not self.is_inside_domain(xhalf):
                break

            # Move full step using the field at the half step
            xnext = x + ds*magnetic_field_interpolator.displacement_vector(xhalf[0], xhalf[1], xhalf[2])
            xnext[2] = self.wrap_z(xnext[2])

            # Return half point is the next point is outside the domain
            if not self.is_inside_domain(xnext):
                x = xhalf
                break

            # Update path length   
            path_length+=np.abs(ds)

            # Update point
            x = xnext
            points.append(x)

        return points
