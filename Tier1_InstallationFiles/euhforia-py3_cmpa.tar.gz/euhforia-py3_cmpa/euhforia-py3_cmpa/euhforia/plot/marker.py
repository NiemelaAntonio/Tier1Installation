# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""EUHFORIA marker style definitions
"""

#
# Defines plot marker styles for heliospheric objects
#

style = {
    "Mercury": {"Marker": "o", "color": (254.0/255.0, 240.0/255.0, 196.0/255.0)},
    "Venus": {"Marker": "o", "color": (213.0/255.0, 144.0/255.0, 47.0/255.0)},
    "Earth": {"Marker": "o", "color": (0.0/255.0, 117.0/255.0, 195.0/255.0)},
    "Mars": {"Marker": "o", "color": (201.0/255.0, 34.0/255.0, 31.0/255.0)},
    "Jupiter": {"Marker": "o", "color": (231.0/255.0, 196.0/255.0, 195.0/255.0)},
    "Saturn": {"Marker": "o", "color": (200.0/255.0, 164.0/255.0, 100.0/255.0)},
    "Uranus": {"Marker": "o", "color": (199.0/255.0, 240.0/255.0, 243.0/255.0)},
    "Neptune": {"Marker": "o", "color": (57.0/255.0, 68.0/255.0, 216.0/255.0)},
    "Pluto": {"Marker": "o", "color": (231.0/255.0, 221.0/255.0, 210.0/255.0)},
    "STA": {"Marker": "s", "color": "r"},
    "STB": {"Marker": "s", "color": "b"},
}
