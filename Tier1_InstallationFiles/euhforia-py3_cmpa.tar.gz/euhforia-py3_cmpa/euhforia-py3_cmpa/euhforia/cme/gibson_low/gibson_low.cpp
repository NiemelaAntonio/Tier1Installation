/**
 *
 * This file is part of EUHFORIA.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * EUHFORIA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * EUHFORIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.
 *
 */


#define USE_XTENSORPYTHON_ARRAY

#include "coco/core/coco.hpp"
#include <pybind11/eigen.h>

#include "gibson_low.hpp"


PYBIND11_PLUGIN(gibson_low)
{
  namespace py = pybind11;

  py::module m("gibson_low", "Kernel for ideal MHD solver");

  py::class_<euhforia::GibsonLowParameters>(m, "GibsonLowParameters")
    .def(py::init<>())
    .def_readwrite("x0",     &euhforia::GibsonLowParameters::x0)
    .def_readwrite("a",      &euhforia::GibsonLowParameters::a)
    .def_readwrite("H",      &euhforia::GibsonLowParameters::H)
    .def_readwrite("a0",     &euhforia::GibsonLowParameters::a0)
    .def_readwrite("a1",     &euhforia::GibsonLowParameters::a1)
    .def_readwrite("r0",     &euhforia::GibsonLowParameters::r0)
    .def_readwrite("r1",     &euhforia::GibsonLowParameters::r1)
    .def_readwrite("phi_ss", &euhforia::GibsonLowParameters::phi_ss)
    .def_readwrite("core_rotation",  &euhforia::GibsonLowParameters::core_rotation_angle)
  ;


  py::class_<euhforia::GibsonLowMagneticField>(m, "GibsonLowModel")
    .def(py::init<>())
    .def("initialize", &euhforia::GibsonLowMagneticField::initialize)
    .def("is_inside", &euhforia::GibsonLowMagneticField::is_inside)
    .def("magnetic_field", &euhforia::GibsonLowMagneticField::magnetic_field)
    .def_readwrite("parameters", &euhforia::GibsonLowMagneticField::params)
  ;

  return m.ptr();

}
