/**
 *
 * This file is part of EUHFORIA.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * EUHFORIA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * EUHFORIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

/**
 * \brief Gibson & Low (1998) flux rope CME model
 *
 */

#include <Eigen/Core>
#include <Eigen/Geometry>

#include "coco/core/constants.hpp"
#include "coco/core/functions.hpp"
#include "coco/geometry/transforms.hpp"


namespace euhforia {


/*!
 * \brief Class storing the parameters of the Gibson & Low model.
 *
 */
struct GibsonLowParameters
{
  double x0;                  // Displacement of spheromak system
  double core_rotation_angle; // Rotation angle of the spheromak system

  double a;
  double H;

  double a0; // in Eq. B8, B9
  double a1; // in Eq. B7
  double r0; // in Eq. B9 : radius of flux surface

  double r1; // in Eq. B3, B4

  double phi_ss;
};



/*!
 * \brief Class for computing the external magnetic field configuration of the
 *        Gibson & Low model. See Appendix B1.
 *
 */
class GibsonLowExternalMagneticField
{
public:

  GibsonLowParameters param;

public:


  /*!
   * \brief Computes the magnetic field outside the bubble, Appendix B1 in G&L
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates in the centered coordinates
   *
   * \returns    Eigen::Vector3d containing the spherical
   *             (Br, Bclt, Blon) components of the magnetic field in the
   *             centered system
   */
  auto magnetic_field(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    auto B   = Eigen::Vector3d(dAdth(r, th)/r, -dAdr(r, th), 0.0);
    B       *= 1.0/(r*sin(th));

    return B;
  }


  double stream_function(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    return A(r, th);
  }

private:


  /*!
   * \brief Computes the stream function A, Eq. B5
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of the stream function
   */
  double A(const double r, const double th) const
  {
    const auto mu = cos(th);

    return psi0(mu) + psi1(r, mu) + psi2(r, mu);
  }


  /*!
   * \brief Computes the derivative of the stream function wrt r.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of dA/dr at p
    */
  double dAdr(const double r, const double th) const
  {
    // NOTE: MAGIC NUMBER
    const auto dr = 1e-6*param.r0;

    return (A(r+dr, th) - A(r-dr, th))/(2.0*dr);
  }


  /*!
   * \brief Computes the derivative of the stream function wrt colatitude.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of dA/dth at p
    */
  double dAdth(const double r, const double th) const
  {
    // NOTE: MAGIC NUMBER!!
    const auto dth = 1e-6;

    return (A(r, th+dth) - A(r, th-dth))/(2.0*dth);
  }


  /*!
   * \brief Compute the g function, Eq. B8
   *
   * \param[in]  x
   *
   * \returns    g(x)
   */
  double psi0(const double mu) const
  {
    return mu;
  }


  /*!
   * \brief Compute the g function, Eq. B8
   *
   * \param[in]  x
   *
   * \returns    g(x)
   */
  double psi1(const double r, const double mu) const
  {
    using namespace coco::functions;

    const double numerator
      = param.r1*(sqr(r)+sqr(param.r1)-sqr(param.r0)) + r*mu*(sqr(param.r0)-2.0*sqr(param.r1));

    const double denominator
      = sqr(sqr(param.r0)-sqr(param.r1))+sqr(r)*sqr(param.r1)+2.0*mu*r*param.r1*(sqr(param.r0)-sqr(param.r1));

    return -numerator/(param.r0*sqrt(denominator));
  }


  /*!
   * \brief Compute the g function, Eq. B8
   *
   * \param[in]  x
   *
   * \returns    g(x)
   */
  double psi2(const double r, const double mu) const
  {
    using namespace coco::functions;

    return sqrt(sqr(r)+sqr(param.r1)-2.0*r*param.r1*mu)/param.r0;
  }

};


/*!
 * \brief Class for computing the internal magnetic field configuration of the
 *        Gibson & Low model. See Appendix B2.
 *
 */
class GibsonLowInternalMagneticField
{
public:

  GibsonLowParameters param;

public:

  /*!
   * \brief Computes the magnetic field inside the bubble, Appendix B2 in G&L
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates in the centered coordinates
   *
   * \returns    Eigen::Vector3d containing the spherical
   *             (Br, Bclt, Blon) components of the magnetic field in the
   *             centered system
   */
  auto magnetic_field(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    auto B   = Eigen::Vector3d(dAdth(p)/r, -dAdr(p), param.H*param.a0*A(p));
    B       *= 1.0/(r*sin(th));

    return B;
  }


  auto stream_function(const Eigen::Vector3d & p) const
  {
    return A(p);
  }

private:

  /*!
   * \brief Computes the stream function A(r, th), Eq. B7
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of the stream function
   */
  double A(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    const auto pi = coco::constants::math::pi;

    double stream_fn = -r*r + param.r0*param.r0*g(param.a0*r)/g(param.a0*param.r0);
    stream_fn       *= 4.0*pi*param.a1*sin(th)*sin(th)/(param.a0*param.a0);

    return stream_fn;
  }


  /*!
   * \brief Computes the derivative of the stream function wrt r.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of dA/dr at p
    */
  double dAdr(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    const auto pi = coco::constants::math::pi;

    const auto dgdr   = param.a0*dgdx(param.a0*r);

    double derivative = - 2.0*r + param.r0*param.r0*dgdr/g(param.a0*param.r0);
    derivative       *= 4.0*pi*param.a1*sin(th)*sin(th)/(param.a0*param.a0);

    return derivative;
  }


  /*!
   * \brief Computes the derivative of the stream function wrt colatitude.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of dA/dth at p
    */
  double dAdth(const Eigen::Vector3d & p) const
  {
    const auto th = p[1];

    return 2.0*cos(th)*A(p)/sin(th);
  }


  /*!
   * \brief Compute the g function, Eq. B8
   *
   * \param[in]  x
   *
   * \returns    g(x)
   */
  double g(const double x) const
  {
    return -cos(x) + sin(x)/x;
  }


  /*!
   * \brief Compute the derivative of g wrt x.
   *
   * \param[in]  x
   *
   * \returns    Value of dg/dx at x
   */
  double dgdx(const double x) const
  {
    return (1.0 - 1.0/(x*x))*sin(x) + cos(x)/x;
  }

};



/*!
 * \brief Class for computing the magnetic field configuration of the
 *        Gibson & Low model.
 *
 */
class GibsonLowMagneticField
{
public:

  GibsonLowParameters params;

  GibsonLowInternalMagneticField internal;
  GibsonLowExternalMagneticField external;

  double stream_function;

public:

  void initialize()
  {
    internal.param = params;
    external.param = params;
  }


  /*!
   * \brief Determines whether the given point is inside the CME.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    bool
   */
  auto is_inside(const Eigen::Vector3d & p)
  {

    // Coordinate in stretched system
    const auto p_stretched
      = Eigen::Vector3d(p[0]+params.a, p[1], p[2]);

    // Translation transform
    const auto translate
      = Eigen::Translation3d(Eigen::Vector3d(-params.x0, 0, 0));

    // Rotation transform
    const auto rotate  = Eigen::AngleAxisd(params.core_rotation_angle,
                                           Eigen::Vector3d(1, 0, 0));

    // Coordinate p in the local internal Cartesian basis
    const auto p_local_internal_cart
      = translate*rotate*coco::geometry::transform::spherical::to_cartesian_coordinates(p_stretched);

    // Coordinate p in the local internal spherical basis
    const auto p_local_internal_sph
      = coco::geometry::transform::cartesian::to_spherical_coordinates(p_local_internal_cart);

    // Is p inside the CME?
    bool is_in = true;

    if (p_local_internal_sph[0] > params.r0) {
      is_in = false;
    }

    return is_in;
  }


  /*!
   * \brief Computes the global magnetic field configuration described in appendix B.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Eigen::Vector3d containing the spherical
   *             (Br, Bclt, Blon) components of b.
   */
  auto b(const Eigen::Vector3d & p)
  {

    //
    // Compute coordinate transformations for internal field.
    //
    // The internal field is defined in a local coordinate system with
    // the origin located at (params.x0,0,0). The axes are rotated an angle
    // params.core_rotation_angle about the x-axis.
    //

    // Translation transform
    const auto translate = Eigen::Translation3d(Eigen::Vector3d(-params.x0, 0, 0));

    // Rotation transform
    const auto rotate  = Eigen::AngleAxisd(params.core_rotation_angle,
                                           Eigen::Vector3d(1, 0, 0));

    // Coordinate p in the local internal Cartesian basis
    const auto p_local_internal_cart
      = translate*rotate*coco::geometry::transform::spherical::to_cartesian_coordinates(p);

    // Coordinate p in the local internal spherical basis
    const auto p_local_internal_sph
      = coco::geometry::transform::cartesian::to_spherical_coordinates(p_local_internal_cart);

    //
    // Compute coordinate transformations for external field.
    //
    // The external field is defined in a local coordinate system with
    // the z-axis passing through the FR center. Thus, a rotation is
    // needed to get to coincide with the x-axis.
    //

    // Rotation transform for external field
    const auto rotate_external
      = Eigen::AngleAxisd(-0.5*coco::constants::math::pi,
                          Eigen::Vector3d(0,1,0));

    // Coordinate p in the local external Cartesian basis
    const auto p_local_external_cart
      = rotate_external*coco::geometry::transform::spherical::to_cartesian_coordinates(p);

    // Coordinate p in the local internal spherical basis
    const auto p_local_external_sph
      = coco::geometry::transform::cartesian::to_spherical_coordinates(p_local_external_cart);

    //
    // Compute magnetic field
    //

    Eigen::Vector3d bglobal(0.0, 0.0, 0.0);

    if (p_local_internal_sph[0] > params.r0) {

#if 0 // External field disabled. TODO: make a better switch, e.g. introduce strength parameter of external field
      // External magnetic field in local spherical basis
      const auto bext_sph
        = external.magnetic_field(p_local_external_sph);

      // External magnetic field in local Cartesian basis
      const auto bext_cart
        = coco::geometry::transform::spherical::to_cartesian_vector(bext_sph, p_local_external_sph, false);

      // Transform to global Cartesian basis
      bglobal = rotate_external.inverse()*bext_cart;

      stream_function = external.stream_function(p_local_external_sph)-1.0;
#endif

    } else {

      // Internal magnetic field in local spherical basis
      const auto bint_sph
        = internal.magnetic_field(p_local_internal_sph);

      // Internal magnetic field in local Cartesian basis
      const auto bint_cart
        = coco::geometry::transform::spherical::to_cartesian_vector(bint_sph, p_local_internal_sph, false);

      // Transform to global Cartesian basis
      bglobal = rotate.inverse()*bint_cart;

      stream_function = internal.stream_function(p_local_internal_sph);
    }

    return coco::geometry::transform::cartesian::to_spherical_vector(bglobal, p, false);
  }


  auto magnetic_field(const Eigen::Vector3d & p)
  {

    //
    // Stretching transformation, Lambda = r + a
    //
    const double r            = p[0]/params.phi_ss;
    const double Lambda       = r + params.a;
    const double Lambda_per_r = Lambda/r;
    const double dLambda_dr   = 1.0;
    const double phi_ss_sqr   = params.phi_ss*params.phi_ss;

    // Coordinate in stretched system
    const auto p_stretched = Eigen::Vector3d(Lambda, p[1], p[2]);

    // Compute magnetic field in stretched system
    const auto bl          = b(p_stretched);

    return Eigen::Vector3d(bl[0]*Lambda_per_r*Lambda_per_r/phi_ss_sqr,
                           bl[1]*Lambda_per_r*dLambda_dr/phi_ss_sqr,
                           bl[2]*Lambda_per_r*dLambda_dr/phi_ss_sqr);

  }

};

}
