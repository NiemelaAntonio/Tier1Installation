# This file is part of EUHFORIA.
#
# Copyright 2019 Alexey Isavnin
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

import calendar
import datetime

import coco.core.constants as constants
import numpy as np
import pandas as pd
from ai.fri3d.model import DynamicFRi3D


class FRi3DModel(object):
    """FRi3D CME model.

    Attributes:
        params.lat        :  Latitude of the eruption, HEEQ rad
        params.lon        :  Longitued of the eruption, HEEQ rad
        params.speed      :  Speed of the CME, m/s
        params.half_width :  Half width of the cone, rad
        params.start_time :  Time at which the cone intersects the r=0.1 AU sphere
    """

    def __init__(
        self,
        start_time,
        latitude,
        longitude,
        toroidal_speed,
        toroidal_height,
        half_width,
        half_height,
        tilt,
        flattening,
        pancaking,
        twist,
        polarity,
        chirality,
        flux,
        mass_density,
        temperature,
        skew,
        solar_wind_boundary,
    ):

        self._t = 0
        self._clt = ()
        self._lon = ()
        self._idx = ()
        self._br = 0
        self._bt = 0
        self._bp = 0
        self._vr = 0
        self.solar_wind_boundary = solar_wind_boundary
        self.disconnected = False

        class Parameters(object):
            pass

        self.params = Parameters()
        self.params.start_time = start_time.to_pydatetime() if isinstance(start_time, pd.Timestamp) else start_time

        self.params.latitude = float(latitude) * np.pi / 180.0
        self.params.colatitude = -self.params.latitude + 0.5 * np.pi
        self.params.longitude = float(longitude) * np.pi / 180.0
        self.params.toroidal_height = float(toroidal_height) * constants.solar_radius
        self.params.toroidal_speed = float(toroidal_speed) * 1e3
        self.params.half_width = float(half_width) * np.pi / 180.0
        self.params.half_height = float(half_height) * np.pi / 180.0
        self.params.tilt = float(tilt) * np.pi / 180.0
        self.params.flattening = float(flattening)
        self.params.pancaking = float(pancaking)
        self.params.skew = float(skew) * np.pi / 180.0
        self.params.twist = float(twist)
        self.params.flux = float(flux)
        self.params.polarity = float(polarity)
        self.params.chirality = float(chirality)

        self.params.mass_density = float(mass_density)
        self.params.temperature = float(temperature)

        self._dfr = DynamicFRi3D(
            latitude=lambda t: self.params.latitude,
            longitude=lambda t: self.params.longitude,
            toroidal_height=lambda t: (t - calendar.timegm(self.params.start_time.timetuple()))
            * self.params.toroidal_speed
            + self.params.toroidal_height,
            half_width=lambda t: self.params.half_width,
            half_height=lambda t: self.params.half_height,
            tilt=lambda t: self.params.tilt,
            flattening=lambda t: self.params.flattening,
            pancaking=lambda t: self.params.pancaking,
            skew=lambda t: self.params.skew,
            twist=lambda t: self.params.twist,
            flux=lambda t: self.params.flux,
            sigma=lambda t: 2,
            polarity=lambda t: self.params.polarity,
            chirality=lambda t: self.params.chirality,
        )

    def mask(self, clt, lon, t):
        """Determines indices of grid points on the boundary sphere where the
        CME is inserted
        """
        tt = calendar.timegm(t.timetuple())
        toroidal_height = self._dfr.toroidal_height(tt)
        
        disconnect_at = 1.0*1.496e11 #1.0 AU in meters

        if (toroidal_height > disconnect_at):
           self.disconnected = True
          
        if self.disconnected:
            self._idx = () #return () # empty self._idx must be returned
            return self._idx


        if (t != self._t or np.any(clt != self._clt) or np.any(lon != self._lon)) and toroidal_height > 0 and self.disconnected==False:
            self._t = t
            self._clt = clt
            self._lon = lon
            sfr = self._dfr.snapshot(tt)

            # Construct grid of coordinates
            r = constants.astronomical_unit * 0.1
            cltmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")
            x = r * np.sin(cltmesh) * np.cos(lonmesh)
            y = r * np.sin(cltmesh) * np.sin(lonmesh)
            z = r * np.cos(cltmesh)
            b, c = sfr.data(x.ravel(), y.ravel(), z.ravel())

            self._br = (
                b[:, 0] * np.sin(cltmesh.ravel()) * np.cos(lonmesh.ravel())
                + b[:, 1] * np.sin(cltmesh.ravel()) * np.sin(lonmesh.ravel())
                + b[:, 2] * np.cos(cltmesh.ravel())
            )
            self._bt = (
                b[:, 0] * np.cos(cltmesh.ravel()) * np.cos(lonmesh.ravel())
                + b[:, 1] * np.cos(cltmesh.ravel()) * np.sin(lonmesh.ravel())
                - b[:, 2] * np.sin(cltmesh.ravel())
            )
            self._bp = -b[:, 0] * np.sin(lonmesh.ravel()) + b[:, 1] * np.cos(lonmesh.ravel())
            self._vr = c[:, 0] * (self._dfr.toroidal_height(tt) - self._dfr.toroidal_height(tt - 1))
            self._md = c[:, 0]*self.params.mass_density/c[:,0]

            # Compute array indices where to insert values
            self._idx = np.where(np.isfinite(b[:, 0]))[0]
            if self._idx.size == 0:
                self._vr = 0
                self._br = 0
                self._bt = 0
                self._bp = 0
                self._md = 0
                self._idx = ()
            else:
                self._br = self._br[self._idx]
                self._bt = self._bt[self._idx]
                self._bp = self._bp[self._idx]
                self._vr = self._vr[self._idx]
                self._md = self._md[self._idx]
                #cidx = self.solar_wind_boundary.vr(clt, lon, tt).ravel()[self._idx] > self._vr
                #self._vr[cidx] = self.solar_wind_boundary.vr(clt, lon, tt).ravel()[self._idx][cidx]
                #self._br[cidx] = self.solar_wind_boundary.Br(clt, lon, tt).ravel()[self._idx][cidx]
                #self._bp[cidx] = self.solar_wind_boundary.Bp(clt, lon, tt).ravel()[self._idx][cidx]

        return self._idx

    def mass_density(self, clt, lon, t):
        """Computes CME mass density
        """
        return (
            self.mask(clt, lon, t),
            self._md
            # *self.params.poloidal_height
            # /self._dfr.poloidal_height(calendar.timegm(t.timetuple()))
        )

    def temperature(self, clt, lon, t):
        """Computes CME temperature
        """
        return self.mask(clt, lon, t), self.params.temperature

    def vr(self, clt, lon, t):
        """Computes CME radial speed
        """
        return self.mask(clt, lon, t), self._vr

    def vt(self, clt, lon, t):
        """Computes CME colatitudinal speed
        """
        return (), 0.0

    def vp(self, clt, lon, t):
        """Computes CME longitudinal speed
        """
        return (), 0.0

    def Br(self, clt, lon, t):
        """Computes CME radial magnetic field
        """
        return self.mask(clt, lon, t), self._br

    def Bt(self, clt, lon, t):
        """Computes CME co-lat magnetic field
        """
        return self.mask(clt, lon, t), self._bt

    def Bp(self, clt, lon, t):
        """Computes CME lon magnetic field
        """
        return self.mask(clt, lon, t), self._bp

    def __str__(self):
        message = "FRi3D CME at {}".format(self.params.start_time)
        return message
