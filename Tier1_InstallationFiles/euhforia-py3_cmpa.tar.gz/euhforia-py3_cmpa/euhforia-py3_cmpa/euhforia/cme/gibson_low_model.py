# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Gibson&Low Coronal Mass Ejection Model
"""

import datetime

import numpy as np
import pandas as pd

import coco.core.constants as constants

from .gibson_low import gibson_low


class GibsonLowModel(object):
    """Gibson and Low CME model.

    The Gibson and Low (1998) model is a time-dependent, three-dimensional
    analytic model of a coronal mass ejection. It features a stretched
    spheromak-like magnetic field, and a pressure and density distribution
    that provides a magnetohydrostatic equilibirum. As currently employed in
    EUHFORIA, however, the density and temperature are assumed constant.

    Args:
        start_time   :  Time at which the CME intersects the r=0.1 AU sphere
        lat          :  Latitude of the eruption, HEEQ deg
        lon          :  Longitude of the eruption, HEEQ deg
        half_width   :  Half width of the CME, deg
        speed        :  Speed of the CME, km/s
        mass_density :  Uniform CME mass density, kg/m^3
        temperature  :  Uniform CME temperature, K
        stretching   :  Stretching factor, solar radius
        handedness   :  Flux rope handedness, +/- 1
        rotation     :  Angle of rotation of CME, deg
        Bscale       :  Magnetic field strength scaling
    """

    def __init__(
        self,
        start_time,
        lat,
        lon,
        half_width,
        speed,
        mass_density,
        temperature,
        stretching,
        handedness,
        rotation,
        Bscale,
    ):

        #
        # Store parameters
        #

        class Parameters(object):
            pass

        self.params = Parameters()

        self.params.interface_radius = 0.1*constants.astronomical_unit
        self.params.interface_radius_in_Rs = self.params.interface_radius/constants.solar_radius

        self.params.lat = float(lat) * np.pi/180.0
        self.params.clt = -self.params.lat + 0.5*np.pi
        self.params.lon = float(lon) * np.pi/180.0

        self.params.start_time = start_time.to_pydatetime() if isinstance(start_time, pd.Timestamp) else start_time

        self.params.half_width = float(half_width)*np.pi/180.0
        self.params.speed = float(speed)*1e3
        self.params.mass_density = float(mass_density)
        self.params.temperature = float(temperature)

        #
        # Set GL parameters
        #
        self.gl = gibson_low.GibsonLowModel()

        self.gl.parameters.a = float(stretching)
        self.gl.parameters.H = float(handedness)
        self.gl.parameters.a1 = float(Bscale)
        self.gl.parameters.core_rotation = float(rotation)*np.pi/180.0

        front_height = self.params.interface_radius_in_Rs
        self.gl.parameters.x0 = (front_height + self.gl.parameters.a)/(1.0 + np.tan(self.params.half_width))
        self.gl.parameters.r0 = front_height - self.gl.parameters.x0 + self.gl.parameters.a

        self.gl.parameters.phi_ss = 1.0
        self.gl.parameters.r1 = 0.0  # This is arbitrary since the external field is not used
        self.gl.parameters.a0 = 5.763854/self.gl.parameters.r0

        self.gl.initialize()

        self.x0_at_start = self.gl.parameters.x0

        #
        # Compute derived parameters
        #

        # Time at which CME has fully passed the boundary
        self.params.end_time = self.params.start_time + datetime.timedelta(
            seconds=2.0*self.gl.parameters.r0*constants.solar_radius/self.params.speed
        )

    def mask(self, clt, lon, t):
        """Determines indices of grid points on the boundary sphere where the
        CME is inserted
        """

        idx = ()

        if t >= self.params.start_time and t <= self.params.end_time:

            time_from_start = (t - self.params.start_time).total_seconds()

            self.gl.parameters.x0 = self.x0_at_start + self.params.speed*time_from_start/constants.solar_radius

            shape = (len(clt), len(lon))

            is_inside = np.zeros(shape)

            for j in range(len(clt)):
                for k in range(len(lon)):
                    is_inside[j, k] = self.gl.is_inside(
                        (self.params.interface_radius_in_Rs, clt[j] + self.params.lat, lon[k] - self.params.lon)
                    )

            # Compute array indices where to insert values
            idx = np.where(is_inside > 0.0)

            # Transform to flat index
            idx = np.ravel_multi_index(idx, shape)

        return idx

    def mass_density(self, clt, lon, t):
        """Computes CME mass density
        """
        return self.mask(clt, lon, t), self.params.mass_density

    def temperature(self, clt, lon, t):
        """Computes CME temperature
        """
        return self.mask(clt, lon, t), self.params.temperature

    def vr(self, clt, lon, t):
        """Computes CME radial speed
        """
        return self.mask(clt, lon, t), self.params.speed

    def vt(self, clt, lon, t):
        """Computes CME colatitudinal speed
        """
        return (), 0.0

    def vp(self, clt, lon, t):
        """Computes CME longitudinal speed
        """
        return (), 0.0

    def Br(self, clt, lon, t):
        """Compute CME radial magnetic field component
        """

        idx = ()
        Br = 0.0

        if self.gl.parameters.a1 > 0.0:

            cltmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")

            idx = self.mask(clt, lon, t)

            lons = lonmesh.flatten()[idx]
            clts = cltmesh.flatten()[idx]

            # Compute Br at the given points
            Br = np.zeros(len(idx))

            for i in range(len(idx)):
                Br[i], Bt, Bp = self.gl.magnetic_field(
                    (self.params.interface_radius_in_Rs, clts[i] + self.params.lat, lons[i] - self.params.lon)
                )

        return idx, Br

    def Bt(self, clt, lon, t):
        """Compute CME co-latitudinal magnetic field component
        """

        idx = ()
        Bt = 0.0

        if self.gl.parameters.a1 > 0.0:

            cltmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")

            idx = self.mask(clt, lon, t)

            lons = lonmesh.flatten()[idx]
            clts = cltmesh.flatten()[idx]

            # Compute Bclt at the given points
            Bt = np.zeros(len(idx))

            for i in range(len(idx)):
                Br, Bt[i], Bp = self.gl.magnetic_field(
                    (self.params.interface_radius_in_Rs, clts[i] + self.params.lat, lons[i] - self.params.lon)
                )

        return idx, Bt

    def Bp(self, clt, lon, t):
        """Compute CME longitudinal magnetic field component
        """

        idx = ()
        Bp = 0.0

        if self.gl.parameters.a1 > 0.0:

            cltmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")

            idx = self.mask(clt, lon, t)

            lons = lonmesh.flatten()[idx]
            clts = cltmesh.flatten()[idx]

            # Compute Blon at the given points
            Bp = np.zeros(len(idx))

            for i in range(len(idx)):
                Br, Bt, Bp[i] = self.gl.magnetic_field(
                    (self.params.interface_radius_in_Rs, clts[i] + self.params.lat, lons[i] - self.params.lon)
                )

        return idx, Bp

    def Br_at_indices(self, clt, lon, t, indices):
        """Compute CME radial magnetic field component at given indices only
        """

        Br = np.zeros(len(indices))

        if (t >= self.params.start_time) and (t <= self.params.end_time) and self.gl.parameters.a1 > 0.0:

            time_from_start = (t - self.params.start_time).total_seconds()

            self.gl.parameters.x0 = self.x0_at_start + self.params.speed*time_from_start/constants.solar_radius

            cltmesh, lonmesh = np.meshgrid(clt, lon, indexing="ij")

            clts = cltmesh.flatten()[indices]
            lons = lonmesh.flatten()[indices]

            for i in range(len(indices)):
                Br[i], Bt, Bp = self.gl.magnetic_field(
                    (self.params.interface_radius_in_Rs, clts[i] + self.params.lat, lons[i] - self.params.lon)
                )

        return Br

    def dBrdt(self, clt, lon, t, dt):

        dBrdt = np.zeros((len(clt), len(lon)))

        t_plus_dt = t + datetime.timedelta(seconds=dt)
        t_minus_dt = t - datetime.timedelta(seconds=dt)

        if (
            (t_plus_dt >= self.params.start_time)
            and (t_minus_dt <= self.params.end_time)
            and self.gl.parameters.a1 > 0.0
        ):

            time_from_start = (t - self.params.start_time).total_seconds()

            #
            # Compute Br at time = t
            #
            Br = np.zeros((len(clt), len(lon)))

            self.gl.parameters.x0 = self.x0_at_start + self.params.speed * time_from_start / constants.solar_radius

            for j in range(len(clt)):
                for k in range(len(lon)):
                    Br[j, k], Bt, Bp = self.gl.magnetic_field(
                        (self.params.interface_radius_in_Rs, clt[j] + self.params.lat, lon[k] - self.params.lon)
                    )

            #
            # Compute Br at time = t + dt
            #
            Br_next = np.zeros((len(clt), len(lon)))

            self.gl.parameters.x0 = (
                self.x0_at_start + self.params.speed*(time_from_start + dt)/constants.solar_radius
            )

            for j in range(len(clt)):
                for k in range(len(lon)):
                    Br_next[j, k], Bt, Bp = self.gl.magnetic_field(
                        (self.params.interface_radius_in_Rs, clt[j] + self.params.lat, lon[k] - self.params.lon)
                    )

            dBrdt = (Br_next - Br) / dt

        return dBrdt

    def __str__(self):

        message = "GL CME at {}".format(self.params.start_time)

        return message
