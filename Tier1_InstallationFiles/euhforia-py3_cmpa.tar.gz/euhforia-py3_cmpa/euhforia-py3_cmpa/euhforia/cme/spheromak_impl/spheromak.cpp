/**
 *
 * This file is part of EUHFORIA.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * EUHFORIA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * EUHFORIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.
 *
 */


#define USE_XTENSORPYTHON_ARRAY

#include "coco/core/coco.hpp"
#include <pybind11/eigen.h>

#include "spheromak.hpp"


PYBIND11_PLUGIN(spheromak)
{
  namespace py = pybind11;

  py::module m("spheromak", "Spheromak magnetic field configurations");

  //
  // Linear force free model
  //

  py::class_<euhforia::LinearForceFreeSpheromakParameters>(m, "LFFSpheromakParameters")
    .def(py::init<>())
    .def_readwrite("x_center",      &euhforia::LinearForceFreeSpheromakParameters::x_center)
    .def_readwrite("y_center",      &euhforia::LinearForceFreeSpheromakParameters::y_center)
    .def_readwrite("z_center",      &euhforia::LinearForceFreeSpheromakParameters::z_center)
    .def_readwrite("lat",           &euhforia::LinearForceFreeSpheromakParameters::lat)
    .def_readwrite("lon",           &euhforia::LinearForceFreeSpheromakParameters::lon)
    .def_readwrite("helicity_sign", &euhforia::LinearForceFreeSpheromakParameters::helicity_sign)
    .def_readwrite("radius", &euhforia::LinearForceFreeSpheromakParameters::radius)
    .def_readwrite("alpha",  &euhforia::LinearForceFreeSpheromakParameters::alpha)
    .def_readwrite("B0",     &euhforia::LinearForceFreeSpheromakParameters::B0)
    .def_readwrite("tilt_angle",    &euhforia::LinearForceFreeSpheromakParameters::tilt_angle)
  ;


  py::class_<euhforia::LinearForceFreeSpheromakModel>(m, "LFFSpheromak")
    .def(py::init<>())
    .def("initialize",     &euhforia::LinearForceFreeSpheromakModel::initialize)
    .def("is_inside",      &euhforia::LinearForceFreeSpheromakModel::is_inside)
    .def("magnetic_field", &euhforia::LinearForceFreeSpheromakModel::magnetic_field)
    .def_readwrite("parameters", &euhforia::LinearForceFreeSpheromakModel::params)
  ;

  return m.ptr();

}
