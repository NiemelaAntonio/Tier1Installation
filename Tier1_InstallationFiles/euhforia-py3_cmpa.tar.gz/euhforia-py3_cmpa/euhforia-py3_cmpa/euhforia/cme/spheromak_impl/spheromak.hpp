/**
 *
 * This file is part of EUHFORIA.
 *
 * Copyright 2016, 2017 Jens Pomoell
 *
 * EUHFORIA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * EUHFORIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

/**
 * \brief Gibson & Low (1998) flux rope CME model
 *
 */

#include <Eigen/Core>
#include <Eigen/Geometry>

#include "coco/core/constants.hpp"
#include "coco/core/functions.hpp"
#include "coco/geometry/transforms.hpp"


namespace euhforia {


/*!
 * \brief Class storing the parameters of the linear force-free spheromak model.
 *
 */
struct LinearForceFreeSpheromakParameters
{

  double helicity_sign;  // Helicity sign

  double radius;         // Spheromak radius

  double alpha;          // Force-free parameter

  double x_center;       // Displacement of spheromak system in x
  double y_center;       // Displacement of spheromak system in y
  double z_center;       // Displacement of spheromak system in z

  double lat;            // Propagation direction latitude
  double lon;            // Propagation direction longitude

  double tilt_angle;     // Angular tilt of spheromak

  double B0;

};





/*!
 * \brief Class for computing the magnetic field of a linear force-free
 *        spheromak.
 *
 */
class LinearForceFreeSpheromakMagneticField
{
public:

  LinearForceFreeSpheromakParameters param;

public:

  /*!
   * \brief Computes the spheromak magnetic field.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates in the axisymmetric
   *                    coordinate system in which the solution is computed.
   *
   * \returns    Eigen::Vector3d containing the spherical
   *             (Br, Bclt, Blon) components of the magnetic field in the
   *             axisymmetric system
   */
  auto magnetic_field(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    auto B   = Eigen::Vector3d(dAdth(p)/r, -dAdr(p), Q(p));
    B       *= 1.0/(r*sin(th));

    return B;
  }

  /*!
   * \brief Computes the poloidal scalar potential A(r, th)
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    the poloidal potential at the given coordinates
   */
  auto poloidal_potential(const Eigen::Vector3d & p) const
  {
    return A(p);
  }

  /*!
   * \brief Computes the toroidal scalar potential Q
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Q at the given coordinates
   */
  auto toroidal_potential(const Eigen::Vector3d & p) const
  {
    return Q(p);
  }


  /*!
   * \brief Computes the poloidal scalar potential A(r, th)
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    the poloidal potential at the given coordinates
   */
  double A(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    return (param.B0/param.alpha)*r*j1(param.alpha*r)*sin(th)*sin(th);
  }


  /*!
   * \brief Computes the toroidal scalar potential Q
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Q at the given coordinates
   */
  double Q(const Eigen::Vector3d & p) const
  {
    return Q(A(p));
  }


  /*!
   * \brief Computes the toroidal scalar potential Q
   *
   * \param[in]  A      Value of the poloidal potential
   *
   * \returns    Q(A)
   */
  double Q(const double A) const
  {
    return param.helicity_sign*param.alpha*A;
  }


private:


  /*!
   * \brief Computes the derivative of the poloidal potential wrt r.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of dA/dr at p
    */
  double dAdr(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    const auto x = param.alpha*r;

    return (param.B0/param.alpha)*(j1(x) + x*dj1dx(x))*sin(th)*sin(th);
  }


  /*!
   * \brief Computes the derivative of the poloidal potential wrt colatitude.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Value of dA/dth at p
    */
  double dAdth(const Eigen::Vector3d & p) const
  {
    const auto r  = p[0];
    const auto th = p[1];

    return (param.B0/param.alpha)*r*j1(param.alpha*r)*2.0*sin(th)*cos(th);
  }


  /*!
   * \brief Compute the spherical bessel function j_1(x)
   *
   * \param[in]  x
   *
   * \returns    j_1(x)
   */
  double j1(const double x) const
  {
    return (-x*cos(x) + sin(x))/(x*x);
  }


  /*!
   * \brief Computes dj_1(x)/dx = j_0(x) - 2 j_1(x)/x
   *
   * \param[in]  x
   *
   * \returns    dj_1(x)/dx
   */
  double dj1dx(const double x) const
  {
    const auto j0 = sin(x)/x;

    return j0 - 2.0*j1(x)/x;
  }

};



/*!
 * \brief Class for computing the magnetic field configuration of the
 *        Linear force-free spheromak CME model.
 *
 */
class LinearForceFreeSpheromakModel
{
public:

  LinearForceFreeSpheromakParameters params;

  LinearForceFreeSpheromakMagneticField internal;


public:

  void initialize()
  {
    internal.param = params;
  }


  /*!
   * \brief Determines whether the given point is inside the sphere.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    bool
   */
  auto is_inside(const Eigen::Vector3d & p)
  {

    // Translation transform
    const auto translate = Eigen::Translation3d(Eigen::Vector3d(-params.x_center,
                                                                -params.y_center,
                                                                -params.z_center));

    // Rotation transform
    const auto rotate_x  = Eigen::AngleAxisd(params.tilt_angle,
                                           Eigen::Vector3d(1, 0, 0));

    const auto rotate_y  = Eigen::AngleAxisd(params.lat,
                                          Eigen::Vector3d(0, 1, 0));

    const auto rotate_z  = Eigen::AngleAxisd(-params.lon,
                                           Eigen::Vector3d(0, 0, 1));


    //
    // Compute coordinate p in the local CME Cartesian basis
    //
    const auto rotate = rotate_x*rotate_y*rotate_z;

    const auto p_local_internal_cart
      = (rotate*translate*coco::geometry::transform::spherical::to_cartesian_coordinates(p));


    // Coordinate p in the local internal spherical basis
    const auto p_local_internal_sph
      = coco::geometry::transform::cartesian::to_spherical_coordinates(p_local_internal_cart);

    // Is p inside the CME?
    bool is_in = true;

    if (p_local_internal_sph[0] > params.radius) {
      is_in = false;
    }

    return is_in;
  }


  /*!
   * \brief Computes the magnetic field configuration.
   *
   * \param[in]  p      Eigen::Vector3d containing spherical
   *                    (r, clt, lon) coordinates
   *
   * \returns    Eigen::Vector3d containing the spherical
   *             (Br, Bclt, Blon) components
   */
  auto B(const Eigen::Vector3d & p)
  {

    // Translation transform
    const auto translate = Eigen::Translation3d(Eigen::Vector3d(-params.x_center,
                                                                -params.y_center,
                                                                -params.z_center));

    // Rotation transform
    const auto rotate_x  = Eigen::AngleAxisd(params.tilt_angle,
                                           Eigen::Vector3d(1, 0, 0));

    const auto rotate_y  = Eigen::AngleAxisd(params.lat,
                                          Eigen::Vector3d(0, 1, 0));

    const auto rotate_z  = Eigen::AngleAxisd(-params.lon,
                                           Eigen::Vector3d(0, 0, 1));


    //
    // Compute coordinate p in the local CME Cartesian basis
    //
    const auto rotate = rotate_x*rotate_y*rotate_z;

    const auto p_local_internal_cart
      = (rotate*translate*coco::geometry::transform::spherical::to_cartesian_coordinates(p));


    // Coordinate p in the local internal spherical basis
    const auto p_local_internal_sph
      = coco::geometry::transform::cartesian::to_spherical_coordinates(p_local_internal_cart);


    //
    // Compute magnetic field
    //

    Eigen::Vector3d B(0.0, 0.0, 0.0);

    if (p_local_internal_sph[0] <= params.radius) {

      // Internal magnetic field in local spherical basis
      const auto bint_sph
        = internal.magnetic_field(p_local_internal_sph);

      // Internal magnetic field in local Cartesian basis
      const auto bint_cart
        = coco::geometry::transform::spherical::to_cartesian_vector(bint_sph, p_local_internal_sph, false);

      // Transform to global Cartesian basis
      B = rotate.inverse()*bint_cart;
    }

    // Return vector in spherical basis
    return coco::geometry::transform::cartesian::to_spherical_vector(B, p, false);
  }


  auto magnetic_field(const Eigen::Vector3d & p)
  {
    return B(p);
  }

};

}
