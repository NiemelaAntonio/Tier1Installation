# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Source surface current sheet coronal magnetic field model.
"""

import configparser
import copy

import astropy.coordinates
import coco.core.coordinates
import euhforia.core.constants as constants
import euhforia.tools.field_line_tracer
import numpy as np
import sunpy.map
from euhforia.corona.magnetic_field import pfss, scs


class SSCS(object):
    """Source surface current sheet coronal magnetic field model.

    This model combines the PFSS and SCS models to arrive at a magnetic field
    model covering the corona from the coronal base (~ 1 RSun) out to ~0.1 AU.
    """

    def __init__(self):

        self.pfss = pfss.PFSS()

        self.scs = scs.SCS()

    def set_magnetogram(self, magnetogram):

        self.pfss.magnetogram = magnetogram

    def initialize_from_config(self, config_file_name):

        config = configparser.ConfigParser()
        config.read(config_file_name)

        #
        # Set PFSS parameters
        #
        self.pfss.max_degree = config.getint("PFSS", "max_degree")
        self.pfss.source_surface_radius = config.getfloat("PFSS", "source_surface_radius") * constants.solar_radius

        # Radial grid coordinates for PFSS model
        self.pfss_radial_grid_coordinates = coco.core.coordinates.constant_ratio_coordinates(
            start=self.pfss.r0,
            end=self.pfss.source_surface_radius,
            num_points=config.getfloat("PFSS", "number_of_radial_grid_pts", fallback=128),
            dx_at_start=0.0025*constants.solar_radius,
        )

        #
        # Set SCS parameters
        #
        self.scs.max_degree = config.getint("SCS", "max_degree")
        self.scs.r0 = config.getfloat("SCS", "start_radius") * constants.solar_radius
        self.scs.rend = config.getfloat("SCS", "end_radius") * constants.astronomical_unit

        # Radial grid coordinates for SCS model
        idx = abs(self.pfss_radial_grid_coordinates - self.scs.r0).argmin()
        dr = self.pfss_radial_grid_coordinates[idx] - self.pfss_radial_grid_coordinates[idx - 1]

        self.scs_radial_grid_coordinates = coco.core.coordinates.constant_ratio_coordinates(
            start=self.scs.r0,
            end=self.scs.rend,
            num_points=config.getfloat("SCS", "number_of_radial_grid_pts", fallback=128),
            dx_at_start=dr,
        )

    def compute(self):

        #
        # Compute PFSS model
        #
        self.pfss.compute()

        self.pfss_on_grid = self.pfss.compute_field_on_grid(self.pfss_radial_grid_coordinates)

        #
        # Compute boundary data for SCS model
        #
        # The boundary data is the unsigned radial magnetic field as
        # provided by the PFSS model
        #
        Br, Bt, Bp = self.pfss.get_synoptic_map(self.scs.r0)

        Br_unsigned = sunpy.map.Map(np.abs(Br.data), Br.meta)
        # Br_unsigned = copy.deepcopy(Br)
        # Br_unsigned.data = np.abs(Br_unsigned.data)

        self.scs.magnetogram = Br_unsigned

        #
        # Compute SCS model
        #
        self.scs.compute()

        self.scs_on_grid = self.scs.compute_field_on_grid(self.scs_radial_grid_coordinates)

        #
        # Merge grids
        #
        """
        self.solution_on_grid = copy.deepcopy(self.pfss_on_grid)

        self.solution_on_grid.grid.axis.r.coordinates \
            = np.concatenate((r_pfss, self.scs_on_grid.grid.axis.r.coordinates[1::]))

        for key in self.solution_on_grid.data.keys():
            self.solution_on_grid.data[key] \
                = np.concatenate((self.pfss_on_grid.data[key][:, :, :], self.scs_on_grid.data[key][1::, :, :]))
        """

    def compute_polarity_corrected_solution(self, num_points=256):

        #
        # Compute magnetic field on entire domain
        #

        # Coordinates of domain
        radial_crds = coco.core.coordinates.constant_ratio_coordinates(
            start=self.pfss.r0, end=self.scs.rend, num_points=num_points, dx_at_start=0.0025*constants.solar_radius
        )

        # Coordinates of PFSS part
        pfss_radial_crds = radial_crds[np.where(radial_crds <= self.scs.r0)]

        # Compute PFSS
        pfss = self.pfss.compute_field_on_grid(pfss_radial_crds)

        # Coordinates of SCS part
        scs_radial_crds = radial_crds[np.where(radial_crds > self.scs.r0)]

        # Compute PFSS
        scs = self.scs.compute_field_on_grid(scs_radial_crds)

        # Construct PFSS+SCS field
        field = copy.deepcopy(pfss)

        field.grid.axis.r.coordinates = np.concatenate((pfss_radial_crds, scs_radial_crds[1::]))

        for key in field.data.keys():
            field.data[key] = np.concatenate((pfss.data[key][:, :, :], scs.data[key][1::, :, :]))

        #
        # Correct polarity
        #

        #
        # Shorthands for convenience
        #
        Br_array = field.data["Br"]
        Bt_array = field.data["Bt"]
        Bp_array = field.data["Bp"]

        r = field.grid.axis.r.coordinates
        t = field.grid.axis.clt.coordinates
        p = field.grid.axis.lon.coordinates

        t_mesh, p_mesh = np.meshgrid(t, p, indexing="ij")

        sin_t = np.sin(t_mesh)
        cos_t = np.cos(t_mesh)
        sin_p = np.sin(p_mesh)
        cos_p = np.cos(p_mesh)

        reverse_polarity = np.zeros(field.data["Br"].shape)

        #
        # In the PFSS region, the polarity should be unchanged
        #
        reverse_polarity[np.where(r <= self.scs.r0), :, :] = 1.0

        #
        # In the SCS region, all field points outwards
        #
        for i in np.where(r > self.scs.r0)[0]:

            Br = Br_array[i, :, :]
            Bt = Bt_array[i, :, :]
            Bp = Bp_array[i, :, :]

            # Compute Cartesian components of B at current shell
            Bx = Br * sin_t * cos_p + Bt * cos_t * cos_p - Bp * sin_p
            By = Br * sin_t * sin_p + Bt * cos_t * sin_p + Bp * cos_p
            Bz = Br * cos_t - Bt * sin_t

            # Compute Cartesian coordinates of points on shell
            x = r[i] * sin_t * cos_p
            y = r[i] * sin_t * sin_p
            z = r[i] * cos_t

            Babs = np.sqrt(Br**2 + Bt**2 + Bp**2)

            for j in range(len(t)):
                for k in range(len(p)):

                    # Direction vector of line
                    l = np.array((Bx[j, k] / Babs[j, k], By[j, k] / Babs[j, k], Bz[j, k] / Babs[j, k]))

                    # Origin of line
                    origin = np.array((x[j, k], y[j, k], z[j, k]))

                    # term under sqrt in distance to intersection to spherical shell
                    l_dot_o = np.dot(l, origin)

                    D = l_dot_o ** 2 - np.dot(origin, origin) + r[i - 1] ** 2

                    sqrt_D = 0.0
                    if D > 0:
                        sqrt_D = np.sqrt(D)

                    d1 = abs(-l_dot_o + sqrt_D)
                    d2 = abs(-l_dot_o - sqrt_D)

                    # Due to the problem at hand, the true distance must be the smallest one
                    # and in the direction of the
                    d = min(d1, d2)

                    # Coordinate of the point at the intersection (let's call it point A)
                    crdA = origin - d * l

                    # Spherical coordinates of point
                    rA = np.sqrt(np.dot(crdA, crdA))
                    tA = np.arccos(crdA[2] / rA)
                    pA = np.arctan2(crdA[1], crdA[0])

                    # Wrap longitude
                    if pA > p[-1]:
                        pA -= 2.0*np.pi
                    if pA < p[0]:
                        pA += 2.0*np.pi

                    # Closest index to point (assumes that radial index = i-1)
                    ti = abs(tA - t).argmin()
                    pi = abs(pA - p).argmin()

                    reverse = np.sign(Br_array[i - 1, ti, pi])

                    # Correct
                    Br_array[i, j, k] *= reverse
                    Bt_array[i, j, k] *= reverse
                    Bp_array[i, j, k] *= reverse

        return field

    def trace_synoptic(self,
                       direction,
                       start_radius,
                       deg_per_pixel,
                       max_path_length=40.0*constants.solar_radius,
                       min_step_size=0.001*constants.solar_radius,
                       **kwargs):

        trace_map = None

        if direction == "outward":

            if start_radius >= self.scs.r0:

                #
                # Trace from SCS model upwards
                #

                tracer = euhforia.tools.field_line_tracer.FieldlineTracer(self.scs_on_grid, method="rk2")

                trace_map = euhforia.tools.field_line_tracer.SynopticFieldLineTracer(
                    radius=start_radius,
                    deg_per_pixel=deg_per_pixel,
                    max_path_length=max_path_length,
                    min_step_size=min_step_size,
                    direction=direction,
                    tracer=tracer,
                    field_model=self.scs,
                    date=self.pfss.magnetogram.meta["date"],
                    crval1=self.pfss.magnetogram.meta["crval1"],
                )

                trace_map.compute()

            else:

                #
                # Trace first up to edge of SCS model (or back to photosphere)
                #
                pfss_tracer = euhforia.tools.field_line_tracer.FieldlineTracer(
                    self.pfss_on_grid, method="rk2", rmax=self.scs.r0
                )

                trace_map = euhforia.tools.field_line_tracer.SynopticFieldLineTracer(
                    radius=start_radius,
                    deg_per_pixel=deg_per_pixel,
                    max_path_length=max_path_length,
                    min_step_size=min_step_size,
                    direction=direction,
                    tracer=pfss_tracer,
                    field_model=self.pfss,
                    date=self.pfss.magnetogram.meta["date"],
                    crval1=self.pfss.magnetogram.meta["crval1"],
                )

                trace_map.compute()

                #
                # Trace then onwards in SCS model
                #
                scs_tracer = euhforia.tools.field_line_tracer.FieldlineTracer(self.scs_on_grid, method="rk2")

                # Truncate start point
                # if np.any(trace_map.at_end_pt["r"].data < self.scs.r0):
                #    print "Truncating starting point radii"
                #    trace_map.at_end_pt["r"].data[np.where(trace_map.at_end_pt["r"].data < self.scs.r0)] = self.scs.r0

                lons, lats = euhforia.core.map.get_center_coordinates(trace_map.at_start_pt["lon"])

                halfway_in_r = self.pfss.r0 + 0.5*(self.scs.r0 - self.pfss.r0)

                #
                # For each point on map, trace field line and record results
                #
                for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
                    for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

                        start_pt_r = trace_map.at_end_pt["r"].data[j, k]

                        if start_pt_r < halfway_in_r:
                            continue
                        else:
                            start_pt_r = max(trace_map.at_end_pt["r"].data[j, k], 1.001*self.scs.r0)

                        start_pt = (
                            start_pt_r,
                            0.5*np.pi - trace_map.at_end_pt["lat"].data[j, k]*np.pi/180.0,
                            trace_map.at_end_pt["lon"].data[j, k]*np.pi/180.0,
                        )

                        B_at_start = self.scs.at_coordinate(start_pt)

                        end_pt = scs_tracer.tracer.compute(
                            start_pt,
                            True,
                            trace_map.fractional_step_size,
                            trace_map.max_path_length,
                            trace_map.min_step_size,
                        )

                        B_at_end = self.scs.at_coordinate(end_pt)

                        # Record data
                        trace_map.at_end_pt["r"].data[j, k] = end_pt[0]
                        trace_map.at_end_pt["lat"].data[j, k] = 90.0 - 180.0*end_pt[1]/np.pi
                        trace_map.at_end_pt["lon"].data[j, k] = end_pt[2]*180.0/np.pi

                        trace_map.at_end_pt["Br"].data[j, k] = B_at_end[0]
                        trace_map.at_end_pt["Bt"].data[j, k] = B_at_end[1]
                        trace_map.at_end_pt["Bp"].data[j, k] = B_at_end[2]

        elif direction == "inward":

            rmin = float(kwargs.get("rmin", 0.0))

            if start_radius <= self.scs.r0:

                #
                # Trace from PFSS model inwards
                #
                tracer = euhforia.tools.field_line_tracer.FieldlineTracer(self.pfss_on_grid, method="rk2", rmin=rmin)

                trace_map = euhforia.tools.field_line_tracer.SynopticFieldLineTracer(
                    radius=start_radius,
                    deg_per_pixel=deg_per_pixel,
                    max_path_length=max_path_length,
                    min_step_size=min_step_size,
                    direction=direction,
                    tracer=tracer,
                    field_model=self.pfss,
                    date=self.pfss.magnetogram.meta["date"],
                    crval1=self.pfss.magnetogram.meta["crval1"],
                )

                trace_map.compute()

            else:

                #
                # Trace first to edge of SCS domain
                #
                scs_tracer = euhforia.tools.field_line_tracer.FieldlineTracer(
                    self.scs_on_grid, method="rk2", rmin=max(rmin, self.scs.r0)
                )

                trace_map = euhforia.tools.field_line_tracer.SynopticFieldLineTracer(
                    radius=start_radius,
                    deg_per_pixel=deg_per_pixel,
                    max_path_length=max_path_length,
                    min_step_size=min_step_size,
                    direction=direction,
                    tracer=scs_tracer,
                    field_model=self.scs,
                    date=self.pfss.magnetogram.meta["date"],
                    crval1=self.pfss.magnetogram.meta["crval1"],
                )

                trace_map.compute()

                if rmin < self.scs.r0:

                    #
                    # Continue to inner boundary of PFSS model if rmin is in the PFSS domain
                    #
                    pfss_tracer = euhforia.tools.field_line_tracer.FieldlineTracer(
                        self.pfss_on_grid, method="rk2", rmin=rmin
                    )

                    lons, lats = euhforia.core.map.get_center_coordinates(trace_map.at_start_pt["lon"])

                    #
                    # For each point on map, trace field line and record results
                    #
                    for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
                        for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

                            start_pt = (
                                trace_map.at_end_pt["r"].data[j, k],
                                0.5*np.pi - trace_map.at_end_pt["lat"].data[j, k]*np.pi/180.0,
                                trace_map.at_end_pt["lon"].data[j, k]*np.pi/180.0,
                            )

                            B_at_start = self.pfss.at_coordinate(start_pt)

                            trace_outward = bool(trace_map.trace_outward == (B_at_start[0] > 0))

                            end_pt = pfss_tracer.tracer.compute(
                                start_pt,
                                trace_outward,
                                trace_map.fractional_step_size,
                                trace_map.max_path_length,
                                trace_map.min_step_size,
                            )

                            B_at_end = self.pfss.at_coordinate(end_pt)

                            # Record data
                            trace_map.at_end_pt["r"].data[j, k] = end_pt[0]
                            trace_map.at_end_pt["lat"].data[j, k] = 90.0 - 180.0*end_pt[1]/np.pi
                            trace_map.at_end_pt["lon"].data[j, k] = end_pt[2]*180.0/np.pi

                            trace_map.at_end_pt["Br"].data[j, k] = B_at_end[0]
                            trace_map.at_end_pt["Bt"].data[j, k] = B_at_end[1]
                            trace_map.at_end_pt["Bp"].data[j, k] = B_at_end[2]

        else:
            raise ValueError("Unknown trace direction")

        return trace_map
