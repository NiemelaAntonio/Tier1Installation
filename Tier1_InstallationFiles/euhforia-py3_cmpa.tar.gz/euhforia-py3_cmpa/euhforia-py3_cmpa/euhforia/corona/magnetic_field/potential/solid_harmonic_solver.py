# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module for computing potential magnetic fields using solid harmonics.
"""

import copy

import astropy.coordinates
import numpy as np
import scipy.interpolate
import shtns
import sunpy.map

import coco
import coco.core.field
import euhforia.core.constants as constants
import euhforia.core.map


class SolidHarmonicPotentialMagneticFieldSolver(object):
    """Class for computing potential magnetic fields in a spherical shell.

    Computes potential magnetic fields (\vec{B} = \nabla{\psi}) in a spherical
    shell domain given Neumann boundary conditions on the inner sphere. The
    resulting Laplace equation for the scalar potential is solved using the
    traditional approach of employing an expansion in solid harmonics. The
    harmonic transforms are computed using the `SHTns library`_, see the
    corresponding documentation for details on the computation itself.

    The inner boundary condition is prescribed by setting the magnetogram
    attribute, and is assumed to be a SunPy.Map object with appropriate data
    and metadata. The euhforia.magnetogram loaders provide magnetograms that
    can be used, see notebooks in examples/coronal_magnetic_fields for examples
    on usage.

    Two models implementing different boundary conditons on the outer sphere
    are supported:
      1. Potential field source surface (PFSS) model in which the magnetic field
         becomes purely radial at a given source surface height
      2. "Regular" model for which the magnetic field tends towards zero at infinity

    Args:
        model (str)                   : The model to compute, PFSS or regular at infinity ("PFSS"/"regular").
        max_degree (int)              : Maximum degree (l) to include in the solid harmonic expansion.
        remove_monopole (bool)        : Set the lowest order term in the expansion to zero.
        lower_boundary_radius (float) : Radius of the lower radial boundary.
        source_surface_radius (float) : Radius of the source surface. Only used with the PFSS model.

    .. _SHTns library:
       https://users.isterre.fr/nschaeff/SHTns/index.html
    """

    def __init__(self,
                 model,
                 max_degree=20,
                 remove_monopole=True,
                 lower_boundary_radius=constants.solar_radius,
                 source_surface_radius=2.5*constants.solar_radius):

        self.model = "PFSS" if "PFSS" in model.upper() else "regular"

        self.remove_monopole = remove_monopole
        self.max_degree = int(max_degree)
        self.r0 = lower_boundary_radius

        if self.model == "PFSS":
            self.source_surface_radius = source_surface_radius

    def _prepare_magnetogram(self):

        # TODO...
        #
        # Check that the latitudinal coordinates that SHTns assumes are
        # the same as in the magnetogram
        #
        pass

    def compute(self):
        """Compute the model.
        """

        # TODO: should turn this around, i.e. prepare magnetogram according to
        # the needs of SHTns! The only piece of info that is needed is the
        # deg / pix angular resolution

        #
        # Prepare magnetogram for computation
        #
        if self.magnetogram is None:
            raise ValueError("Magnetogram has not been set.")
        else:
            self._prepare_magnetogram()

        #
        # Initialize spherical harmonic solver SHTns
        #
        self._sph_harm = shtns.sht(self.max_degree, self.max_degree)

        #
        #
        grid_type = shtns.sht_reg_fast | shtns.SHT_THETA_CONTIGUOUS

        self._sph_harm.set_grid(
            self.magnetogram.meta["NAXIS2"],  # num lat points
            self.magnetogram.meta["NAXIS1"],  # num lon points
            flags=grid_type,
        )

        # Compute and store the harmonic coefficents
        self._compute_harmonic_coefficients()

        # Compute the longitude coordinate of the left edge
        lons, lats = euhforia.core.map.get_edge_coordinates(self.magnetogram)
        self.lon_of_edge = lons[0]*np.pi/180.0

    def _compute_harmonic_coefficients(self):
        """Performs the analysis step in which the harmonic expansion
        coefficents are computed.
        """

        #
        # Specify Neumann boundary condition on the inner sphere.
        #
        # NOTE: In the SunPy Map, the data is assumed to represent Br,
        #       and the layout is such that data[j, k] = Br(lat_j, lon_k),
        #       i.e. Br starts in the lower left corner when plotted with
        #       plot.synoptic. However, SHTns wants the data as
        #       Br(clt_j, lon_k), so a flip is needed.
        #       Likewise, a flip back is needed when producing SunPy maps
        #       from the model
        Br = np.array(np.flipud(self.magnetogram.data).T, dtype=float)

        # Compute harmonic coefficients and store result as member
        self._Clm = self._sph_harm.analys(Br)

        # Remove monopole component from expansion
        if self.remove_monopole:
            self._Clm[self._sph_harm.idx(0, 0)] = complex(0)

    def get_synoptic_map(self, r):
        """Computes the magnetic field on a spherical surface.

        Args:
            r : Radius of the spherical surface
        Returns
            Maps Br, Bt, Bp
        """

        Qlm, Slm, Tlm = self._compute_QST_fields(r)

        # Compute radial, colatitudinal (theta) and longitudinal (phi) components
        Br, Bt, Bp = self._sph_harm.synth(Qlm, Slm, Tlm)

        # Create a map out of the result

        # TODO: add variable names to metadata!
        # TODO: erase old metadata, i.e. create fresh metadata
        meta = copy.copy(self.magnetogram.meta)

        # Flip data to conform to that in the metadata
        Br_map = sunpy.map.Map((np.flipud(Br.T), meta))
        Bt_map = sunpy.map.Map((np.flipud(Bt.T), meta))
        Bp_map = sunpy.map.Map((np.flipud(Bp.T), meta))

        return Br_map, Bt_map, Bp_map

    def _compute_QST_fields(self, r):
        """Computes the radial, spheroidal and toroidal scalar fields Q, S and T,
        see https://users.isterre.fr/nschaeff/SHTns/vsh.html
        """

        x = r/self.r0
        l = self._sph_harm.l

        Qlm = 0.0
        Slm = 0.0

        if self.model == "PFSS":

            xs = self.source_surface_radius / self.r0

            denom = l * (xs ** (-2*l - 1)) + l + 1.0

            Qlm = (self._Clm/denom)*(l*(xs**(-2*l - 1))*(x**(l - 1)) + (l + 1.0)*(x**(-l - 2)))
            Slm = (self._Clm/denom)*((xs**(-2*l - 1))*(x**(l - 1)) - (x**(-l - 2)))

        else:

            denom = l + 1.0

            Qlm = (self._Clm/denom)*((l + 1.0)*(x**(-l - 2)))
            Slm = (self._Clm/denom)*(-(x**(-l - 2)))

        Tlm = np.zeros(len(Slm), dtype=complex)

        return Qlm, Slm, Tlm

    def at_coordinate(self, p):
        """Computes magnetic field vector at point p.

        Note that this function should be used sparingly if computation
        efficiency is of concern.

        Args:
            p : triplet (radius, colatitude, longitude) giving the coordinates
                of the point.
        Returns:
            (B_radius, B_colatitude, B_longitude) triplet
        """

        r, colat, lon = p

        # Shift longitude so that it is in [0, 360[ range
        shifted_lon = (lon - self.lon_of_edge) % (2.0*np.pi)

        Qlm, Slm, Tlm = self._compute_QST_fields(r)

        return self._sph_harm.SHqst_to_point(Qlm, Slm, Tlm, np.cos(colat), shifted_lon)

    def compute_field_on_grid(self, radial_coordinates):
        """Computes the field on a grid

        Computes the potential magnetic field on a nodal grid. The radial coordinates
        are given as input. The longitudinal and latitudinal coordinates are
        the edge coordinates of the input magnetogram.

        Args:
            radial_coordinates (array) : Coordinates of radial axis

        Returns:
            coco.VectorField object
        """

        # Edge coordinates of input magnetogram
        edge_lons, edge_lats = euhforia.core.map.get_edge_coordinates(self.magnetogram)

        # Make sure coordinates monotonically increasing
        translated_lons = astropy.coordinates.Longitude(edge_lons - edge_lons[0], unit="deg").value
        translated_lons[-1] = translated_lons[0] + 360.0
        translated_lons += edge_lons[0]

        # Number of pixels
        num_lon_pixels = len(translated_lons) - 1
        num_lat_pixels = len(edge_lats) - 1

        # Compute pixel center coordinates
        pixel_lons = 0.5*(translated_lons[1::] + translated_lons[0:-1])
        pixel_lats = 0.5*(edge_lats[1::] + edge_lats[0:-1])

        # Construct coordinates of extended pixel-centered spherical map that is
        # to be used as the source for interpolation
        lon_centers_extended = np.zeros(num_lon_pixels + 2)
        lat_centers_extended = np.zeros(num_lat_pixels + 2)

        lon_centers_extended[1:-1] = pixel_lons
        lat_centers_extended[1:-1] = pixel_lats

        # Add periodic coordinates
        lon_centers_extended[0] = lon_centers_extended[-2] - 360.0
        lon_centers_extended[-1] = lon_centers_extended[1] + 360.0

        # Add poles
        lat_centers_extended[0] = -90.0
        lat_centers_extended[-1] = 90.0

        lon_centers_extended *= np.pi/180.0
        clt_centers_extended = (90.0 - lat_centers_extended[::-1])*np.pi/180.0

        #
        # Construct grid
        #
        grid = coco.Grid(geometry="spherical")

        r = coco.CoordinateAxis(name="r")
        r.coordinates = np.copy(radial_coordinates)

        clt = coco.CoordinateAxis(name="clt")
        clt.coordinates = 0.5 * np.pi - np.copy(edge_lats[::-1])*np.pi/180.0  # flip due to FORTRAN ordering

        lon = coco.CoordinateAxis(name="lon")
        lon.coordinates = np.copy(translated_lons)*np.pi/180.0

        grid.set_coordinate_axes(r, clt, lon)

        # Array of points for RegularGridInterpolator
        interpolation_coordinates = (
            np.vstack(np.meshgrid(clt.coordinates, lon.coordinates, indexing="ij")).reshape(2, -1).T
        )

        #
        # Loop through radial coordinates, computing the values on the
        # spherical shell at each r
        #

        B_on_grid = (np.zeros(grid.num_nodes), np.zeros(grid.num_nodes), np.zeros(grid.num_nodes))

        for idx, r in enumerate(radial_coordinates):

            # Compute field on pixel centers
            Qlm, Slm, Tlm = self._compute_QST_fields(r)
            B_on_pixels = self._sph_harm.synth(Qlm, Slm, Tlm)

            # Polar magnetic fields
            B_at_north_pole = self.at_coordinate((r, 0.0, 0.0))
            B_at_south_pole = self.at_coordinate((r, np.pi, 0.0))

            # Interpolate extended pixel-centered to nodes
            for dim in (0, 1, 2):

                B_extended = np.zeros((num_lat_pixels + 2, num_lon_pixels + 2))

                # Interior of map identical to the pixel-centered field
                B_extended[1:-1, 1:-1] = B_on_pixels[dim].T

                # Add polar fields
                B_extended[0, :] = B_at_north_pole[dim]
                B_extended[-1, :] = B_at_south_pole[dim]

                # Add periodic points
                B_extended[:, 0] = B_extended[:, -2]
                B_extended[:, -1] = B_extended[:, 1]

                # Interpolate to nodes
                interpolator = scipy.interpolate.RegularGridInterpolator(
                    (clt_centers_extended, lon_centers_extended), B_extended, method="linear"
                )

                B_interp = interpolator(interpolation_coordinates)

                B_on_grid[dim][idx, :, :] = B_interp.reshape((num_lat_pixels + 1, num_lon_pixels + 1))

        field = coco.core.field.VectorField(grid=grid)

        field.data = {"Br": np.copy(B_on_grid[0]), "Bt": np.copy(B_on_grid[1]), "Bp": np.copy(B_on_grid[2])}

        # Attach metadata
        # TODO: add variable names to metadata!
        # TODO: erase old metadata, i.e. create fresh metadata
        field.meta = copy.copy(self.magnetogram.meta)

        return field
