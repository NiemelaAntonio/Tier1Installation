# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Determines open and closed field lines
"""

import astropy.coordinates
import numpy as np

import euhforia.core.map


def compute_open_and_closed_fields(synoptic_trace_map, open_field_threshold_radius):
    """Compute regions of open and closed fields.

    For each foot point of a given synoptic trace map, determines whether the
    field line if closed or open. The connectivity information is coded as:

     +/- 2 :   open field with positive/negative polarity at footpoint
     +/- 1 : closed field with positive/negative polarity at footpoint

    Args:
      synoptic_trace_map : SynopticFieldLineTracer - object containing map of
                           field lines traced from the photosphere/low corona
                           upwards
      open_field_threshold_radius : Radius beyond which the end point of the
                                    field line is designated an open field

    Returns:
      SunPy map containing connectivity information
    """

    #
    # Initialize map
    #
    m = euhforia.core.map.create_empty_map(
        date=synoptic_trace_map.date,
        deg_per_pixel=synoptic_trace_map.deg_per_pixel,
        crval1=synoptic_trace_map.at_start_pt["Br"].meta["crval1"],
    )

    #
    # Get coordinates
    #
    lons, lats = euhforia.core.map.get_center_coordinates(m)

    #
    # For each point on map, trace field line and record results
    #
    for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
        for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

            is_open = False

            # If the field line, that has been traced starting from the photosphere/low corona,
            # has its end point high in the corona, (e.g. at the source surface),
            # it is designated an open field line
            # NOTE: assumes j,k of m to be same as j,k of synoptic_trace_map
            if synoptic_trace_map.at_end_pt["r"].data[j, k] >= open_field_threshold_radius:
                is_open = True

            # Compute "connectivity" value
            connectivity_code = (1.0 + float(is_open))*np.sign(synoptic_trace_map.at_start_pt["Br"].data[j, k])

            m.data[j, k] = connectivity_code

    return m
