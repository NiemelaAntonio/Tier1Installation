# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Determines open and closed field lines
"""

import astropy.coordinates
import euhforia.core.constants as constants
import euhforia.core.map
import euhforia.core.util
import numpy as np
import sunpy.map


def compute_flux_tube_expansion_map(synoptic_trace_map, use_radial_field=False):
    """Compute flux tube expansion.

    For a set of field lines, computes their expansion factor.

    Args:
      synoptic_trace_map : trace map traced from the corona downwards
      use_radial_field   : Compute FTE using only radial component

    Returns:
      SunPy Map containing the fte values
    """

    #
    # Initialize map
    #
    m = euhforia.core.map.create_empty_map(
        date=synoptic_trace_map.date,
        deg_per_pixel=synoptic_trace_map.deg_per_pixel,
        crval1=synoptic_trace_map.at_start_pt["Br"].meta["crval1"],
    )

    #
    # Get coordinates
    #
    lons, lats = euhforia.core.map.get_center_coordinates(m)

    #
    # For each point on map, trace field line and record results
    #
    for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
        for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

            # NOTE: assumes j,k of m to be same as j,k of synoptic_trace_map

            # Radial coordinate at start (i.e. high in the corona)
            r_high = synoptic_trace_map.at_start_pt["r"].data[j, k]

            # Radial coordinate at end (i.e. low in the corona)
            r_low = synoptic_trace_map.at_end_pt["r"].data[j, k]

            # Magnetic field strength high in the corona
            Br_high = synoptic_trace_map.at_start_pt["Br"].data[j, k]
            B_high = np.sqrt(
                synoptic_trace_map.at_start_pt["Br"].data[j, k]**2
                + synoptic_trace_map.at_start_pt["Bt"].data[j, k]**2
                + synoptic_trace_map.at_start_pt["Bp"].data[j, k]**2
            )

            # Magnetic field strength low in the corona
            Br_low = synoptic_trace_map.at_end_pt["Br"].data[j, k]
            B_low = np.sqrt(
                synoptic_trace_map.at_end_pt["Br"].data[j, k]**2
                + synoptic_trace_map.at_end_pt["Bt"].data[j, k]**2
                + synoptic_trace_map.at_end_pt["Bp"].data[j, k]**2
            )

            if use_radial_field:
                m.data[j, k] = (abs(Br_low)/(abs(Br_high) + 1e-12))*((r_low/r_high)**2)
            else:
                m.data[j, k] = (B_low/(B_high + 1e-12))*((r_low/r_high)**2)

            if r_low > 1.2*constants.solar_radius:
                m.data[j, k] = None

    # Clean map by averaging out NaNs
    # m.data = euhforia.core.util.replace_nan_with_average(m.data)
    m = sunpy.map.Map(euhforia.core.util.replace_nan_with_average(m.data), m.meta)

    return m
