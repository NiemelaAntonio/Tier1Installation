# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Computing distance to coronal hole boundaries
"""

import astropy.coordinates
import numpy as np

import euhforia.core.constants as constants
import euhforia.core.map


def geodesic_on_sphere(pointA, pointB):
    """Compute angular distance on sphere between two points.

    Computes the central angle of the great circle between the givent two
    points on a sphere.

    Args:
        pointA : (lat, lon), both given in rad
        pointB : (lat, lon), both given in rad

    Returns:
        Central angle in rad

    Notes:
        Uses special case of the Vincenty formula,
        see http://en.wikipedia.org/wiki/Great-circle_distance
    """

    latA, lonA = pointA
    latB, lonB = pointB

    delta_lon = lonA - lonB

    numerator = (np.cos(latB)*np.sin(delta_lon))**2
    numerator += (np.cos(latA)*np.sin(latB) - np.sin(latA)*np.cos(latB)*np.cos(delta_lon))**2
    numerator = np.sqrt(numerator)

    denominator = np.sin(latA)*np.sin(latB) + np.cos(latA)*np.cos(latB)*np.cos(delta_lon)

    central_angle = np.arctan2(numerator, denominator)

    return central_angle


def compute_coronal_hole_edge_list(open_closed_map):
    """Identifies edges of coronal holes and returns their coordinates

    Args:
        open_closed_map : Map of the open and closed regions

    Returns:
        List of coordinate tuples (lat [rad], lon [rad]) of points where an
        edge was found
    """

    lon_edges, lat_edges = euhforia.core.map.get_edge_coordinates(open_closed_map)

    #
    # Latitudinal sweep
    #

    edge_points_lat_sweep = []
    for k, lon in enumerate(euhforia.core.map.get_center_coordinates(open_closed_map)[0]):

        # Data along current longitude
        sliver = abs(open_closed_map.data[:, k])

        # Forward difference
        diff = abs(sliver[1::] - sliver[0:-1])

        for idx in np.where(diff > 0.5)[0]:
            lat = lat_edges[idx + 1]
            edge_points_lat_sweep.append((lat*np.pi/180.0, lon*np.pi/180.0))

    #
    # Longitudinal sweep
    #

    edge_points_lon_sweep = []
    for j, lat in enumerate(euhforia.core.map.get_center_coordinates(open_closed_map)[1]):

        sliver = abs(open_closed_map.data[j, :])

        diff = abs(sliver[1::] - sliver[0:-1])

        for idx in np.where(diff > 0.5)[0]:
            lon = lon_edges[idx + 1]
            edge_points_lon_sweep.append((lat*np.pi/180.0, lon*np.pi/180.0))

    return edge_points_lat_sweep + edge_points_lon_sweep


def compute_distance_to_nearest_coronal_hole_boundary(p, coronal_hole_edge_points):
    """Computes the distance to the nearest coronal hole boundary (CHB)

    Args:
        p : (lat [rad], lon[rad]) tuple of the point
        coronal_hole_edge_points : list of CHB points
    Returns:
        Angular distance to nearest CHB in radians
    """

    ang_dist = np.Inf

    for edge_pt in coronal_hole_edge_points:

        ang_dist_to_edge_pt = geodesic_on_sphere(p, edge_pt)

        ang_dist = min(ang_dist, ang_dist_to_edge_pt)

    return ang_dist


def compute_distance_to_coronal_holes_map(synoptic_trace_map, open_closed_map):
    """Compute map of angular distances to nearest coronal hole.

    Args:
      synoptic_trace_map : Map of field lines traced from the corona downwards
      open_closed_map    : Map of open and closed regions

    Returns:
      SunPy Map containing the distance values
    """

    #
    # Initialize map
    #
    deg_per_pixel = synoptic_trace_map.deg_per_pixel

    m = euhforia.core.map.create_empty_map(
        date=open_closed_map.date, deg_per_pixel=deg_per_pixel, crval1=open_closed_map.meta["crval1"]
    )

    #
    # Get coordinates
    #
    lons, lats = euhforia.core.map.get_center_coordinates(m)

    #
    # Compute coronal hole edge point list
    #
    edge_points = compute_coronal_hole_edge_list(open_closed_map)

    #
    # For each point on map, trace field line and record results
    #
    for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
        for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

            foot_point_lon = synoptic_trace_map.at_end_pt["lon"].data[j, k]*np.pi/180.0
            foot_point_lat = synoptic_trace_map.at_end_pt["lat"].data[j, k]*np.pi/180.0

            m.data[j, k] = compute_distance_to_nearest_coronal_hole_boundary(
                (foot_point_lat, foot_point_lon), edge_points
            )

    return m
