# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""SCS upper coronal magnetic field model.
"""

from euhforia.corona.magnetic_field.potential import solid_harmonic_solver as sh


class SCS(object):
    """Schatten current sheet upper coronal magnetic field model.

    This class acts as a wrapper to the potential field solvers.
    """

    def __init__(self):
        pass

    def __new__(cls, **kwargs):
        return sh.SolidHarmonicPotentialMagneticFieldSolver(model="regular", remove_monopole=False, **kwargs)
