# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Empirical coronal models.
"""

import configparser
import copy
import datetime
import os

import astropy.coordinates
import euhforia.core.constants as constants
import euhforia.core.map
import euhforia.corona.magnetic_field.sscs
import euhforia.corona.magnetic_field.topology as topology
import euhforia.magnetogram.loader
import numexpr as ne
import numpy as np
import sunpy.map
from scipy import ndimage


def compute_wind_speed_map(flux_tube_expansion=None,
                           distance_to_coronal_hole_edge=None,
                           wind_speed_expression=None,
                           **kwargs):
    """Compute wind speed from magnetic field topology.
    """

    #
    # Check sanity of inputs
    #
    if wind_speed_expression is None:
        raise ValueError("Wind speed expression not given")

    if "f" in wind_speed_expression and flux_tube_expansion is None:
        raise ValueError("Wind speed expression contains f but FTE map not provided")

    if "d" in wind_speed_expression and distance_to_coronal_hole_edge is None:
        raise ValueError("Wind speed expression contains d but distance to CH map not provided")

    #
    # Initialize map
    #
    if flux_tube_expansion is not None:
        deg_per_pixel = 360.0/flux_tube_expansion.meta["naxis1"]
        m = euhforia.core.map.create_empty_map(
            bunit="m/s",
            date=flux_tube_expansion.meta["date"],
            deg_per_pixel=deg_per_pixel,
            crval1=flux_tube_expansion.meta["crval1"],
        )
    elif distance_to_coronal_hole_edge is not None:
        deg_per_pixel = 360.0/distance_to_coronal_hole_edge.meta["naxis1"]
        m = euhforia.core.map.create_empty_map(
            bunit="m/s",
            date=distance_to_coronal_hole_edge.meta["date"],
            deg_per_pixel=deg_per_pixel,
            crval1=distance_to_coronal_hole_edge.meta["crval1"],
        )
    else:
        raise ValueError("Both flux tube expansion map and distance to CH map are None")

    #
    # Get coordinates
    #
    lons, lats = euhforia.core.map.get_center_coordinates(m)

    #
    # For each point on map, trace field line and record results
    #
    for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
        for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

            if flux_tube_expansion is not None:
                f = flux_tube_expansion.data[j, k]
            if distance_to_coronal_hole_edge is not None:
                d = distance_to_coronal_hole_edge.data[j, k]

            m.data[j, k] = ne.evaluate(wind_speed_expression)

    return m


class EmpiricalCoronalModel(object):
    """Empirical coronal model.

    This class implements empirical corona models that utilize the
    topology of the coronal magnetic field to infer properties of the plasma,
    such as the flow velocity and density, in the upper corona.
    """

    def __init__(self):

        self.magnetic_field_model = euhforia.corona.magnetic_field.sscs.SSCS()

    def initialize(self, config_file):
        """Initialize the model
        """

        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        self.config_file = config_file

        if self.config.has_option("HeliosphereBoundary", "wind_speed_relation"):
            self.wind_speed_formula = self.config.get("HeliosphereBoundary", "wind_speed_relation")
        else:
            self.wind_speed_formula = "240.0 + 675.0*(1.0+f)**(-0.22)"

    def prepare_magnetogram(self):

        #
        # Retrieve and load magnetogram
        #

        # Get options
        provider = self.config.get("Magnetogram", "provider")
        locator = self.config.get("Magnetogram", "source")
        save_dir = self.config.get("Magnetogram", "data_dir")
        deg_per_pixel = self.config.getfloat("Magnetogram", "degrees_per_pixel")

        magnetogram_loader = euhforia.magnetogram.loader.MagnetogramLoader(provider)

        magnetogram_file = magnetogram_loader.get_file(locator, save_directory=save_dir)

        magnetogram = magnetogram_loader.read(magnetogram_file)

        #
        # Regrid and smooth
        #
        regridded_magnetogram = euhforia.core.map.regrid(magnetogram, deg_per_pixel=deg_per_pixel)

        gaussian_smoothing = self.config.getfloat("Magnetogram", "gaussian_smoothing_sd", fallback=0.0)
        num_smoothings = self.config.getint("Magnetogram", "num_flux_conserving_smoothing_steps", fallback=0)

        if num_smoothings > 0:
            smoothed_magnetogram = euhforia.core.map.smooth(regridded_magnetogram, num_steps=num_smoothings)
        elif gaussian_smoothing > 0.0:
            smoothed_magnetogram = sunpy.map.Map(
                ndimage.gaussian_filter(regridded_magnetogram.data, sigma=gaussian_smoothing),
                regridded_magnetogram.meta,
            )
            # copy.deepcopy(regridded_magnetogram)
            # smoothed_magnetogram.data = ndimage.gaussian_filter(smoothed_magnetogram.data, sigma=gaussian_smoothing)
        else:
            smoothed_magnetogram = regridded_magnetogram

        # Set the smoothed magnetogram as the one to use
        self.magnetogram = smoothed_magnetogram

    def compute_magnetic_field_model(self):

        # Set resolution of model
        self.deg_per_pixel = self.config.getfloat("HeliosphereBoundary", "degrees_per_pixel")

        self.magnetic_field_model.initialize_from_config(self.config_file)

        self.magnetic_field_model.set_magnetogram(self.magnetogram)

        self.magnetic_field_model.compute()

    def trace_field_lines(self):

        self.trace_from_photosphere \
            = self.magnetic_field_model.trace_synoptic(start_radius=1.0025*constants.solar_radius,
                                                       direction="outward",
                                                       deg_per_pixel=self.deg_per_pixel)

        self.trace_from_above \
            = self.magnetic_field_model.trace_synoptic(start_radius=21.49*constants.solar_radius,
                                                       direction="inward",
                                                       deg_per_pixel=self.deg_per_pixel)

    def compute_topology(self):

        self.open_closed_regions = topology.open_closed.compute_open_and_closed_fields(
            self.trace_from_photosphere, 2.5 * constants.solar_radius
        )

        if "f" in self.wind_speed_formula:
            self.flux_tube_expansion = topology.fte.compute_flux_tube_expansion_map(self.trace_from_above)
        else:
            self.flux_tube_expansion = None

        if "d" in self.wind_speed_formula:
            self.distance_to_coronal_hole_edge = topology.compute_distance_to_coronal_holes_map(
                self.trace_from_above, self.open_closed_regions
            )
        else:
            self.distance_to_coronal_hole_edge = None

    def compute_wind_speed(self):

        self.wind_speed = compute_wind_speed_map(
            flux_tube_expansion=self.flux_tube_expansion,
            distance_to_coronal_hole_edge=self.distance_to_coronal_hole_edge,
            wind_speed_expression=self.wind_speed_formula,
        )

    def compute_heliospheric_boundary(self):

        #
        # Initialize maps
        #
        self.heliospheric_boundary = {}
        self.heliospheric_boundary["vr"] = copy.deepcopy(self.wind_speed)
        self.heliospheric_boundary["Br"] = copy.deepcopy(self.wind_speed)
        self.heliospheric_boundary["number_density"] = copy.deepcopy(self.wind_speed)
        self.heliospheric_boundary["temperature"] = copy.deepcopy(self.wind_speed)

        #
        # Get model params
        #
        config = configparser.ConfigParser()
        config.read(self.config_file)

        # Speed to add to empirical speed
        v_add = config.getfloat("HeliosphereBoundary", "speed.add")

        # Max solar wind speed, also = vfast
        v_max = config.getfloat("HeliosphereBoundary", "speed.max")
        # Min solar wind speed
        v_min = config.getfloat("HeliosphereBoundary", "speed.min")

        # Magnetic field when v = vfast, SI
        B_fast_solar_wind = config.getfloat("HeliosphereBoundary", "fast_solar_wind.magnetic_field")*1e-9

        # Number density when v = vfast, SI
        n_fast_solar_wind = config.getfloat("HeliosphereBoundary", "fast_solar_wind.number_density")*1e6

        # Thermal pressure, SI
        P_solar_wind = config.getfloat("HeliosphereBoundary", "solar_wind.pressure")*1e-9

        lons, lats = euhforia.core.map.get_center_coordinates(self.heliospheric_boundary["vr"])

        for j, lat in enumerate(astropy.coordinates.Angle(lats, unit="deg")):
            for k, lon in enumerate(astropy.coordinates.Angle(lons, unit="deg")):

                #
                # Modify wind speed:
                #
                #   1. Subtract a value to account for residual acceleration
                #   2. Limit to be in reasonable range
                #

                v = self.wind_speed.data[j, k] + v_add

                v = min(v, v_max)
                v = max(v, v_min)

                self.heliospheric_boundary["vr"].data[j, k] = v

                #
                # Compute radial magnetic field component
                #
                # The sign of the magnetic field is obtained from the
                # direction of the field line.
                #
                # The magnitude is determined as a function of vr
                #
                Bsign = np.sign(self.trace_from_above.at_end_pt["Br"].data[j, k])
                Br = Bsign * B_fast_solar_wind * (v / v_max)
                self.heliospheric_boundary["Br"].data[j, k] = Br

                #
                # Compute number density
                #
                #  n v^2 = constant => n = const / v^2 = nref (vref/v)^2
                #
                n = n_fast_solar_wind * (v_max / v)**2
                self.heliospheric_boundary["number_density"].data[j, k] = n

                #
                # Compute temperature
                #
                self.heliospheric_boundary["temperature"].data[j, k] = P_solar_wind/(n*constants.kB)

                # Alfven speed:
                # rho = n*0.5*constants.proton_mass

                # vA = Br/np.sqrt(rho*constants.mu0)

                # Sound speed (c_S^2 = P/rho)
                # adiabatic_index = 1.5
                # cS = np.sqrt(adiabatic_index*P_solar_wind/rho)

                # if v*1e3 < (vA + cS):
                #    print "subfast"

        # Convert vr to SI (all others should already be in SI)
        # self.heliospheric_boundary["vr"].data *= 1e3
        self.heliospheric_boundary["vr"] \
            = sunpy.map.Map(self.heliospheric_boundary["vr"].data*1e3,
                            self.heliospheric_boundary["vr"].meta)

        # Transform to Stonyhurst, and rotate to compensate for the fact that
        # the SSCS model does not include rotation

        rotation_angle = self.config.getfloat("HeliosphereBoundary", "rotate")

        for key in self.heliospheric_boundary.keys():

            m = euhforia.core.map.to_stonyhurst(self.heliospheric_boundary[key])

            m = euhforia.core.map.rotate_map_in_longitude(m, rotation_angle, wrap_angle=180.0)

            self.heliospheric_boundary[key] = m

        # Update unit metadata
        self.heliospheric_boundary["vr"].meta["bunit"] = "m/s"
        self.heliospheric_boundary["Br"].meta["bunit"] = "T"
        self.heliospheric_boundary["number_density"].meta["bunit"] = "m$^{-3}$"
        self.heliospheric_boundary["temperature"].meta["bunit"] = "K"

    def save_heliospheric_boundary_to_ascii(self):

        date = self.heliospheric_boundary["vr"].meta["date"]

        if isinstance(date, datetime.datetime):
            date = date.isoformat()

        if self.config.has_option("HeliosphereBoundary", "output_file_name"):
            file_name = self.config.get("HeliosphereBoundary", "output_file_name")
        else:
            file_name = "solar_wind_boundary_" + date + ".dat"

        fp = open(file_name, "w")

        #
        # Write time
        #
        fp.write("Time:\n")
        fp.write(date + "\n")

        #
        # Write coordinates
        #

        fp.write("Radius of sphere:\n")
        fp.write(str(0.1*constants.astronomical_unit) + "\n")

        lons, lats = euhforia.core.map.get_center_coordinates(self.heliospheric_boundary["vr"])

        # Get stricly increasing longitudinal coordinates
        lons_wrap = euhforia.core.map.get_ascending_longitudinal_coordinates(lons)

        clts = (0.5*np.pi - lats*np.pi/180.0)[::-1]

        fp.write("Number of colatitude grid points:\n")
        fp.write(str(len(clts)) + "\n")
        fp.write("Colatitude grid points:\n")
        np.savetxt(fp, clts, encoding="latin1")

        fp.write("Number of longitude grid points:\n")
        fp.write(str(len(lons_wrap)) + "\n")
        fp.write("Longitude grid points:\n")
        np.savetxt(fp, lons_wrap*np.pi/180.0, encoding="latin1")

        #
        # Write variables
        #
        #
        # Save in order: (lon_0, colat_0)
        #                (lon_0, colat_1) etc.

        for key in ["vr", "number_density", "temperature", "Br"]:

            fp.write(str(key) + "\n")
            np.savetxt(fp, np.flipud(self.heliospheric_boundary[key].data).flatten("F"), encoding="latin1")

        fp.close()

    def compute(self):

        self.compute_magnetic_field_model()

        self.trace_field_lines()

        self.compute_topology()

        self.compute_wind_speed()

        self.compute_heliospheric_boundary()

        self.save_heliospheric_boundary_to_ascii()
