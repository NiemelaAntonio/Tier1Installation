#
# Import paths definied in _paths.py if the file exists.
#
try:
    import euhforia._paths
except ImportError:
    pass


#
# Check version numbers
#
from euhforia.core._version import __version__, check_coco_version, version_info

check_coco_version()
