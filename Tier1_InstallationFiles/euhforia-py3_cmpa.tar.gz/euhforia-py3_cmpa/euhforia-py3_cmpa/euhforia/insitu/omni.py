# This file is part of EUHFORIA.
#
# Copyright 2018 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module for accessing OMNI data
"""

import datetime

import numpy as np
import pandas as pd

import ai.cdas


class OMNIData(object):
    """Class providing OMNI solar wind data.
    """

    def __init__(self):

        self.start_time = None
        self.end_time = None

        # Descriptive label for legend
        self.label = "OMNI 5 min"

        #
        # Data
        #
        self.df = None

    def retrieve(self):
        """Downloads/loads data
        """

        # Get the data
        omni_data = ai.cdas.get_data(
            "istp_public",
            "OMNI_HRO_5MIN",
            self.start_time,
            self.end_time,
            ["proton_density", "Vx", "Vy", "Vz", "BX_GSE", "BY_GSE", "BZ_GSE", "flow_speed"],
        )

        # Store as a DataFrame
        self.df = pd.DataFrame.from_dict(omni_data)

        # Rename date
        self.df.rename(columns={"EPOCH_TIME": "date"}, inplace=True)

        # Store bulk speed in SI where bad values have been assigned to NaN
        self.df["flow_speed"] = np.array([v if v != (99999.9) else np.NaN for v in omni_data["FLOW_SPEED,_GSE"]])*1e3

        # Same for number density
        self.df["proton_number_density"] = (
            np.array([n if n != (999.99) else np.NaN for n in omni_data["PROTON_DENSITY"]])*1e6
        )
