# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module for accessing real time spacecraft data
"""

import datetime
import ftplib

import numpy as np
import pandas as pd

import euhforia.core.util as util


class ACERealTimeData(object):
    def __init__(self, save_dir="./"):

        self.resource_name = "sohoftp.nascom.nasa.gov"

        self.start_time = None
        self.end_time = None

        self.save_dir = save_dir

        self.date = []

        self.label = "ACE NRT 1 hr"

        #
        # SWEPAM data
        #

        # Proton number density, m^-3
        self.proton_number_density = None

        # Bulk speed, m/s
        self.bulk_speed = None

        # Ion temperature, K
        self.ion_temperature = None

        # Status of the data
        # self.swepam_data_status    = None

        #
        # MAG data
        #

        # GSM Magnetic field vector components, T
        self.Bx = None
        self.By = None
        self.Bz = None

        # Magnitude of magnetic field, T
        self.magnetic_field_magnitude = None

    def parse_swepam(self, file_name):

        f = open(file_name, "r")

        # Read data. Assume two first lines are extra header
        #
        f.readline()
        f.readline()

        data = np.loadtxt(f)

        f.close()

        # Get dates and times
        #
        year = data[:, 0]
        month = data[:, 1]
        day = data[:, 2]
        HHMM = data[:, 3]

        for idx in range(len(year)):
            hour = "{:0>4d}".format(int(HHMM[idx]))[0:2]
            self.date.append(datetime.datetime(int(year[idx]), int(month[idx]), int(day[idx]), hour=int(hour)))

        # Get variables and convert to SI
        #
        n = np.array(data[:, 7])*1e6
        v = np.array(data[:, 8])*1e3
        T = np.array(data[:, 9])

        # Check for missing values
        #
        n = [x if x != (-9999.9)*1e6 else np.NaN for x in n]
        v = [x if x != (-9999.9)*1e3 else np.NaN for x in v]
        T = [x if x != (-1.00e05) else np.NaN for x in T]

        n = np.array(n)
        v = np.array(v)
        T = np.array(T)

        # Append data
        #
        self.bulk_speed = self.append(self.bulk_speed, v)
        self.ion_temperature = self.append(self.ion_temperature, T)
        self.proton_number_density = self.append(self.proton_number_density, n)
        # self.swepam_data_status    = self.append(self.swepam_data_status, s)

    def parse_mag(self, file_name):

        f = open(file_name, "r")

        # Read data. Assume two first lines are extra header
        #
        f.readline()
        f.readline()

        data = np.loadtxt(f)

        f.close()

        # Get data and convert to SI
        #
        Bx = np.array(data[:, 7])*1e-9
        By = np.array(data[:, 8])*1e-9
        Bz = np.array(data[:, 9])*1e-9

        # Check for missing values
        #
        Bx = [x if x != (-999.9)*1e-9 else np.NaN for x in Bx]
        By = [x if x != (-999.9)*1e-9 else np.NaN for x in By]
        Bz = [x if x != (-999.9)*1e-9 else np.NaN for x in Bz]

        Bx = np.array(Bx)
        By = np.array(By)
        Bz = np.array(Bz)

        B = np.array(np.sqrt(Bx * Bx + By * By + Bz * Bz))

        # Append data
        #
        self.Bx = self.append(self.Bx, Bx)
        self.By = self.append(self.By, By)
        self.Bz = self.append(self.Bz, Bz)
        self.magnetic_field_magnitude = self.append(self.magnetic_field_magnitude, B)

    def append(self, a, b):

        if a is not None:
            a = np.concatenate((a, b))
        else:
            a = b

        return a

    def retrieve(self):

        # TODO: Check that start time and end time have been set

        # Get file list
        #

        ftp = ftplib.FTP()

        ftp.connect(self.resource_name)
        ftp.login("anonymous", "pass")

        file_list = ftp.nlst("sdb/goes/ace/monthly/*.txt")

        ftp.quit()

        # Download and read data
        #
        self.get_instrument_data(file_list, "swepam")
        self.get_instrument_data(file_list, "mag")

        #
        # Finalize data by creating a DataFrame
        #
        data_dict = {
            "date": self.date,
            "flow_speed": self.bulk_speed,
            "proton_number_density": self.proton_number_density,
        }

        self.df = pd.DataFrame.from_dict(data_dict)

    def get_instrument_data(self, file_list, instrument):

        #
        # Find files
        #

        remote_data_files = []

        for f in file_list:

            # Remove leading path
            #
            name = f.split("/")[-1]

            # Get date
            #
            date = name.split("_")[0]

            year = int(date[0:4])
            month = int(date[4::])

            # Get instrument
            #
            instr = name.split("_")[2]

            # Check if year & month correspond to the date and instrument given
            #
            if (self.start_time.year == year) and (self.start_time.month == month) and (instr == instrument):
                remote_data_files.append(f)

            if (self.end_time.year == year) and (self.end_time.month == month) and (instr == instrument):
                remote_data_files.append(f)

        # Remove duplicate entries
        #
        remote_data_files = list(set(remote_data_files))

        # Download files
        #

        local_data_files = []

        for f in remote_data_files:
            local_data_files.append(
                util.download_remote_file(
                    "ftp://" + self.resource_name + "/" + f, save_directory=self.save_dir, replace=True
                )
            )

        # Sort file list according to date
        #
        local_data_files = sorted(local_data_files)

        # Parse data
        #
        for f in local_data_files:

            if instrument == "swepam":
                self.parse_swepam(f)

            if instrument == "mag":
                self.parse_mag(f)
