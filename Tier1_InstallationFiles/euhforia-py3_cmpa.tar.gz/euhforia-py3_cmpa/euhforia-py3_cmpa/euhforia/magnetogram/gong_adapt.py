# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module providing GONG ADAPT magnetogram support.
"""

import datetime
import os
from urllib.request import urlopen

import astropy.units as units
import numpy as np
import sunpy.map
import sunpy.sun


def read(file_name, realization_idx=0):
    """Read a GONG ADAPT FITS file, and return it as a SunPy Map.

    Args:
        file_name       : string of the FITS file name. Files compressed with
                          gzip also supported.
        realization_idx : int (0-11) giving the index of the realization to use.
                          Default=0.

    Returns:
        sunpy.map.Map
    """

    #
    # Read in FITS data
    #
    fits_file = sunpy.io.read_file(file_name)

    # Assumes one dataset in file
    header = dict(fits_file[0][1])
    data = fits_file[0][0][realization_idx]

    if not header["MODEL"] == "ADAPT" or not header["MAPDATA"] == "GONG":
        raise ValueError("Magnetogram does not appear to be a GONG-ADAPT magnetogram.")

    #
    # Add missing metadata
    #

    # Add date & time info
    date_time = datetime.datetime.strptime(header["MAPTIME"], "%Y-%m-%dT%H:%M:%S")

    header["DATE-OBS"] = header["MAPTIME"]
    header["DATE"] = header["MAPTIME"]

    # Add location info
    header["CRLN_OBS"] = sunpy.coordinates.sun.L0(date_time).to(units.deg)
    header["CRLT_OBS"] = sunpy.coordinates.sun.B0(date_time).to(units.deg)

    # NOTE: The above differ slightly from the values given in the file, WHY?
    # header["CRLN_OBS"] = header["MAPLON"]
    # header["CRLT_OBS"] = header["EPHEM_B0"]

    header["CTYPE1"] = "CRLN-CAR"
    header["CTYPE2"] = "CRLT-CAR"

    header["DSUN_OBS"] = sunpy.coordinates.sun.earth_distance(date_time).to(units.m)

    # Add data info
    header["BUNIT"] = "Gauss"
    header["DETECTOR"] = "GONG/ADAPT"

    return sunpy.map.Map((data, header))


def retrieve(date, save_directory="./"):
    """Download a GONG/ADAPT magnetogram.

    Downloads the GONG/ADAPT magnetogram given a date. The appropriate magnetogram
    is selected by first choosing the given day, and then selecting the data file
    that is closest in time to the given time. If the string "latest" is instead
    passed, date is interpreted as the current UTC time.

    Args:
        date           : datetime object
        save_directory : path where to store the file to download
    Returns:
        absolute path of the file that has been downloaded
    """

    if date == "latest":
        date = datetime.datetime.utcnow()

    if date.year < 2012:
        raise ValueError("GONG/ADAPT data not available before 2012")

    # Construct URL of data dir
    dir_name = "ftp://gong2.nso.edu/adapt/maps/gong/"
    dir_name += datetime.datetime.strftime(date, "%Y/")

    # Get file listing
    listing = urlopen(dir_name).read().decode("utf-8").splitlines()
    file_names = [l.split()[-1] for l in listing]

    # Remove CM centered entries
    for f in file_names:
        if "41311" in f:
            file_names.remove(f)

    # Find file closest to the given time
    time_deltas = list()
    for file_name in file_names:
        file_date = datetime.datetime.strptime(file_name.split("_")[2], "%Y%m%d%H%M")
        time_deltas.append((file_date - date).total_seconds())

    file_name = file_names[abs(np.array(time_deltas)).argmin()]

    # Create save directory if it doesn't exist
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)

    # Download file
    file_path = sunpy.util.net.download_file(dir_name + file_name, save_directory, overwrite=True)

    return os.path.abspath(file_path)
