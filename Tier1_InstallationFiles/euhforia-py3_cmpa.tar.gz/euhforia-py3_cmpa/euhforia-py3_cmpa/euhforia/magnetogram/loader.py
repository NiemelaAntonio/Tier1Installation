# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

"""Generic magnetogram loading functionality
"""

import datetime
import importlib
import os

import sunpy.map


class MagnetogramLoader(object):
    """Class providing an interface to retrieveing and loading magnetograms.

    Args:
        provider (str) : Name of magnetogram provider. Currently supported:
                         GONG, GONG_ADAPT
    """

    def __init__(self, provider):

        self.providers = ("GONG", "GONG_ADAPT")

        if provider not in self.providers:
            raise ValueError("Unrecognized or unsupported magnetogram provider")

        # Import module based on the given provider
        module = importlib.import_module("euhforia.magnetogram." + provider.lower())

        # Define the magnetogram retriever and reader functions
        self.retriever = getattr(module, "retrieve")
        self.reader = getattr(module, "read")

    def read(self, file_name):
        """Read magnetogram file

        Reads the magnetogram file using the selected magnetogram provider

        Args:
            file_name (str) : Name of magnetogram file
        """
        return self.reader(file_name)

    def get_file(self, locator, save_directory="./"):
        """Get magnetogram

        Gets a magnetogram based on the provided locator. Following cases are
        supported:
            1. If locator is a URL, the file is downloaded
            2. If locator is a local file, the file is returned
            3. If locator is a date, the file corresponding to the date is downloaded
            4. If locator equals "latest", the most recent magnetogram is downloaded

        Args:
            locator (str) : Descriptor for what to do, see above
            save_directory (str) : Directory where to save any file that is downloaded

        Returns:
            path to the file
        """

        # Is locator a date string?
        try:
            date = datetime.datetime.strptime(str(locator), "%Y-%m-%dT%H:%M:%S")
        except ValueError:
            date = None

        if str(locator).split(":")[0] in ("http", "ftp"):
            # Locator is a URL: download it
            magnetogram_file = sunpy.util.net.download_file(locator, save_directory, overwrite=False)

        elif os.path.isfile(str(locator)):
            # Locator is a local file
            magnetogram_file = locator

        elif date is not None:
            # Locator is a date: find file and download it
            magnetogram_file = self.retriever(date, save_directory=save_directory)

        elif locator == "latest":
            # Locator is a date (now): download most recent file
            magnetogram_file = self.retriever("latest", save_directory=save_directory)

        elif isinstance(locator, datetime.datetime):
            # Locator is a datetime object?
            magnetogram_file = self.retriever(locator, save_directory=save_directory)

        else:
            raise ValueError("Unable to process locator: unrecognized")

        return magnetogram_file
