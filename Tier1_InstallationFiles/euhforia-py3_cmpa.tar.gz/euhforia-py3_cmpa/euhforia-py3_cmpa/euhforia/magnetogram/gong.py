# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

"""Module providing GONG standard synoptic magnetogram support.
"""

import datetime
import os

import astropy.io.fits
import astropy.units as units
import numpy as np
import requests
import sunpy.map
import sunpy.sun
from bs4 import BeautifulSoup


def read(file_name):
    """Read in synoptic magnetogram in FITS format provided by GONG, and return
    it as a SunPy Map.

    Args:
        file_name : name of the FITS file. Files compressed with
                    gzip also supported.

    Returns:
        sunpy.map.Map
    """

    #
    # Read in FITS data
    #
    fits_file = sunpy.io.read_file(file_name)

    # Assumes one dataset in file
    header = fits_file[0][1]
    data = fits_file[0][0]

    meta = dict(header)

    if not meta["TELESCOP"] == "NSO-GONG":
        raise ValueError("Magnetogram does not appear to be a GONG magnetogram.")

    date_time = datetime.datetime.strptime(header["DATE"], "%Y-%m-%dT%H:%M:%S")

    #
    # Correct/add metadata
    #
    meta["DATE-OBS"] = header["DATE"]

    # Provide a more accurate sin latitude step than given in the header
    # This makes the coordinates of the poles to be +-90 instead of
    # +- 89.9 when one uses the given value for cdelt2
    meta["CDELT2"] = 2.0/np.pi

    # Add location info
    meta["CRLN_OBS"] = sunpy.coordinates.sun.L0(date_time).to(units.deg)
    meta["CRLT_OBS"] = sunpy.coordinates.sun.B0(date_time).to(units.deg)
    meta["DSUN_OBS"] = sunpy.coordinates.sun.earth_distance(date_time).to(units.m)

    meta["DETECTOR"] = "GONG standard"

    meta["CUNIT1"] = "deg"
    meta["CUNIT2"] = "deg"

    return sunpy.map.Map((data, meta))


def retrieve(date, save_directory="./"):
    """Download a GONG magnetogram.

    Downloads the GONG magnetogram given a date. The appropriate magnetogram
    is selected by first choosing the given day, and then selecting the
    data file that is closest in time to the given time. If the string "latest"
    is instead passed, date is interpreted as the current UTC time.

    Args:
        date           : datetime object
        save_directory : path where to store the file to download
    Returns:
        absolute path of the file that has been downloaded
    """

    if date == "latest":
        date = datetime.datetime.utcnow()

    if date.year < 2006 or (date.year == 2006 and date.month < 9):
        raise ValueError("GONG data not available before 2006/9")

    dataset_id = "bqs"
    file_id = "mr" + dataset_id

    # Construct URL of data dir
    dir_name = "http://gong.nso.edu/data/magmap/QR/" + dataset_id + "/"
    dir_name += datetime.datetime.strftime(date, "%Y%m/")
    dir_name += file_id + datetime.datetime.strftime(date, "%y%m%d/")

    # Get names of data files in directory
    page_text = requests.get(dir_name).text
    soup = BeautifulSoup(page_text, "html.parser")

    file_names = [node.get("href") for node in soup.find_all("a") if file_id in node.get("href")]

    # Find file closest to the given time
    # NOTE: it is possible that the closest file would actually be from the
    # previous or next day. Not checking for this here.
    time_deltas = list()
    for file_name in file_names:
        file_date = datetime.datetime.strptime(file_name.split("c")[0], file_id + "%y%m%dt%H%M")
        time_deltas.append((file_date - date).total_seconds())

    file_name = file_names[abs(np.array(time_deltas)).argmin()]

    # Create save directory if it doesn't exist
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)

    # Download file
    file_path = sunpy.util.net.download_file(dir_name + file_name, save_directory, overwrite=True)

    return os.path.abspath(file_path)
