# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Orbits of misc. heliospheric objects
"""

import os

import numpy as np
import scipy.interpolate

from . import orbit


class Pluto(object):
    """Class container for orbit of Pluto
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Pluto", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/pluto.npz"
        )


class HEEQ(object):
    """Class container for fixed HEEQ origin
    """

    def __new__(cls):
        return orbit.FixedOrbit(name="HEEQ", position=None)
