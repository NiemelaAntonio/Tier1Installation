# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Orbit utlility classes
"""

import numpy as np
import scipy.interpolate


class TabulatedOrbit(object):
    """Class for computing the position from tabulated orbit data.

    Computes the position of an object in the heliosphere from tabulated
    orbit data.
    """

    def __init__(self, orbit_file=None, name=None, **kwargs):

        self.name = name

        if orbit_file is not None:
            self.load(orbit_file)

    def exists(self, start_date, end_date):
        """Checks whether the orbit exists in the given time window
        """
        return (self.dates[0] < start_date) and (self.dates[-1] > end_date)

    def position(self, date):
        """Compute position of object using spherical coordinates

        Args:
            date (datetime) : Date at which to get the position at
        Returns:
            tuple of r, lat, lon coordinates
        """

        if date >= self.dates[-1] or date <= self.dates[0]:
            return np.Inf, 0.0, 0.0

        # Interpolation point
        dt = (date - self.dates[0]).total_seconds()

        # Interpolate monotonic longitude
        monotonic_lon = self.monotonic_lon_interpolator(dt)

        # Wrap to [-pi, pi]
        lon = self.wrap(monotonic_lon)

        # Return interpolated position
        return self.r_interpolator(dt), self.lat_interpolator(dt), lon

    def wrap(self, lon):
        """Wrap coordinate to be in [-pi, pi]
        """
        return ((lon + np.pi) % (2*np.pi)) - np.pi

    def load(self, file_name):
        """Load tabulated orbit data

        The npz-file is assumed to contain r, lat, lon coordinates at the given
        dates.

        Args:
            file_name (str) : Name of orbit file
        """

        # Load data
        data = np.load(file_name, encoding="bytes", allow_pickle=True)

        # Store data values
        self.dates = data["dates"]
        self.r = data["r"]
        self.lat = data["lat"]
        self.lon = data["lon"]

        #
        # Create interpolators
        # Time is converted to a number by computing time from first data
        # point
        dt = np.zeros(len(self.dates))

        for idx, d in enumerate(self.dates):
            dt[idx] = (d - self.dates[0]).total_seconds()

        # Construct interpolators
        self.r_interpolator = scipy.interpolate.interp1d(dt, self.r)
        self.lat_interpolator = scipy.interpolate.interp1d(dt, self.lat)

        #
        # Longitude requires extra care due to the periodicity which will
        # cause erraneous interpolation at periodic points. This is cicumvented
        # by transfroming the periodic longitude to a monotonicly increasing
        # or decreasing function by suitably adding multiples of 2 pi to the
        # angle
        #

        # Detect discontinous points
        offset = np.copy(self.lon)
        offset[1::] = self.lon[1::] - self.lon[0:-1]

        offset[np.where(abs(offset) < 4.0)] = 0.0

        # Determine multiple of 2 pi
        for count, idx in enumerate(np.where(abs(offset) > 4.0)[0]):
            offset[idx::] = count + 1

        offset *= 2.0*np.pi

        self.monotonic_lon_interpolator = scipy.interpolate.interp1d(dt, self.lon + offset)


class FixedOrbit(object):
    """Class representing a virtual spacecraft that remains in a fixed position.
    """

    def __init__(self, name=None, position=None, **kwargs):

        self.name = name

        if position is None:
            self.pos = np.array((0.0, 0.0, 0.0))
        else:
            self.pos = np.asarray(position)

    def position(self, date):
        """Computes position of object

        Args:
            date (datetime) : Date at which to get the position of the SC
        Returns:
            tuple of r, lat, lon coordinates
        """

        return self.pos

    def exists(self, start_date, end_date):
        """Checks whether the orbit exists in the given time window
        """
        return True


class RelativeOrbit(object):
    """Class for getting the position of a virtual spacecraft relative to another object.
    """

    def __init__(self, name=None, obj_relative_to=None, shift=None, **kwargs):

        self.name = name

        # Inject base object
        self.base_object = obj_relative_to

        if shift is None:
            self.shift = np.array((0.0, 0.0, 0.0))
        else:
            self.shift = np.asarray(shift)

    def position(self, date):
        """Computes position of object

        Args:
            date (datetime) : Date at which to get the position of the SC
        Returns:
            tuple of r, lat, lon coordinates
        """

        r, lat, lon = self.base_object.position(date)

        r += self.shift[0]
        lat += self.shift[1]
        lon += self.shift[2]

        return r, lat, lon

    def exists(self, start_date, end_date):
        """Checks whether the orbit exists in the given time window
        """
        return self.base_object.exists(start_date, end_date)
