# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Orbits of spacecraft
"""

import os

import numpy as np
import scipy.interpolate

from . import orbit


class STA(object):
    """Class container for orbit of STEREO-AHEAD
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="STA", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/sta.npz"
        )


class STB(object):
    """Class container for orbit of STEREO-BEHIND
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="STB", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/stb.npz"
        )
