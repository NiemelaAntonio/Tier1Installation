# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Orbits of planets
"""

import os

import numpy as np
import scipy.interpolate

from . import orbit


class Mercury(object):
    """Class container for orbit of Mercury
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Mercury", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/mercury.npz"
        )


class Venus(object):
    """Class container for orbit of Venus
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Venus", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/venus.npz"
        )


class Earth(object):
    """Class container for orbit of Earth
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Earth", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/earth.npz"
        )


class Mars(object):
    """Class container for orbit of Mars
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Mars", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/mars.npz"
        )


class Jupiter(object):
    """Class container for orbit of Jupiter
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Jupiter", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/jupiter.npz"
        )


class Saturn(object):
    """Class container for orbit of Saturn
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Saturn", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/saturn.npz"
        )


class Uranus(object):
    """Class container for orbit of Uranus
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Uranus", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/uranus.npz"
        )


class Neptune(object):
    """Class container for orbit of Neptune
    """

    def __new__(cls):
        return orbit.TabulatedOrbit(
            name="Neptune", orbit_file=os.path.dirname(os.path.realpath(__file__)) + "/orbit_data/neptune.npz"
        )
