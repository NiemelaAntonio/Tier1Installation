# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.


"""Module for plotting slices of the 3D output data.
"""

import matplotlib
import matplotlib.patches
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np
import scipy.interpolate

import coco.core.grid
import euhforia.core.constants as constants

from . import marker


def equatorial(d, variable, **kwargs):
    """Plot data in heliographic equatorial plane
    """

    #
    # Compute data in equatorial plane
    #

    # Create interpolator to data
    element_type = coco.core.grid.get_element_type(d.grid, d.data[variable])
    interpolator = scipy.interpolate.RegularGridInterpolator(
        d.grid.get_coordinates(element_type), d.data[variable], method="linear"
    )

    # Define interpolation points
    r = kwargs.get("radial_coordinates", np.linspace(0.1, 2.0, 256)*constants.astronomical_unit)
    r = np.unique(np.clip(r, d.grid.indomain_edge_coords.r[0], d.grid.indomain_edge_coords.r[-1]))

    clt = 0.5*np.pi

    lon = d.grid.indomain_edge_coords.lon

    # Array of points for RegularGridInterpolator
    interpolation_coordinates = np.vstack(np.meshgrid(r, clt, lon, indexing="ij")).reshape(3, -1).T

    # Interpolate
    interpolated_data = interpolator(interpolation_coordinates).reshape((len(r), len(lon)))

    # Compute x,y coordinates of plot
    r_plot = r/constants.astronomical_unit

    rmesh, lonmesh = np.meshgrid(r_plot, lon, indexing="ij")

    x = rmesh * np.cos(lonmesh)
    y = rmesh * np.sin(lonmesh)

    #
    # Plot
    #

    # Figure handles
    fig = kwargs.get("fig", None)
    if fig is None:
        fig = plt.figure(figsize=kwargs.get("figsize", (11, 6)))

    ax = kwargs.get("ax", None)
    if ax is None:
        ax = fig.add_subplot(1, 1, 1)

    # Contour levels
    levels = get_contour_levels(kwargs.get("levels", None), interpolated_data)

    # Create the contour plot
    cax = ax.contourf(x, y, interpolated_data, levels, cmap=kwargs.get("cmap", "plasma"), extend="both")
    ax.tick_params(axis='y', labelsize=12)
    ax.tick_params(axis='x', labelsize=12)

    # Add colorbar
    if kwargs.get("colorbar", True):

        locator = matplotlib.ticker.MaxNLocator(8, min_n_ticks=1)
        default_ticks = locator.tick_values(levels[0], levels[-1])

        cbar = fig.colorbar(cax, ax=ax, ticks=kwargs.get("colorbar_ticks", default_ticks))
        cbar.ax.tick_params(labelsize=24)

    #
    # Add guides
    #

    if kwargs.get("guides", True):

        options = {"color": kwargs.get("guide_color", "0.35"), "alpha": 0.5}

        r_min = r_plot[0]
        r_max = r_plot[-1]

        # Draw circles at given radial coordinates
        circle_radii = np.asarray(kwargs.get("circle_radii", (1.0, 2.0)))

        for circle_radius in circle_radii[(circle_radii >= r_min) & (circle_radii <= r_max)]:
            circle = plt.Circle((0.0, 0.0), radius=circle_radius, fill=False, **options)
            ax.add_patch(circle)

        # Draw dashed circles at given radial coordinates
        dashed_circle_radii = np.asarray(kwargs.get("dashed_circle_radii", (0.5, 1.5)))

        for circle_radius in dashed_circle_radii[(dashed_circle_radii >= r_min) & (dashed_circle_radii <= r_max)]:
            circle = plt.Circle((0.0, 0.0), radius=circle_radius, fill=False, ls="dashed", **options)
            ax.add_patch(circle)

        # Draw y = 0 line
        line = plt.Line2D((-r_max, r_max), (0.0, 0.0), **options)
        ax.add_line(line)

        # Draw x = 0 line
        line = plt.Line2D((0.0, 0.0), (-r_max, r_max), **options)
        ax.add_line(line)

        # Draw lon = 45 deg diagonal line
        line = plt.Line2D(
            (-r_max/np.sqrt(2.0), r_max/np.sqrt(2.0)), (-r_max/np.sqrt(2.0), r_max/np.sqrt(2.0)), **options
        )
        ax.add_line(line)

        # Draw lon = -45 deg diagonal line
        line = plt.Line2D(
            (-r_max/np.sqrt(2.0), r_max/np.sqrt(2.0)), (r_max/np.sqrt(2.0), -r_max/np.sqrt(2.0)), **options
        )
        ax.add_line(line)

        # Cover the lines above in the middle
        circle = plt.Circle((0.0, 0.0), radius=r_min, color="w", fill=True, zorder=4)
        ax.add_patch(circle)

    ax.set_aspect("equal")

    ax.set_xlabel("$x$ [HEEQ AU]",fontsize=16)
    ax.set_ylabel("$y$ [HEEQ AU]",fontsize=16)

    if kwargs.get("write_date", True):
        ax.text(0.01, 1.025, "{0: <40}".format(d.datetime.item(0).strftime("%Y-%m-%d %H:%M")), fontsize=16, transform=ax.transAxes)

    if kwargs.get("colorbar", True):

        unit_str = str("  [" + d.units[variable] + "]") if d.units[variable] is not None else ""

        colorbar_default_label = str(variable) + unit_str

        cbar.ax.set_ylabel(kwargs.get("colorbar_label", colorbar_default_label), labelpad=10.0, labelsize=16)
        cbar.ax.tick_params(labelsize=24)

    return fig, ax, cax


def meridional(d, variable, lon=0.0, **kwargs):
    """Plot data in a meridional plane
    """

    #
    # Compute data in meridional plane
    #

    # Create interpolator to data
    element_type = coco.core.grid.get_element_type(d.grid, d.data[variable])
    interpolator = scipy.interpolate.RegularGridInterpolator(
        d.grid.get_coordinates(element_type), d.data[variable], method="linear"
    )

    # Define interpolation points
    r = kwargs.get("radial_coordinates", np.linspace(0.1, 2.0, 256)*constants.astronomical_unit)
    r = np.unique(np.clip(r, d.grid.indomain_edge_coords.r[0], d.grid.indomain_edge_coords.r[-1]))

    clt = d.grid.indomain_edge_coords.clt
    #print(d.grid.get_coordinates(element_type))
    # Wrap longitude
    if lon > d.grid.indomain_edge_coords.lon[-1]:
        lon -= 2.0*np.pi
    if lon < d.grid.indomain_edge_coords.lon[0]:
        lon += 2.0*np.pi

    # Array of points for RegularGridInterpolator
    interpolation_coordinates = np.vstack(np.meshgrid(r, clt, lon, indexing="ij")).reshape(3, -1).T

    # Interpolate
    interpolated_data = interpolator(interpolation_coordinates).reshape((len(r), len(clt)))

    # Compute x,y coordinates of plot
    r_plot = r/constants.astronomical_unit

    rmesh, cltmesh = np.meshgrid(r_plot, clt, indexing="ij")

    x = rmesh*np.sin(cltmesh)
    y = rmesh*np.cos(cltmesh)

    #
    # Plot
    #

    # Figure handles
    fig = kwargs.get("fig", None)
    if fig is None:
        fig = plt.figure(figsize=kwargs.get("figsize", (11, 6)))

    ax = kwargs.get("ax", None)
    if ax is None:
        ax = fig.add_subplot(1, 1, 1)

    levels = get_contour_levels(kwargs.get("levels", None), interpolated_data)

    # Plot contour
    cax = ax.contourf(x, y, interpolated_data, levels, cmap=kwargs.get("cmap", "plasma"), extend="both")
    ax.tick_params(axis='y', labelsize=12)
    ax.tick_params(axis='x', labelsize=12)
    # Add colorbar
    if kwargs.get("colorbar", True):

        locator = matplotlib.ticker.MaxNLocator(8, min_n_ticks=1)
        default_ticks = locator.tick_values(levels[0], levels[-1])

        cbar = fig.colorbar(cax, ax=ax, ticks=kwargs.get("colorbar_ticks", default_ticks))
        cbar.ax.tick_params(labelsize=24)

    #
    # Add guides
    #

    if kwargs.get("guides", True):

        options = {"color": kwargs.get("guide_color", "0.35"), "alpha": 0.5}

        r_min = r_plot[0]
        r_max = r_plot[-1]

        # Draw arcs at given radial coordinates
        circle_radii = np.asarray(kwargs.get("circle_radii", (1.0, 2.0)))

        for circle_radius in circle_radii[(circle_radii >= r_min) & (circle_radii <= r_max)]:
            arc = matplotlib.patches.Arc(
                (0.0, 0.0),
                width=2.0*circle_radius,
                height=2.0*circle_radius,
                angle=0.0,
                theta1=90.0 - d.grid.indomain_edge_coords.clt[-1]*180.0/np.pi,
                theta2=90.0 - d.grid.indomain_edge_coords.clt[0]*180.0/np.pi,
                fill=False,
                **options
            )
            ax.add_patch(arc)

        # Draw dashed arcs at given radial coordinates
        dashed_circle_radii = np.asarray(kwargs.get("dashed_circle_radii", (0.5, 1.5)))

        for circle_radius in dashed_circle_radii[(dashed_circle_radii >= r_min) & (dashed_circle_radii <= r_max)]:
            arc = matplotlib.patches.Arc(
                (0.0, 0.0),
                width=2.0*circle_radius,
                height=2.0*circle_radius,
                angle=0.0,
                theta1=90.0 - d.grid.indomain_edge_coords.clt[-1]*180.0/np.pi,
                theta2=90.0 - d.grid.indomain_edge_coords.clt[0]*180.0/np.pi,
                fill=False,
                ls="dashed",
                **options
            )
            ax.add_patch(arc)

        # Draw line of heliographic equator
        line = plt.Line2D((r_min, r_max), (0.0, 0.0), **options)
        ax.add_line(line)

        # Draw line 30 deg to North from heliographic equator
        line = plt.Line2D(
            (r_min*np.cos(30.0*np.pi/180.0), r_max*np.cos(30.0*np.pi/180.0)),
            (r_min*np.sin(30.0*np.pi/180.0), r_max*np.sin(30.0*np.pi/180.0)),
            **options
        )
        ax.add_line(line)

        # Draw line 30 deg to South from heliographic equator
        line = plt.Line2D(
            (r_min*np.cos(-30.0*np.pi/180.0), r_max*np.cos(-30.0*np.pi/180.0)),
            (r_min*np.sin(-30.0*np.pi/180.0), r_max*np.sin(-30.0*np.pi/180.0)),
            **options
        )
        ax.add_line(line)

    ax.set_ylim((-r_plot[-1], r_plot[-1]))

    ax.set_aspect("equal")

    if np.isclose(lon, 0.0):
        ax.set_xlabel("$x$ [HEEQ AU]",fontsize=16)
    else:
        ax.set_xlabel("$\mathrm{Distance}$ [AU]",fontsize=16)

    ax.set_ylabel("$z$ [HEEQ AU]",fontsize=16)

    if kwargs.get("write_date", True):
        ax.text(0, 1.025, "{0: <40}".format(d.datetime.item(0).strftime("%Y-%m-%d %H:%M")), fontsize=16, transform=ax.transAxes)

    if kwargs.get("colorbar", True):

        unit_str = str("  [" + d.units[variable] + "]") if d.units[variable] is not None else ""
        colorbar_default_label = str(variable) + unit_str

        cbar.ax.set_ylabel(kwargs.get("colorbar_label", colorbar_default_label), labelpad=10.0)
        cbar.ax.tick_params(labelsize=24)

    return fig, ax, cax


def equatorial_and_meridional(d, variable, meridional_slice, levels, **kwargs):
    """Plot equatorial and meridional plane in same figure
    """

    #
    # Create figure
    #
    fig = kwargs.get("fig", None)
    if fig is None:
        fig = plt.figure(figsize=kwargs.get("figsize", (10, 5.5)))

    ax = kwargs.get("ax", None)
    if ax is None:
        gs = matplotlib.gridspec.GridSpec(1, 2, width_ratios=[1.38, 1.0])
        ax1 = plt.subplot(gs[0])
        ax2 = plt.subplot(gs[1])
    else:
        ax1 = ax[0]
        ax2 = ax[1]

    cmap = kwargs.get("cmap", "plasma")
    colorbar_ticks = kwargs.get("colorbar_ticks", None)
    #cbar_tick_size = kwargs.get("colorbar_ticks_size", cbar_tick_size)

    #
    # Equatorial plot
    #
    fig, ax1, cax = equatorial(
        d,
        variable,
        fig=fig,
        ax=ax1,
        levels=levels,
        cmap=cmap,
        colorbar=False,
        write_date=kwargs.get("write_date", True),
    )

    #
    # Meridional plot
    #
    fig, ax2, cax = meridional(
        d, variable, fig=fig, ax=ax2, lon=meridional_slice, levels=levels, cmap=cmap, colorbar=False, write_date=False
    )

    # ax2.set_xlim((0.0, 1.0));

    #
    # Add colorbar
    #
    cbar = fig.colorbar(cax, ax=ax2, pad=0.1, ticks=colorbar_ticks, fraction=0.08, extend="both") #default fraction=0.06

    unit_str = str("  [" + d.units[variable] + "]") if d.units[variable] is not None else ""
    cbar.ax.set_ylabel(str(variable) + unit_str, labelpad=10.0)

    #
    # Add planets and SC
    #
    heliospheric_objects = kwargs.get("heliospheric_objects", [])

    for obj in heliospheric_objects:

        r, lat, lon = obj.position(d.datetime)

        # Don't plot if object is further than outer boundary of data
        if r > max(d.grid.domain.r):
            continue

        ax1.plot(
            r * np.cos(lon) / constants.astronomical_unit,
            r * np.sin(lon) / constants.astronomical_unit,
            "o",
            label=obj.name,
            markersize=7,
            marker=marker.style[obj.name]["marker"],
            color=marker.style[obj.name]["color"],
        )

        if kwargs.get("show_legend", True):
            ax1.legend(loc="lower center", bbox_to_anchor=(0.5, -0.23), ncol=4, numpoints=1, fancybox=True, fontsize=7)

        if np.isclose(lon, meridional_slice):
            ax2.plot(
                r*np.cos(lat)/constants.astronomical_unit,
                r*np.sin(lat)/constants.astronomical_unit,
                "o",
                label=obj.name,
                markersize=7,
                marker=marker.style[obj.name]["marker"],
                color=marker.style[obj.name]["color"],
            )

    return fig, ax1, ax2


def get_contour_levels(levels, data):
    """Determine contour levels for slice plots
    """

    if levels is None:
        locator = matplotlib.ticker.MaxNLocator(7 + 1, min_n_ticks=1)
        lev = locator.tick_values(data.min(), data.max())
        levels = np.linspace(lev[0], lev[-1], 64)
    elif isinstance(levels, (list, tuple, np.ndarray)):
        levels = np.asarray(levels)
    else:
        num_levels = int(levels)

        locator = matplotlib.ticker.MaxNLocator(num_levels + 1, min_n_ticks=1)
        lev = locator.tick_values(data.min(), data.max())
        levels = np.linspace(lev[0], lev[-1], num_levels)

    return levels
