Installation quick guide
========================

 1. Compile pyFISHPACK:

    * cd external/pyfishpack
    * make (edit the Makefile if needed)

 2. Compile EUHFORIA files

    * make -f makefiles/name_of_suitable_make_file
