#!/bin/bash
#Author: Anwesha Maharana
#An example file to process EUHFORIA 3D files into vtr, dat and plt formats, and also create the standard EUHFORIA visualisations
#Execute this after logging into wICE

for i in {try_run,} #Add all the simulation names to be processed
do
        echo $i

NAME=$i 

# defining run name string
WORK_DIR=$VSC_SCRATCH/euhforia_events/$NAME/heliosphere #location where .npz files are stored
TOOL_DIR=$VSC_DATA/euhforia_2023/euhforia/run # where this file (postprocess_euhforia.sh) exists; create_plots.py exists

###################---------------- Loading euhforia modules ----------------###################
source ~/.bashrc #Load the relevant EUHFORIA modules
###################---------------------- Merging NPZs ----------------------###################
merge_from=$WORK_DIR/
mkdir -p $WORK_DIR/merged
merge_to=$WORK_DIR/merged

cd /apps/leuven/skylake/2018a/software/Euhforia-GUI/euhforia/tools/ #Change the path to the tools folder 
./merge_npz.py $merge_from/*.npz --output_dir $merge_to/ 

echo $pwd

if [ $? -eq 0 ]; then
    echo NPZs merged successfully.
    rm -r $merge_from/*.npz #removes the unmerged npz files
else
    echo NPZs could not be merged.
fi

#Create standard EUHFORIA pngs
$VSC_DATA/euhforia/run/create_plots.py $WORK_DIR/merged/*.npz --output_dir $WORK_DIR/

#The following is also a possibility
#/apps/leuven/skylake/2018a/software/Euhforia-GUI/euhforia/run/create_plots.py $WORK_DIR/merged/*.npz --output_dir $WORK_DIR/


'''
###################-------------------- Making vtk files ---------------------###################
convert_from=$WORK_DIR/merged

convert_to=$WORK_DIR/merged

#Tool available in /apps/leuven/skylake/2018a/software/Euhforia-GUI/euhforia/tools/
./convert_to_vtk.py $convert_from/*.npz --output_dir $convert_to/

if [ $? -eq 0 ]; then
    echo VTKs made successfully.
    cd $convert_to
    ls *.vtr>>files.visit
else
    echo VTKs could not be made.
fi
'''

'''
echo "Making dat files"
###################---------------------- Making dat files -------------------###################
mkdir -p $WORK_DIR/dat
cd $TOOL_DIR/
./convert_to_dat.py $WORK_DIR/merged/*.npz --output_dir $WORK_DIR/dat/
###################-------------------- Making plt files ---------------------###################

module purge
module load Tecplot

FILES=$WORK_DIR/dat/*.dat

# prepare for tecplot visualization
for f in $FILES
do
  echo "Processing $f file..."
  preplot $f ${f%.dat}.plt
  rm $f
  #cp "$f" "${f%.dat.plt}.plt"
  #preplot "${f%.dat.plt}.plt" "${f%.dat.plt}.plt"
  #preplot $f change something
  # take action on each file. $f store current file name
  #cat $f
done
'''

done

