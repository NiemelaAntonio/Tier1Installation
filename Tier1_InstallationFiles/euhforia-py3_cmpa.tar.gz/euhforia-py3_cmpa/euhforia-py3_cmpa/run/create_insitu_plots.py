#!/usr/bin/env python

import argparse
import datetime
import glob
import os
import re
import sys

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import gridspec
from pandas.plotting import register_matplotlib_converters

BLIND_PALETTE = {
    "orange": (0.901960784, 0.623529412, 0.0),
    "sky-blue": (0.337254902, 0.705882353, 0.91372549),
    "bluish-green": (0.0, 0.619607843, 0.450980392),
    "yellow": (0.941176471, 0.894117647, 0.258823529),
    "blue": (0.0, 0.447058824, 0.698039216),
    "vermillion": (0.835294118, 0.368627451, 0.0),
    "reddish-purple": (0.8, 0.474509804, 0.654901961),
}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("files", type=str, nargs="*", help="files to process")
    parser.add_argument("--output_dir", type=str, help="directory where plots are saved")
    args = parser.parse_args()
    if len(args.files) == 0:
        parser.print_help()
        exit()
    data_dir = os.path.dirname(os.path.abspath(args.files[0]))

    major = mdates.DayLocator()
    minor = mdates.HourLocator(byhour=(0, 6, 12, 18))
    majorFormat = mdates.DateFormatter("%m-%d")
    register_matplotlib_converters()

    for idx, f in enumerate(args.files):
        name_list = os.path.splitext(os.path.basename(f))[0].split("_")
        vantage_point = name_list.pop()
        run_id = "_".join(name_list)

        df = pd.read_csv(f, sep="\\s+", parse_dates=["date"])
        if len(df.index) == 0:
            continue
        output_cadence = (df["date"] - df["date"].shift()).median().seconds / 60.0

        fig = plt.figure(figsize=(8, 12))
        gs = gridspec.GridSpec(5, 1)
        plt.subplots_adjust(hspace=0.001)

        ax = fig.add_subplot(gs[0])
        ax.plot(df["date"], np.sqrt(df["Br[nT]"]**2 + df["Bclt[nT]"]**2 + df["Blon[nT]"]**2), "k", linewidth=1)
        ax.set_ylabel("|B| [nT]")
        ax.set_title(vantage_point)

        ax = fig.add_subplot(gs[1])
        ax.plot(df["date"], df["Br[nT]"], linewidth=1, color=BLIND_PALETTE["vermillion"], label="$B_r$")
        ax.plot(df["date"], df["Bclt[nT]"], linewidth=1, color=BLIND_PALETTE["bluish-green"], label="$B_{clt}$")
        ax.plot(df["date"], df["Blon[nT]"], linewidth=1, color=BLIND_PALETTE["blue"], label="$B_{lon}$")
        ax.legend(loc="upper right", prop={"size": 9}, framealpha=1)
        ax.set_ylabel("B [nT]")

        ax = fig.add_subplot(gs[2])
        ax.plot(
            df["date"], np.sqrt(df["vr[km/s]"]**2 + df["vclt[km/s]"]**2 + df["vlon[km/s]"]**2), "k", linewidth=1
        )
        ax.set_ylabel("|V| [km/s]")

        ax = fig.add_subplot(gs[3])
        ax.plot(df["date"], df["n[1/cm^3]"], "k", linewidth=1)
        ax.set_ylabel("n [1/cm^3]")

        ax = fig.add_subplot(gs[4])
        ax.plot(df["date"], df["P[Pa]"], "k", linewidth=1)
        ax.set_ylabel("P [Pa]")
        ax.set_xlabel("time [UTC]")

        for i, ax in enumerate(fig.axes):
            ax.xaxis.set_major_locator(major)
            ax.xaxis.set_major_formatter(majorFormat)
            ax.xaxis.set_minor_locator(minor)
            ax.yaxis.set_label_coords(-0.08, 0.5)
            ax.autoscale(enable=True, axis="x", tight=True)
            ax.tick_params(which="both", direction="in", top=True, right=True)
            ax.annotate("(" + chr(i + 97) + ")", xy=(0.03, 0.8), xycoords="axes fraction")
            if i < len(fig.axes) - 1:
                ax.axes.xaxis.set_ticklabels([])

        fig.savefig(os.path.join(args.output_dir, run_id + "_" + vantage_point + ".png"), dpi=200)
        plt.close()
