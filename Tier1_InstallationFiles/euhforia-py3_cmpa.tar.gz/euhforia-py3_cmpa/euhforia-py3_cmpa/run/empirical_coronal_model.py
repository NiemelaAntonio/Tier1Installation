#!/usr/bin/env python
#
# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

import argparse
import os

import euhforia
import euhforia.core.constants as constants
import euhforia.corona.empirical
import euhforia.plot.synoptic
from matplotlib import pyplot as plt

if __name__ == "__main__":

    #
    # Parse command line arguments
    #
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--config-file", default="corona_default.cfg", type=str, help="Configuration file (default: %(default)s)"
    )
    parser.add_argument("--create-plots", action="store_true")

    args = parser.parse_args()

    #
    # Compute the model
    #
    print("Empirical Coronal model using configuration file: " + args.config_file)
    print("------------------------------------------------")

    # Instantiate the model, use the provided config file for setup
    coronal_model = euhforia.corona.empirical.EmpiricalCoronalModel()

    # Initialize the model
    coronal_model.initialize(config_file=args.config_file)

    # Prepare the magnetogram
    coronal_model.prepare_magnetogram()

    # Compute the model
    coronal_model.compute()

    # Save the plots
    if args.create_plots:
        basepath = os.path.splitext(coronal_model.config.get("HeliosphereBoundary", "output_file_name"))[0]

        coronal_model.magnetogram.plot_settings["norm"] = plt.Normalize(-20, 20)
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.magnetogram)
        fig.savefig(basepath + "-magnetogram.png", dpi=fig.dpi)

        coronal_model.open_closed_regions.plot_settings["cmap"] = "RdBu"
        coronal_model.open_closed_regions.plot_settings["norm"] = plt.Normalize(-2.5, 2.5)
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.open_closed_regions)
        fig.savefig(basepath + "-open_and_closed_field_regions.png", dpi=fig.dpi)

        coronal_model.flux_tube_expansion.plot_settings["norm"] = plt.Normalize(0, 100)
        coronal_model.flux_tube_expansion.plot_settings["cmap"] = "afmhot"
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.flux_tube_expansion)
        fig.savefig(basepath + "-expansion_factor.png", dpi=fig.dpi)

        Br, Bt, Bp = coronal_model.magnetic_field_model.pfss.get_synoptic_map(constants.solar_radius)
        Br.plot_settings["norm"] = plt.Normalize(-30, 30)
        fig, ax = euhforia.plot.synoptic.plot(Br)
        fig.savefig(basepath + "-field_lower_boundary.png", dpi=fig.dpi)

        coronal_model.heliospheric_boundary["vr"].plot_settings["norm"] = plt.Normalize(250e3, 750e3)
        coronal_model.heliospheric_boundary["vr"].plot_settings["cmap"] = "RdYlGn_r"
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.heliospheric_boundary["vr"])
        fig.savefig(basepath + "-radial_velocity.png", dpi=fig.dpi)

        coronal_model.heliospheric_boundary["number_density"].plot_settings["norm"] = plt.Normalize(0, 1e9)
        coronal_model.heliospheric_boundary["number_density"].plot_settings["cmap"] = "Purples"
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.heliospheric_boundary["number_density"])
        fig.savefig(basepath + "-number_density.png", dpi=fig.dpi)

        coronal_model.heliospheric_boundary["Br"].plot_settings["cmap"] = "RdBu_r"
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.heliospheric_boundary["Br"])
        fig.savefig(basepath + "-radial_field.png", dpi=fig.dpi)

        coronal_model.heliospheric_boundary["temperature"].plot_settings["cmap"] = "Spectral_r"
        fig, ax = euhforia.plot.synoptic.plot(coronal_model.heliospheric_boundary["temperature"])
        fig.savefig(basepath + "-temperature.png", dpi=fig.dpi)
