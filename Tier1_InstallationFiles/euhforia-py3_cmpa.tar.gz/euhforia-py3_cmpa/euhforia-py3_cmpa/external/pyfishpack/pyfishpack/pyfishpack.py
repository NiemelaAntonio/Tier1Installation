# This file is part of pyFISHPACK.
#
# Copyright 2016, 2017 Jens Pomoell, Erkka Lumme
#
# pyFISHPACK is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# pyFISHPACK is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with pyFISHPACK. If not, see <http://www.gnu.org/licenses/>.


"""pyFISHPACK interface to FISHPACK routines.
"""

import collections

import namedlist
import scipy as sp

# Import FISHPACK routines
from . import hw3crt, hwscrt, hwsssp


class HelmholtzSolver(object):
    """Helmholtz PDE solver.

    Solves the [Helmholtz equation](https://en.wikipedia.org/wiki/Helmholtz_equation)
    for various geometries, dimensions and methods.

    Attributes:
        geometry   :  Geometry of the problem ("cartesian"/"cylindrical"/"spherical")
        dim        :  Dimensionality of the problem ("2D"/"3D")
        colocation :  Location of the data with respect to the grid points
                      ("centered"/"staggered")
        rhs        :  Array containing the possibly non-zero right hand side of
                      equation
        lam        :  Helmholtz eq. constant (k^2 in wiki equation definition)
    """

    def __init__(self, **kwargs):

        self.geometry = kwargs.get("geometry", "cartesian")
        self.dimensions = kwargs.get("dim", "2D")
        self.colocation = kwargs.get("colocation", "centered")

        self.num_dims = int(self.dimensions[0])

        #
        # Identify solver by constructing a string from the given options
        #
        solverstr = "_" + str(self.geometry) + "_" + str(self.dimensions) + "_" + str(self.colocation)

        if hasattr(self, solverstr):
            self.solver = getattr(self, solverstr)
        else:
            raise AttributeError("Solver matching the given options not available")

        # RHS of Helmholt eq.
        self.rhs = None

        # Constant Lamda parameter in Helmholtz eq.
        self.lam = 0.0

    def set_domain(self, *args):
        """Set spatial domain.
        """

        if len(args) != self.num_dims:
            raise AttributeError("Number of coordinate axes not compatible with dimensionality")

        # Get names of coordinate axes
        self.axis_names = [list(args[dim].keys())[0] for dim in range(self.num_dims)]

        # Get actual coordinates
        crds = [list(args[dim].values())[0] for dim in range(self.num_dims)]

        # Store as named tuple
        self.coordinates = collections.namedtuple("Coordinates", self.axis_names)(*crds)

        # Generate boundary data structures
        self._generate_boundary_data_types()

    def _generate_boundary_data_types(self):

        BoundaryCondition = namedlist.namedlist("BoundaryCondition", ["type", "data"])

        BoundaryPair = namedlist.namedlist("BoundaryPair", ["upper", "lower"])

        Boundary = namedlist.namedlist("Boundary", self.axis_names)

        boundary_pairs = [
            BoundaryPair(BoundaryCondition("periodic", None), BoundaryCondition("periodic", None))
            for dim in range(self.num_dims)
        ]

        self.boundary = Boundary(*boundary_pairs)

    def solve(self, ctrl_output=None):

        return self.solver(ctrl_output=ctrl_output)

    def _cartesian_2D_centered(self, ctrl_output=None):
        """Solves (d/dx)(du/dx) + (d/dy)(du/dy) + lam*u = rhs

        Solves 2D Helmholtz problem in a Cartesian domain using centered
        finite differences. Uses FISHPACK hwscrt routine.

        If specified crtl_output-keyword must be an empty list to which the
        control output of hwscrt routine is saved in order [pertrb, ierror]
        """

        if (ctrl_output is not None and type(ctrl_output) is not list) or (
            ctrl_output is not None and len(ctrl_output) > 0
        ):
            raise ValueError("Keyword 'ctrl_output' must be an empty list.")

        # On input, f is the RHS of the equation. However, the solution will be
        # placed in f which is why a copy is required here
        f = sp.copy(self.rhs, order="F")

        #
        # Figure out FISHPACK boundary condition identifier
        # Also alter f when dirichlet boundaries are used (see FISHPACK doc)
        # This is a bit clunky...
        #
        boundary_id = list()
        for dim in range(self.num_dims):

            bnd = self.boundary[dim]

            # Default: periodic
            bndid = 0

            if bnd.lower.type == "dirichlet" and bnd.upper.type == "dirichlet":
                bndid = 1
                if dim == 0:
                    f[0, :] = sp.copy(bnd.lower.data)
                    f[-1, :] = sp.copy(bnd.upper.data)
                else:
                    f[:, 0] = sp.copy(bnd.lower.data)
                    f[:, -1] = sp.copy(bnd.upper.data)

            if bnd.lower.type == "dirichlet" and bnd.upper.type == "neumann":
                bndid = 2
                if dim == 0:
                    f[0, :] = sp.copy(bnd.lower.data)
                else:
                    f[:, 0] = sp.copy(bnd.lower.data)

            if bnd.lower.type == "neumann" and bnd.upper.type == "neumann":
                bndid = 3

            if bnd.lower.type == "neumann" and bnd.upper.type == "dirichlet":
                bndid = 4
                if dim == 0:
                    f[-1, :] = sp.copy(bnd.upper.data)
                else:
                    f[:, -1] = sp.copy(bnd.upper.data)

            boundary_id.append(bndid)

        # Temporary work array required by hwscrt
        w = sp.zeros(f.shape[0] * f.shape[1])

        pertrb, ierror = hwscrt.hwscrt(
            self.coordinates[0][0],
            self.coordinates[0][-1],
            len(self.coordinates[0]) - 1,
            boundary_id[0],
            self.boundary[0].lower.data,
            self.boundary[0].upper.data,
            self.coordinates[1][0],
            self.coordinates[1][-1],
            len(self.coordinates[1]) - 1,
            boundary_id[1],
            self.boundary[1].lower.data,
            self.boundary[1].upper.data,
            self.lam,
            f,
            w,
        )
        if ctrl_output is not None:
            ctrl_output.append(pertrb)
            ctrl_output.append(ierror)

        return f

    def _spherical_2D_centered(self, ctrl_output=None):
        """Solves  1/sin(theta)*(d/d theta)(sin(theta) du/d theta)+ 1/sin^2(theta) (d^2 u/d phi^2) + lam*u = rhs

        Solves 2D Helmholtz problem on a unit sphere using centered finite
        differences. Uses FISHPACK hwsssp routine.

        The matrix indexing used in the function follows hwsssp routine of
        FISHPACK: the rows correspond to theta direction and columns the phi
        direction. Theta and phi must be given in radians.

        NOTE: DO NOT USE THIS FUNCTION TO SOLVE POISSON EQUATIONS OVER DOMAINS
        THAT CONTAIN EITHER OF THE POLES (I.E. WHERE THETA = 0 OR !PI).

        If specified crtl_output-keyword must be an empty list to which the
        control output of hwsssp routine is saved in order [pertrb, ierror]
        """
        # TODO: Add the FISHPACK functionality to solve equations over domains
        # that contain either of the poles the poles

        if (ctrl_output is not None and type(ctrl_output) is not list) or (
            ctrl_output is not None and len(ctrl_output) > 0
        ):
            raise ValueError("Keyword 'ctrl_output' must be an empty list.")

        # On input, f is the RHS of the equation. However, the solution will be
        # placed in f which is why a copy is required here
        f = sp.copy(self.rhs, order="F")

        #
        # Figure out FISHPACK boundary condition identifier
        # Also alter f when dirichlet boundaries are used (see FISHPACK doc)
        # This is a bit clunky...
        #
        boundary_id = list()
        for dim in range(self.num_dims):

            bnd = self.boundary[dim]

            # Default: periodic
            bndid = 0

            if bnd.lower.type == "dirichlet" and bnd.upper.type == "dirichlet":
                bndid = 1
                if dim == 0:
                    f[0, :] = sp.copy(bnd.lower.data)
                    f[-1, :] = sp.copy(bnd.upper.data)
                else:
                    f[:, 0] = sp.copy(bnd.lower.data)
                    f[:, -1] = sp.copy(bnd.upper.data)

            if bnd.lower.type == "dirichlet" and bnd.upper.type == "neumann":
                bndid = 2
                if dim == 0:
                    f[0, :] = sp.copy(bnd.lower.data)
                else:
                    f[:, 0] = sp.copy(bnd.lower.data)

            if bnd.lower.type == "neumann" and bnd.upper.type == "neumann":
                bndid = 3

            if bnd.lower.type == "neumann" and bnd.upper.type == "dirichlet":
                bndid = 4
                if dim == 0:
                    f[-1, :] = sp.copy(bnd.upper.data)
                else:
                    f[:, -1] = sp.copy(bnd.upper.data)
            # TODO: add the specific boundary conditions to be used at the poles:
            # bndid = 5,...,9

            boundary_id.append(bndid)

        # Temporary work array required by hwscrt
        w = sp.zeros(f.shape[0] * f.shape[1])

        pertrb, ierror = hwsssp.hwsssp(
            self.coordinates[0][0],
            self.coordinates[0][-1],
            len(self.coordinates[0]) - 1,
            boundary_id[0],
            self.boundary[0].lower.data,
            self.boundary[0].upper.data,
            self.coordinates[1][0],
            self.coordinates[1][-1],
            len(self.coordinates[1]) - 1,
            boundary_id[1],
            self.boundary[1].lower.data,
            self.boundary[1].upper.data,
            self.lam,
            f,
            w,
        )

        if ctrl_output is not None:
            ctrl_output.append(pertrb)
            ctrl_output.append(ierror)

        return f

    def _cartesian_3D_centered(self, ctrl_output=None):
        """Solves (d/dx)(du/dx) + (d/dy)(du/dy) + (d/dz)(du/dz) + lam*u = rhs

        Solves 3D Helmholtz problem in a Cartesian domain using centered
        finite differences. Uses FISHPACK hw3crt routine.

        If specified crtl_output-keyword must be an empty list to which the
        control output of hwscrt routine is saved in order [pertrb, ierror]
        """

        if (ctrl_output is not None and type(ctrl_output) is not list) or (
            ctrl_output is not None and len(ctrl_output) > 0
        ):
            raise ValueError("Keyword 'ctrl_output' must be an empty list.")

        # On input, f is the RHS of the equation. However, the solution will be
        # placed in f which is why a copy is required here
        f = sp.copy(self.rhs, order="F")

        #
        # Figure out FISHPACK boundary condition identifier
        # Also alter f when dirichlet boundaries are used (see FISHPACK doc)
        # This is a bit clunky...
        #
        boundary_id = list()
        for dim in range(self.num_dims):

            bnd = self.boundary[dim]

            # Boundary planes
            lower_bnd_plane = [slice(None), slice(None), slice(None)]
            lower_bnd_plane[dim] = 0

            upper_bnd_plane = [slice(None), slice(None), slice(None)]
            upper_bnd_plane[dim] = -1

            # Default: periodic
            bndid = 0

            if bnd.lower.type == "dirichlet" and bnd.upper.type == "dirichlet":
                bndid = 1

                f[lower_bnd_plane] = sp.copy(bnd.lower.data, order="F")
                f[upper_bnd_plane] = sp.copy(bnd.upper.data, order="F")

            if bnd.lower.type == "dirichlet" and bnd.upper.type == "neumann":
                bndid = 2

                f[lower_bnd_plane] = sp.copy(bnd.lower.data, order="F")

            if bnd.lower.type == "neumann" and bnd.upper.type == "neumann":
                bndid = 3

            if bnd.lower.type == "neumann" and bnd.upper.type == "dirichlet":
                bndid = 4

                f[upper_bnd_plane] = sp.copy(bnd.upper.data, order="F")

            boundary_id.append(bndid)

        # Temporary work array required by hwscrt
        w = sp.zeros(f.shape[0] * f.shape[1] * f.shape[2])

        pertrb, ierror = hw3crt.hw3crt(
            self.coordinates[0][0],
            self.coordinates[0][-1],
            len(self.coordinates[0]) - 1,
            boundary_id[0],
            self.boundary[0].lower.data,
            self.boundary[0].upper.data,
            #
            self.coordinates[1][0],
            self.coordinates[1][-1],
            len(self.coordinates[1]) - 1,
            boundary_id[1],
            self.boundary[1].lower.data,
            self.boundary[1].upper.data,
            #
            self.coordinates[2][0],
            self.coordinates[2][-1],
            len(self.coordinates[2]) - 1,
            boundary_id[2],
            self.boundary[2].lower.data,
            self.boundary[2].upper.data,
            #
            self.lam,
            f,
            w,
        )

        if ctrl_output is not None:
            ctrl_output.append(pertrb)
            ctrl_output.append(ierror)

        return f
