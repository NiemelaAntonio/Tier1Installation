To DO
=====

 * Add more solvers
 * Not apparent what the coordinates for RHS are for staggered case, CHECK!
 * Capture potential error codes
 * Check that the fishpack doc is OK with including the source in the distribution
 * Use https://github.com/jlokimlin/modern_fishpack instead of legaacy fishpack?
 * Documentation
 * Better installation procedure (setuptools, setup.py)
 * More error checking
 * Release to public
