#!/usr/bin/env python
#
# This file is part of pyFISHPACK.
#
# Copyright 2016, 2017 Jens Pomoell, Erkka Lumme
#
# pyFISHPACK is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# pyFISHPACK is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with pyFISHPACK. If not, see <http://www.gnu.org/licenses/>.

"""Example solution of Helmholtz equation in 2D Cartesian domain.

This is the example provided in fishpack4.1/test/thwscrt.f
"""

import matplotlib.pyplot as plt
import scipy as sp

import pyfishpack

if __name__ == "__main__":

    helmholtz = pyfishpack.HelmholtzSolver(geometry="cartesian", dim="2D", colocation="centered")

    #
    # Define problem domain
    #
    x = sp.linspace(0.0, 2.0, 41)
    y = sp.linspace(-1.0, 3.0, 81)

    helmholtz.set_domain({"x": x}, {"y": y})

    #
    # Set boundary conditions
    #

    # Dirichlet and Neumann boundary conditions require the boundary data
    # (value of the function or value of the derivative of the function) to
    # be given.
    helmholtz.boundary.x.lower.type = "dirichlet"
    helmholtz.boundary.x.lower.data = sp.zeros(len(y))

    helmholtz.boundary.x.upper.type = "neumann"
    helmholtz.boundary.x.upper.data = 4.0 * sp.cos((y + 1.0) * sp.pi / 2.0)

    # For periodic boundaries, no data needs not be given
    helmholtz.boundary.y.lower.type = "periodic"
    helmholtz.boundary.y.upper.type = "periodic"

    #
    # Compute RHS of the Helmholtz eq. (the source term)
    #
    X, Y = sp.meshgrid(x, y, indexing="ij")

    rhs = (2.0 - (4.0 + sp.pi * sp.pi / 4.0) * X ** 2) * sp.cos((Y + 1.0) * sp.pi / 2.0)

    helmholtz.rhs = rhs

    #
    # Set the lambda constant
    #
    helmholtz.lam = -4.0

    #
    # Compute exact solution
    #
    exact = (X ** 2) * sp.cos((Y + 1.0) * sp.pi / 2.0)

    #
    # Compute numerical solution
    #
    u = helmholtz.solve()

    #
    # Plot results
    #
    fig, (ax1, ax2) = plt.subplots(1, 2)

    p1 = ax1.pcolormesh(x, y, u.T)
    fig.colorbar(p1, ax=ax1)
    ax1.set_title("Numerical solution")

    p2 = ax2.pcolormesh(x, y, (u - exact).T)
    fig.colorbar(p2, ax=ax2)
    ax2.set_title("Numerical - Exact")

    plt.show()
