pyFISHPACK
==========

pyFISHPACK is a thin Python interface to [FISHPACK](https://www2.cisl.ucar.edu/resources/legacy/fishpack),
a legacy collection of subroutines for solving separable elliptic partial differential equations.


Installation
------------

pyFISHPACK relies on [f2py](http://docs.scipy.org/doc/numpy-dev/f2py/).
Currently the installation procedure is not automated and the user is required
to compile the source manually. A typical installation proceeds as follows:

    1. Edit the Makefile in the pyFISHPACK root dir to suit your system
    2. Run make

Note that you can run `f2py -c --help-fcompiler` to get info on the compiler
options for your system. In addition to f2py, the only non-standard Python
package that is needed is namedlist (`pip install namedlist`).


Usage
-----

Check the `examples/` directory for examples on using the code.


License
-------

pyFISHPACK is provided under the [LPGL](https://www.gnu.org/licenses/lgpl.html)
license. Note that FISHPACK carries it's own [license](https://www2.cisl.ucar.edu/resources/legacy/fishpack/license).
