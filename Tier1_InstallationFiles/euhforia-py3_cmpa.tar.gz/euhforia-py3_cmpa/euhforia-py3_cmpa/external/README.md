This folder contains third party libraries used by EUHFORIA
===========================================================

**Please note that these libraries are copyrighted by others than the EUHFORIA
authors, but are included as allowed by their respective licenses. Please
consult the license of each library for details.**

Below is a list of the libraries and details of how they were included in the
repository. Note that the libraries included here are only libraries that are
not included in CoCo.


pyFISHPACK
----------

::
    git clone https://jpomoell@bitbucket.org/jpomoell/pyfishpack.git
    cd pyfishpack/
    rm -rf .git/
    git add *
