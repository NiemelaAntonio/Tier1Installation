Getting started with EUHFORIA
=============================

This section provides a quick introduction to running EUHFORIA.

EUHFORIA consists of two essential building-blocks: the coronal model and
the heliosphere model. The two are ran separately.

Running the coronal model
-------------------------

To run the empirical coronal model: ::

  cd run
  ./empirical_coronal_model.py

This runs the coronal model using default parameters (as specified in
the corona_default.cfg configuration file). This includes downloading
the latest available GONG ADAPT magnetogram and using that as the input data
for the computation. To run the model using a custom setup, do: ::

  ./empirical_coronal_model.py --config-file name_of_configuration_file.cfg

where the last parameter specifies which configuration file to use. For example,
to run the June 2015 test one would execute ::

  ./empirical_coronal_model.py --config-file ../examples/June_2015_CMEs/June_2015_solar_wind.cfg

The coronal model computation should take, depending on the parameters,
from a couple of minutes to around ten at most.

By default, the only output of the coronal model is the solar wind boundary data
file that is required by the heliospheric model. For investigating the
properties of the coronal model and for producing plots, please see e.g. the
:file:`examples/June_2015_CMEs/Solar wind.ipynb` notebook.

Running the heliosphere model
-----------------------------

Running the heliospheric simulation is done by: ::

  cd run
  mpirun -np 8 ./heliosphere --config-file ../examples/June_2015_CMEs/June_2015_CMEs.cfg

where 8 refers to the number of processes that will be used. Again, the :code:`--config-file`
option says which configuration to use.

.. warning:: Running the heliospheric model in general takes a long time!


Visualizing the results
#######################

After the run has finished, plots of the results can be created using
the provided Python scripts. For instance, to plot data from the
heliosphere simulation: ::

  cd run
  ./create_plots.py
  ./create_plots.py June_2015/june_2015_*.npz  --output_dir june_2015/

This will save plots in the :file:`june_2015/`` directory. You can change
which meridional slice is plotted using the :code:`--meridional_plane`-option.

To convert data to VTK for visualization e.g. with VisIt, use the :file:`tools/convert_to_vtk.py`
tool.
