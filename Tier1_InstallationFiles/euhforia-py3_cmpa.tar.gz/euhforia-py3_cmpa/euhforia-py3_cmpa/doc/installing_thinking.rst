=====================
Installation Thinking
=====================

EUHFORIA relies on a number of external libraries, which must first be installed
before the code can be used.

The central dependency is the magnetohydrodynamics code CoCo. Therefore, the
first task is to install CoCo, a process which is detailed in the documentation
of CoCo and is not repeated here.

Once CoCo has been installed, the next task is to install the remaining
dependencies of EUHFORIA.

#. On Thinking these can be loaded by using the following commands:
   ::
	cd $VSC_DATA; 
	git clone https://USERNAME@github.com/jpomoell/euhforia.git
	cd euhforia

#. This step is only needed if you have not yet loaded the correct modules on Thinking. These are the modules you will have to load every time you want to use Euhforia on the cluster.
   ::
	source switch_to_2016a
	module load euhforia-software/201705-GCC-6.2.0-1

After the dependencies have been installed, the C++-parts of EUHFORIA need to be
compiled. This requires creating a makefile suitable for the system where the
code is to be used.

#. Compile pyfishpack
   :: 
	cd external/pyfishpack
	make	

#. Compilation.
   :: 
	cd $VSC_DATA; cd euhforia
	cp makefiles/thinking.make Makefile
	make
NOTE: To install on Breniac, change 'thinking' to 'broadwell' in the Makefile.
