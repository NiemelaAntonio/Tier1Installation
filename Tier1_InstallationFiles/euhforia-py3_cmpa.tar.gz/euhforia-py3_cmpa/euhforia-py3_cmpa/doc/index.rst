EUHFORIA documentation
====================================

Welcome to EUHFORIA: EUropean Heliopsheric FORecasting Information Asset.

EUHFORIA is a space weather modeling tool that
computes the time-evolution of the inner heliospheric plasma
environment using a combination of empirical and physics-based
modeling approaches.

Contents:

.. toctree::
   :maxdepth: 2

   installing.rst

   getting_started.rst

   phases.rst

   restarting.rst

   changelog.rst
