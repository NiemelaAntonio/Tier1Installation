Restart functionality
=====================

Most of a simulation run time is typically spent on relaxation of
background solar wind, which makes repetitive runs computationally
expensive. Restart functionality is here to amend this issue.

Typical usage
-------------

Generally, you would want to use the restart functionality to obtain
a snapshot of relaxed background solar wind. In order to do this, first,
run a simulation in a usual way setting a reasonable relaxation time
and setting cme insertion time and forecast time to zero.

Now one of the saved NPZ files can be used as a snapshot for simulation
restart. The snapshot file is specified using the restart_from option of the
configuration file. Refer to the example configuration file at
:file:`examples/restart/test_restart.cfg`. The restart_from
option supports wildcards, so you can use a snapshot of a parallel run.
Now you can specify relaxation time to be zero and set cme insertion
time and forecast time to some reasonable values.

The restart function does not depend on the number of cpus used for the
snapshot run and the following runs.

Caveats
-------------

There are a number of things to keep in mind when using the restart functionality:

   * All timing is with respect to the forecast start time which by definition is
     the time given by the solar wind background data. The forecast start time
     is not modified by the restart functionality.
   * As a result of the above, modifying the relaxation time when restarting
     does not change the duration of the relaxation (in typical use cases) because
     the simulation is simply trying to advance to time = forecast time + forecast duration
     from whatever time it is currently at (which is defined by the restart snapshot).
   * If a CME is in the process of being injected in the restart snapshot but
     is not included in the CME parameter file used in restarting, something horrible will result.
     It is important to remember that the restarting simulation is not aware of
     the CME parameter file or any other data used in producing the snapshot.
   * The grid of the simulation and restart data must correspond identically,
     i.e. restarting to a finer or coarser grid is not supported.
