============
Installation
============

EUHFORIA relies on a number of external libraries, which must first be installed
before the code can be used.

The central dependency is the magnetohydrodynamics code CoCo. Therefore, the
first task is to install CoCo, a process which is detailed in the documentation
of CoCo and is not repeated here.

Once CoCo has been installed, the next task is to install the remaining
dependencies of EUHFORIA, which are:

- `Pandas <http://pandas.pydata.org/>`_
- `SHTns <http://users.isterre.fr/nschaeff/SHTns/>`_
- `AstroPy <http://www.astropy.org/>`_
- `SunPy <http://www.sunpy.org/>`_
- `Numexpr <https://github.com/pydata/numexpr>`_
- pyFISHPACK (see below)

After the dependencies have been installed, the C++-parts of EUHFORIA need to be
compiled. This requires creating a makefile suitable for the system where the
code is to be used. Example makefiles are provided in the :file:`makefiles/` - directory. Note that
the configuration options are essentially the same as needed by CoCo.

Since the installation procedure differs depending on the configuration of the
system, instructions for a few different cases are provided separately below.

Typical installation procedure
==============================

In the following we briefly outline how one would typically
install the required libraries on a standard Linux/Unix system. Please
refer to the documentation of the corresponding libraries for
more comprehensive installation instructions.

SHTns
-----

SHTns is a spherical harmonic transform code. SHTns requires itself a
third-party library `FFTW <http://www.fftw.org/>`_ . A typical
installation scheme for the latter is as follows (see also the `instructions of SHTns <https://users.isterre.fr/nschaeff/SHTns/compil.html>`_ ):

#. Prepare files
   ::

      mkdir tmp_build
      cd tmp_build
      wget http://www.fftw.org/fftw-3.3.4.tar.gz
      tar xf fftw-3.3.4.tar.g

#. Configure
   ::

      cd fftw-3.3.4/
      ./configure --prefix=$HOME/libraries/fftw-3.3.4

#. Compile and install
   ::

      make
      make install

Once FFTW has been installed, the installation of SHTns and its
Python bindings proceeds typically along the following:

#. Prepare files
   ::

      mkdir tmp_build
      cd tmp_build
      wget https://bitbucket.org/nschaeff/shtns/downloads/shtns-2.6.2-r516.tar.gz
      tar xf shtns-2.6.2-r516.tar.gz

#. Configure
   ::

      cd shtns-2.6.2-r516
      export LDFLAGS=-L$HOME/libraries/fftw-3.3.4/lib
      export CPPFLAGS=-I$HOME/libraries/fftw-3.3.4/include
      ./configure --prefix=$HOME/libraries/shtns-2.6.2 --disable-openmp --enable-python

#. Compile and install
   ::

      make
      make install



AstroPy
-------

Typically (using pip):
::

   pip install --no-deps astropy

or using Anaconda:
::

   conda install astropy


SunPy
-----

Typically, if not the latest version is needed:
::

   pip install sunpy[all]

The [all] option is optional but recommended by SunPy.

With Anaconda:
::

   conda install sunpy


Numexpr
-------

With Anaconda:
::

   conda install numexpr


pyFISHPACK
----------

pyFISHPACK is a Python interface to FISHPACK, and is included as an external
dependency in the :file:`external/` directory, and must be compiled.
Please see the documentation therein for installation instructions.

Anaconda and macOS
==================

When compiling the C++-part of the code using Anaconda on macOS,
the run-time library needs to be changed from the system Python to that of
Anaconda. This is done using :file:`install_name_tool`. For instance for
the field line tracer:
::

    install_name_tool -change libpython2.7.dylib $HOME/anaconda/lib/libpython2.7.dylib euhforia/tools/tracer/tracer.so

You can check the names of the libraries that are loaded at runtime using
::

    otool -L euhforia/tools/tracer/tracer.so
