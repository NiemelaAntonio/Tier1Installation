=========
Changelog
=========

1.0.4 (May 2018)
---------------------

* Restart functionality added
* Added option for more flexible custom virtual spacecraft point output. Now it
  is possible to place arbitrary number of virtual spacecraft at positions
  relative to other objects e.g. Earth, or at fixed HEEQ coordinates. All specified
  in the standard configuration file.
* Updated default plotting tool with options for using OMNI data in addition
  to ACE NRT data. Added also option for plotting log(n).
* New data output mode that activates output from minus forecast duration to
  plus forecast duration.

1.0.3 (December 2017)
---------------------

* Corrected incorrect computation of thermal pressure of CMEs at inner boundary
* Reverted to computing the electric field directly as E = - v x B as a temporary
  work around while finding a solution to computing the non-inductive electric field
  accurately
* Added the LFF spheromak CME model as well as the truly spherical CME model
* Added new tests: July 2012 FR CME, synthetic solar wind and spheromak test
* Removed all instances of appending to the Python path directly: now EUHFORIA
  and dependencies need to be locatable by the system

1.0.2 (July 2017)
-----------------

* Fixed critical bug in core.util.replace_nan_with_average that caused the
  function to return None for maps with no NaNs instead of the original map

1.0.1 (June 2017)
-----------------

* Added support for using the distance from the coronal hole boundary in the
  empirical solar wind
* Shifted grid coordinates in heliospheric MHD model by delta/2 so that Earth
  is more often close to a cell-center
* Added option in SSCS magnetic field model to trace field lines down to
  a given height rather than always to the surface (photosphere)
* Added option to compute flux tube expansion factor using only the radial
  component
* Fixed a couple of bugs in empirical solar wind model, and several
  missing module imports

1.0 (June 2017)
---------------

* Initial release
