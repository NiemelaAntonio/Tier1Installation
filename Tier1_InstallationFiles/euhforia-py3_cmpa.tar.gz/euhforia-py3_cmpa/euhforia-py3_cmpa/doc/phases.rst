Phases of a run
===============

A heliosphere model run consists of three simulation phases:

1. Relaxation of the ambient solar wind
#. Insertion of CMEs
#. Forecast

Depicted as a timeline, the phases are as follows:

.. image:: timeline.png


Relaxation
----------

Each model run starts by creating a steady-state (when in a frame
co-rotating with the Sun) solar wind solution. This is accomplished by
running the model for a set number of days starting from an initial
state which is not a steady-state solution of the model equations.
During this relaxation, any transient behaviour is transported out of
the computational domain by the solar wind. This requires one to run
the heliosphere model a time

.. math:: t = \frac{d}{v_\mathrm{slow}}

where :math:`v_\mathrm{slow}` is the slowest wind speed at the inner
radial boundary, and :math:`d` is the radial extent of the
computational domain. For typical values :math:`v_\mathrm{slow} \sim
350 \, \mathrm{km/s}, d \sim 2 \, \mathrm{AU}` the required simulation
time :math:`t \sim 10` days.


CME insertion
-------------

At any given time, at least several CMEs are present in the inner
heliosphere on average. The plasma environment in the interplanetary
space is significantly modified by the presence of the CMEs, and this
needs to be taken into account when modeling the evolution of a
particular eruption.

To accomplish this, after a steady-state solution has been obtained, a
phase of inserting CMEs follows in the modeling pipelone. During this
time, any CMEs from the five days (default value) prior to the start
of the forecast is inserted. In this time, a slow CME of :math:`v \sim
350 \, \mathrm{km/s}` has had time to propagate to Earth.

.. note:: If no CMEs are given or if none of the CMEs are inside the time window of the
          simulation, the CME insertion phase is skipped.


Forecast
--------

The last phase of the run is the actual forecast, the time of start of
which is equal to the observation time of the magnetogram. The
forecast is reasonable to run forward in time approximately up until
the East limb observation crosses the central meridian. This
corresponds to

.. math:: t \sim 60^\circ \cdot \frac{27.2753 \, \mathrm{days}}{360^\circ} \sim 5 \, \mathrm{days}

which is the default value. If in addition the transit time of a fast
wind stream of approximately two days is considered, a forecast of
seven days is still reasonable to compute.
