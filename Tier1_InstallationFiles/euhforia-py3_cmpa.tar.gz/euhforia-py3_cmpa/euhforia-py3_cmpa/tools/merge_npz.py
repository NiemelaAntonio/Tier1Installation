#!/usr/bin/env python
#
# This file is part of EUHFORIA.
#
# Copyright 2016, 2017 Jens Pomoell
#                 2018 Jens Pomoell, Christine Verbeke
#
# EUHFORIA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# EUHFORIA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EUHFORIA. If not, see <http://www.gnu.org/licenses/>.

"""Merges npz output files produced in a parallel run into one file.

For each file expression, reads in all the separate npz files. When saving,
overlapping ghost cells are removed while keeping only the ghost cells at the
domain boundaries.
"""

import argparse
import glob
import os
import re
import sys

import numpy as np

import euhforia.core.constants as constants
import euhforia.core.io

# import coco.core.grid


if __name__ == "__main__":

    #
    # Parse command line arguments
    #
    parser = argparse.ArgumentParser()

    # Where the data is located
    parser.add_argument(
        "files",
        type=str,
        # metavar="path",
        nargs="*",
        help="files to process",
    )

    # Where to save plots and data
    parser.add_argument(
        "--output_dir",
        default="output/",
        type=str,
        metavar="path",
        help="dir. where output is saved (default: %(default)s)",
    )

    args = parser.parse_args()

    # Display help message if no files given
    if len(args.files) == 0:
        parser.print_help()
        exit()

    # Get directory of data
    data_dir = os.path.dirname(os.path.abspath(args.files[0]))

    #
    # Create list of file expressions of type xxx_dateTtime*
    #
    file_expressions = []
    for f in args.files:

        # Get the date
        match = re.search(r"\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}", f)

        # Skip if a file matching the regex does not exist
        if match is not None:

            date = match.group()

            # Split the file name
            fs = f.split(date)

            # Create the appropriate file expression to merge
            # distributed npz files
            file_expressions.append(fs[0] + date + "*")

    # Remove duplicate and sort
    file_expressions = sorted(list(set(file_expressions)))

    #
    # Process each file
    #
    for idx, f in enumerate(file_expressions):

        print("Processing", f)
        sys.stdout.flush()

        # Load data
        data = euhforia.core.io.load_heliospheric_data(f)

        # Strucutre to save
        data_to_save = {
            "time": data.time,
            "rank": 0,
            "mpi_coord": [0, 0, 0],
            "mpi_blocks": [1, 1, 1],
            "num_ghosts": data.grid.num_ghost_cells,
            "r": data.grid.edge_coords.r,
            "clt": data.grid.edge_coords.clt,
            "lon": data.grid.edge_coords.lon,
            "units": [data.grid.axis.r.unit, data.grid.axis.clt.unit, data.grid.axis.lon.unit],
            "datetime": data.datetime,
            "vr": data.vr,
            "vclt": data.vclt,
            "vlon": data.vlon,
            "n": data.n,
            "P": data.P,
            "Br": data.Br,
            "Bclt": data.Bclt,
            "Blon": data.Blon,
        }

        # Save to disk in same npz format
        output_file_name = f.split("/")[-1].split("*")[0]

        np.savez(args.output_dir + output_file_name, **data_to_save)
